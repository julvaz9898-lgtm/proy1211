import streamlit as st
from datetime import datetime, timedelta
import pyodbc
import pandas as pd

# Configurar la página
st.set_page_config(page_title="Venta Diaria Lactalis", layout="centered")

st.sidebar.success("Selecciona una página arriba 👆")
# Obtener la fecha de hoy
hoy = datetime.today()

# Calcular la fecha del día anterior
ayer = hoy - timedelta(days=1)

# Formatear la fecha del día anterior como texto (opcional)
fecha_anterior = ayer.strftime("%d/%m/%Y")



# Cargar y mostrar la imagen desde una carpeta
image_path = r"C:\Users\Administrador.WIN-LE39LI0G69U\Desktop\streamlit\img\mexico.png"  # Cambia esto por la ruta de tu imagen
st.image(image_path, caption='',  use_container_width=True)

# Título grande en el centro con color azul claro
st.markdown(
    """
    <h1 style='text-align: center; color: #2c83f9;'>Venta Diaria Lactalis México🧀🥛</h1>
    """,
    unsafe_allow_html=True
)

st.markdown("""
<style>
.big-font {
    font-size:40px !important;
}
</style>
""", unsafe_allow_html=True)


texto_con_fecha = f'<p class="big-font">Resumen Volumen al {fecha_anterior}</p>'
# Mostrar el texto en Streamlit
st.markdown(texto_con_fecha, unsafe_allow_html=True)



# Título
st.title("¡Buen día!")

# Texto
st.write("Comparto reporte de seguimiento sobre sus Volúmenes vs Cuota")

# Texto subrayado

st.markdown("<u>Datos Importantes:</u>", unsafe_allow_html=True)

# Configuración de la conexión a SQL Server
server = '172.22.1.10\DHW_BI'
database = 'ESTADISTICAS'
username = 'sa'
password = 'BD06e8Y8'
connection_string = f'DRIVER={{SQL Server}};SERVER={server};DATABASE={database};UID={username};PWD={password}'

# Función para obtener los datos de la tabla
def obtener_datos():
    try:
        conn = pyodbc.connect(connection_string)
        query = """
        SELECT
        *

        FROM CUOTA
        """
        df = pd.read_sql(query, conn)
        conn.close()
        return df.iloc[0]  # Suponiendo que solo hay una fila de datos
    except Exception as e:
        st.error(f"Error al conectar a la base de datos: {e}")
        return None


# Interfaz de la aplicación Streamlit
def main():
    st.title("Reporte de Ventas")

    datos = obtener_datos()
    if datos is not None:
        st.write(f"**Venta Diaria promedio REAL** ({datos['VENTA_DIARIA_PROM']:.2f}) T")
        st.write(f"**Venta Diaria promedio Cuota** ({datos['VENTA_PROM_CUOTA']:.2f}) T ({datos['POR_VENTA']:.2f}%)")
        st.write(f"**Venta necesaria Diaria para alcanzar el objetivo** ({datos['VENTA_OBJETIVO']:.2f}) T")
        st.write("")
        st.write(f"Si la venta sigue de manera lineal **Volumen Final del mes** ({datos['VOL_FINAL_MES']:.2f}) T vs Cuota ({datos['POR_VENTA']:.2f}%)")
        st.write(f"**Cuota Objetivo** ({datos['VOL_NET_CUOT']:.2f}) T")

if __name__ == "__main__":
    main()


# Función para obtener datos de SQL Server TABLA1
def get_data(query2):
    conn = pyodbc.connect(connection_string)
    df = pd.read_sql(query2, conn)
    conn.close()
    df = df.round(2)
    return df

# Interfaz de Streamlit
st.title("Visualización de Datos")


query2 = """ SELECT *
  FROM [CUOTA_VENTA].[dbo].[SUBCANAL_CUOTA] ORDER BY SUBCANAL
;"""
df = get_data(query2)
# Establecer la columna 'SUBCANAL' como índice
df.set_index('SUBCANAL', inplace=True)

# Función para aplicar colores según la condición
def color_condicion_todo(row):
    """
    Aplica color rojo si el valor de la última columna es menor a 100,
    azul si es mayor o igual a 100.
    """
    color = 'red' if row[-1] < 100 else 'blue'
    return [f'color: {color}' for _ in row]

# Aplicar estilos a todas las celdas del DataFrame
df_estilizado = df.style.apply(color_condicion_todo, axis=1)

# Formatear la columna 'vol_act_cuota' para agregar el símbolo %
df_estilizado = df_estilizado.format({'vol_act_cuota': '{:.2f}%'})

df_estilizado = df_estilizado.format("{:.2f}")


# Mostrar el DataFrame estilizado en Streamlit
st.write("### a.SubC vs Cuota:")
st.write(df_estilizado)







# Función para obtener datos de SQL Server TABLA2
def get_data(query3):
    conn = pyodbc.connect(connection_string)
    df = pd.read_sql(query3, conn)
    conn.close()
    df = df.round(2)
    return df



query3 = """SELECT
    GRUPO,
    SUM([a.Vol Act]) AS a_Vol_Act,
    sum([A.IMP ACT])/NULLIF(SUM([a.Vol Act]),0) AS a_val_kg_Act,
    SUM([d.vol cuota]) AS d_vol_cuota,
    NULLIF(sum([A.IMP CUOT]),0)/NULLIF(sum([d.vol cuota]),0) AS d_val_kg_cuota,
    SUM([a.Vol Act]) / NULLIF(SUM([d.vol cuota]), 0) * 100 AS vol_act_cuota
FROM
    [CUOTA_VENTA].[dbo].[CUOTA_2025]
GROUP BY
    GRUPO
UNION ALL
SELECT
    'Total' AS GRUPO,
    SUM([a.Vol Act]) AS a_Vol_Act,
    NULLIF(sum([A.IMP ACT]),0)/NULLIF(SUM([a.Vol Act]),0) AS a_val_kg_Act,
    SUM([d.vol cuota]) AS d_vol_cuota,
    NULLIF(sum([A.IMP CUOT]),0)/NULLIF(sum([d.vol cuota]),0) AS d_val_kg_cuota,
    SUM([a.Vol Act]) / NULLIF(SUM([d.vol cuota]), 0) * 100 AS vol_act_cuota
FROM
    [CUOTA_VENTA].[dbo].[CUOTA_2025] ;"""
df = get_data(query3)
# Establecer la columna 'SUBCANAL' como índice
df.set_index('GRUPO', inplace=True)

# Función para aplicar colores según la condición
def color_condicion_todo(row):
    """
    Aplica color rojo si el valor de la última columna es menor a 100,
    azul si es mayor o igual a 100.
    """
    color = 'red' if row[-1] < 100 else 'blue'
    return [f'color: {color}' for _ in row]

# Aplicar estilos a todas las celdas del DataFrame
df_estilizado = df.style.apply(color_condicion_todo, axis=1)



# Formatear la columna 'vol_act_cuota' para agregar el símbolo %
df_estilizado = df_estilizado.format({'vol_act_cuota': '{:.2f}%'})
df_estilizado = df_estilizado.format("{:.2f}")

# Mostrar el DataFrame estilizado en Streamlit
st.write("### a.Grupo vs Cuota")
st.write(df_estilizado)


























# Función para obtener datos de SQL Server TABLA3
def get_data(query4):
    conn = pyodbc.connect(connection_string)
    df = pd.read_sql(query4, conn)
    conn.close()
    df = df.round(2)
    return df



query4 = """ SELECT
    [Sourcing ],
    CONVERT(DECIMAL(10,2),SUM([a.Vol Act])) AS a_Vol_Act,
    CAST(sum([A.IMP ACT])/NULLIF(SUM([a.Vol Act]),0) AS DECIMAL(10,2)) AS a_val_kg_Act,
    SUM([d.vol cuota]) AS d_vol_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(sum([A.IMP CUOT]),0)/NULLIF(sum([d.vol cuota]),0)) AS d_val_kg_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(SUM([a.Vol Act]),0) /NULLIF(SUM([d.vol cuota]),0)) * 100 AS vol_act_cuota
FROM
    [CUOTA_VENTA].[dbo].[CUOTA_2025]
GROUP BY
    [Sourcing ]
UNION ALL
SELECT
    'Total' AS Sourcing,
    CONVERT(DECIMAL(10,2),SUM([a.Vol Act])) AS a_Vol_Act,
     CAST(sum([A.IMP ACT])/NULLIF(SUM([a.Vol Act]),0) AS DECIMAL(10,2))  AS a_val_kg_Act,
    SUM([d.vol cuota]) AS d_vol_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(sum([A.IMP CUOT]),0)/NULLIF(sum([d.vol cuota]),0)) AS d_val_kg_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(SUM([a.Vol Act]),0) /NULLIF(SUM([d.vol cuota]),0)) * 100 AS vol_act_cuota
FROM
    [CUOTA_VENTA].[dbo].[CUOTA_2025] ORDER BY [Sourcing ];"""
df = get_data(query4)

df.columns = df.columns.str.strip()
# Establecer la columna 'SUBCANAL' como índice
df.set_index('Sourcing', inplace=True)

# Función para aplicar colores según la condición
def color_condicion_todo(row):
    """
    Aplica color rojo si el valor de la última columna es menor a 100,
    azul si es mayor o igual a 100.
    """
    color = 'red' if row[-1] < 100 else 'blue'
    return [f'color: {color}' for _ in row]

# Aplicar estilos a todas las celdas del DataFrame
df_estilizado = df.style.apply(color_condicion_todo, axis=1)



# Formatear la columna 'vol_act_cuota' para agregar el símbolo %
df_estilizado = df_estilizado.format({'vol_act_cuota': '{:.2f}%'})
df_estilizado = df_estilizado.format("{:.2f}")

# Mostrar el DataFrame estilizado en Streamlit
st.write("### a.Sourcing vs Cuota")
st.write(df_estilizado)






















# Función para obtener datos de SQL Server TABLA4
def get_data(query5):
    conn = pyodbc.connect(connection_string)
    df = pd.read_sql(query5, conn)
    conn.close()
    df = df.round(2)
    return df



query5 = """
  SELECT
    encargado,
    CONVERT(DECIMAL(10,2),SUM([a.Vol Act])) AS a_Vol_Act,
    CAST(sum([A.IMP ACT])/NULLIF(SUM([a.Vol Act]),0) AS DECIMAL(10,2)) AS a_val_kg_Act,
    SUM([d.vol cuota]) AS d_vol_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(sum([A.IMP CUOT]),0)/NULLIF(sum([d.vol cuota]),0)) AS d_val_kg_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(SUM([a.Vol Act]),0) /NULLIF(SUM([d.vol cuota]),0)) * 100 AS vol_act_cuota
FROM
    [CUOTA_VENTA].[dbo].[CUOTA_2025] where encargado!='VERONICA VALENCIA'
GROUP BY
    encargado
UNION ALL
SELECT
    'Total' AS encargado,
    CONVERT(DECIMAL(10,2),SUM([a.Vol Act])) AS a_Vol_Act,
     CAST(sum([A.IMP ACT])/NULLIF(SUM([a.Vol Act]),0) AS DECIMAL(10,2))  AS a_val_kg_Act,
    SUM([d.vol cuota]) AS d_vol_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(sum([A.IMP CUOT]),0)/NULLIF(sum([d.vol cuota]),0)) AS d_val_kg_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(SUM([a.Vol Act]),0) /NULLIF(SUM([d.vol cuota]),0)) * 100 AS vol_act_cuota
FROM
    [CUOTA_VENTA].[dbo].[CUOTA_2025] ORDER BY encargado
;"""
df = get_data(query5)

df.columns = df.columns.str.strip()
# Establecer la columna 'SUBCANAL' como índice
df.set_index('encargado', inplace=True)

# Función para aplicar colores según la condición
def color_condicion_todo(row):
    """
    Aplica color rojo si el valor de la última columna es menor a 100,
    azul si es mayor o igual a 100.
    """
    color = 'red' if row[-1] < 100 else 'blue'
    return [f'color: {color}' for _ in row]

# Aplicar estilos a todas las celdas del DataFrame
df_estilizado = df.style.apply(color_condicion_todo, axis=1)



# Formatear la columna 'vol_act_cuota' para agregar el símbolo %
df_estilizado = df_estilizado.format({'vol_act_cuota': '{:.2f}%'})
df_estilizado = df_estilizado.format("{:.2f}")

# Mostrar el DataFrame estilizado en Streamlit
st.write("### a.Encargado vs Cuota")
st.write(df_estilizado)


























# Función para obtener datos de SQL Server TABLA5
def get_data(query6):
    conn = pyodbc.connect(connection_string)
    df = pd.read_sql(query6, conn)
    conn.close()
    df = df.round(2)
    return df



query6 = """
    SELECT
    Marca1,
    CONVERT(DECIMAL(10,2),SUM([a.Vol Act])) AS a_Vol_Act,
    CAST(sum([A.IMP ACT])/NULLIF(SUM([a.Vol Act]),0) AS DECIMAL(10,2)) AS a_val_kg_Act,
    SUM([d.vol cuota]) AS d_vol_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(sum([A.IMP CUOT]),0)/NULLIF(sum([d.vol cuota]),0)) AS d_val_kg_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(SUM([a.Vol Act]),0) /NULLIF(SUM([d.vol cuota]),0)) * 100 AS vol_act_cuota
FROM
    [CUOTA_VENTA].[dbo].[CUOTA_2025]
GROUP BY
    Marca1
UNION ALL
SELECT
    'Total' AS Marca1,
    CONVERT(DECIMAL(10,2),SUM([a.Vol Act])) AS a_Vol_Act,
     CAST(sum([A.IMP ACT])/NULLIF(SUM([a.Vol Act]),0) AS DECIMAL(10,2))  AS a_val_kg_Act,
    SUM([d.vol cuota]) AS d_vol_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(sum([A.IMP CUOT]),0)/NULLIF(sum([d.vol cuota]),0)) AS d_val_kg_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(SUM([a.Vol Act]),0) /NULLIF(SUM([d.vol cuota]),0)) * 100 AS vol_act_cuota
FROM
    [CUOTA_VENTA].[dbo].[CUOTA_2025] ORDER BY Marca1
;"""
df = get_data(query6)

df.columns = df.columns.str.strip()
# Establecer la columna 'SUBCANAL' como índice
df.set_index('Marca1', inplace=True)

# Función para aplicar colores según la condición
def color_condicion_todo(row):
    """
    Aplica color rojo si el valor de la última columna es menor a 100,
    azul si es mayor o igual a 100.
    """
    color = 'red' if row[-1] < 100 else 'blue'
    return [f'color: {color}' for _ in row]

# Aplicar estilos a todas las celdas del DataFrame
df_estilizado = df.style.apply(color_condicion_todo, axis=1)



# Formatear la columna 'vol_act_cuota' para agregar el símbolo %
df_estilizado = df_estilizado.format({'vol_act_cuota': '{:.2f}%'})
df_estilizado = df_estilizado.format("{:.2f}")

# Mostrar el DataFrame estilizado en Streamlit
st.write("### MARCA 1 vs Cuota")
st.write(df_estilizado)











# Función para obtener datos de SQL Server TABLA6
def get_data(query7):
    conn = pyodbc.connect(connection_string)
    df = pd.read_sql(query7, conn)
    conn.close()
    df = df.round(2)
    return df



query7 = """


  SELECT
    Producto4,
    CONVERT(DECIMAL(10,2),SUM([a.Vol Act])) AS a_Vol_Act,
    CAST(sum([A.IMP ACT])/NULLIF(SUM([a.Vol Act]),0) AS DECIMAL(10,2)) AS a_val_kg_Act,
    SUM([d.vol cuota]) AS d_vol_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(sum([A.IMP CUOT]),0)/NULLIF(sum([d.vol cuota]),0)) AS d_val_kg_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(SUM([a.Vol Act]),0) /NULLIF(SUM([d.vol cuota]),0)) * 100 AS vol_act_cuota
FROM
    [CUOTA_VENTA].[dbo].[CUOTA_2025]
GROUP BY
    Producto4
UNION ALL
SELECT
    'Total' AS Producto4,
    CONVERT(DECIMAL(10,2),SUM([a.Vol Act])) AS a_Vol_Act,
     CAST(sum([A.IMP ACT])/NULLIF(SUM([a.Vol Act]),0) AS DECIMAL(10,2))  AS a_val_kg_Act,
    SUM([d.vol cuota]) AS d_vol_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(sum([A.IMP CUOT]),0)/NULLIF(sum([d.vol cuota]),0)) AS d_val_kg_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(SUM([a.Vol Act]),0) /NULLIF(SUM([d.vol cuota]),0)) * 100 AS vol_act_cuota
FROM
    [CUOTA_VENTA].[dbo].[CUOTA_2025] ORDER BY Producto4
;"""
df = get_data(query7)

df.columns = df.columns.str.strip()
# Establecer la columna 'SUBCANAL' como índice
df.set_index('Producto4', inplace=True)

# Función para aplicar colores según la condición
def color_condicion_todo(row):
    """
    Aplica color rojo si el valor de la última columna es menor a 100,
    azul si es mayor o igual a 100.
    """
    color = 'red' if row[-1] < 100 else 'blue'
    return [f'color: {color}' for _ in row]

# Aplicar estilos a todas las celdas del DataFrame
df_estilizado = df.style.apply(color_condicion_todo, axis=1)



# Formatear la columna 'vol_act_cuota' para agregar el símbolo %
df_estilizado = df_estilizado.format({'vol_act_cuota': '{:.2f}%'})
df_estilizado = df_estilizado.format("{:.2f}")

# Mostrar el DataFrame estilizado en Streamlit
st.write("### PRODUCTO vs Cuota")
st.write(df_estilizado)
