import streamlit as st
from datetime import datetime, timedelta
import pyodbc
import pandas as pd

st.title("📈 CAPISTRANO - REPORTE DE VENTAS")
st.sidebar.success("Selecciona una página arriba 👆")



# Configuración de la conexión a SQL Server
server = '172.22.1.10\DHW_BI'
database = 'ESTADISTICAS'
username = 'sa'
password = 'BD06e8Y8'
connection_string = f'DRIVER={{SQL Server}};SERVER={server};DATABASE={database};UID={username};PWD={password}'


# Función para obtener datos de SQL Server TABLA1
def get_data(query2):
    conn = pyodbc.connect(connection_string)
    df = pd.read_sql(query2, conn)
    conn.close()
    df = df.round(2)
    return df

# Interfaz de Streamlit


query2 = """    SELECT
    [Id Cliente],[Codigo Lactalis],[Descripcion_Lactalis2],
    CONVERT(DECIMAL(10,2),SUM([a.Vol Act])) AS a_Vol_Act,
    CAST(sum([A.IMP ACT])/NULLIF(SUM([a.Vol Act]),0) AS DECIMAL(10,2)) AS a_val_kg_Act,
    SUM([d.vol cuota]) AS d_vol_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(sum([A.IMP CUOT]),0)/NULLIF(sum([d.vol cuota]),0)) AS d_val_kg_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(SUM([a.Vol Act]),0) /NULLIF(SUM([d.vol cuota]),0)) * 100 AS vol_act_cuota
FROM
    [CUOTA_VENTA].[dbo].[CUOTA_2025] where [Id Cliente]='2000001514'
GROUP BY
    [Id Cliente],[Codigo Lactalis],Descripcion_Lactalis2
UNION ALL
SELECT
    'total'as Id_Cliente,0 AS CodigoLactalis,'total' as Descripcion_Lactalis2,
    CONVERT(DECIMAL(10,2),SUM([a.Vol Act])) AS a_Vol_Act,
     CAST(sum([A.IMP ACT])/NULLIF(SUM([a.Vol Act]),0) AS DECIMAL(10,2))  AS a_val_kg_Act,
    SUM([d.vol cuota]) AS d_vol_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(sum([A.IMP CUOT]),0)/NULLIF(sum([d.vol cuota]),0)) AS d_val_kg_cuota,
    CONVERT(DECIMAL(10,2),NULLIF(SUM([a.Vol Act]),0) /NULLIF(SUM([d.vol cuota]),0)) * 100 AS vol_act_cuota
FROM
    [CUOTA_VENTA].[dbo].[CUOTA_2025] WHERE  [Id Cliente]='2000001514'
;"""
df = get_data(query2)
# Establecer la columna 'SUBCANAL' como índice
df.set_index(['Id Cliente','Codigo Lactalis','Descripcion_Lactalis2'], inplace=True)


# Función para aplicar colores según la condición
def color_condicion_todo(row):
    """
    Aplica color rojo si el valor de la última columna es menor a 100,
    azul si es mayor o igual a 100.
    """
    color = 'red' if row[-1] < 100 else 'blue'
    return [f'color: {color}' for _ in row]

# Aplicar estilos a todas las celdas del DataFrame
df_estilizado = df.style.apply(color_condicion_todo, axis=1)

# Formatear la columna 'vol_act_cuota' para agregar el símbolo %
df_estilizado = df_estilizado.format({'vol_act_cuota': '{:.2f}%'})

df_estilizado = df_estilizado.format("{:.2f}")


# Mostrar el DataFrame estilizado en Streamlit
st.write("### DIAMANTE VS CUOTA CAPISTRANO:")
st.write(df_estilizado)
