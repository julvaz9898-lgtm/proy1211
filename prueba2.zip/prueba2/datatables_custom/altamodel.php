<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />


<body>
<nav class="navbar navbar-ligth" style="background-color: #e3f2fd;">
    <div class="container">
    <a>
    <img src="images/logo_lactalis.jpg">
       
    <div>
    <a aling="rigth" class="navbar-brand ">MARCAS Y MODELOS DE EQUIPOS</a>
    
   
       
    </div>
</nav>


<div class="container p-4">
    <div class="row">
      <div class="col-md-9 register-right"> 
         <form action="modelguardar.php" method="POST" class="form-register" enctype="multipart/form-data">
         <p class="text-uppercase" >AGREGAR </p>
          
         <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
        
                                <div class="row register-form">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Marca*" name="Marca" />
                                        </div>
                                       
                                      
                                                                             
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Modelo*" name="Model" />
                                        </div>
                                       
                                        
                                       
                                      
                                           
                                        <a href="marcas.php" class="btn btn-danger"  role="button" aria-pressed="true">ATRAS</a>                            
                                        <button type="submit"class="btn btn-success" name="savemodel">GUARDAR</button>
                                        
                                    </div>
                                </div>
                            </div>

         




         </form>

        </div>  
    </div>  
</div>





















































<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
