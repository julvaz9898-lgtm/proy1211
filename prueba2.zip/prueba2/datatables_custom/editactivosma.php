<?php
 include("conexiondb.php");

 

 $Username=$_SESSION['Username'];
 
 




?>


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<body>
<nav class="navbar navbar-ligth" style="background-color: #e3f2fd;">
    <div class="container">
    <a href="index.php">
    <img src="images/logo_lactalis.jpg">
       
    <div>
    <a aling="rigth" href="activosma.php"class="navbar-brand ">EDITOR DE ACTIVO FIJO</a>
    
   
       
    </div>
</nav>

<?php include("conexiondb.php");
if(isset($_GET['id'])){
    $id=$_GET['id'];
    $query= "SELECT * FROM activo_sma WHERE id=$id";
    $result=mysqli_query($conn,$query);
    if(mysqli_num_rows($result)==1){
        $row = mysqli_fetch_array($result);
        $Mes=$row['Mes'];
        $Fecha_Adquisicion=$row['Fecha_Adquisicion'];
        $Ubicacion=$row['Ubicacion'];
        $Area=$row['Area'];
        $CeCo=$row['CeCo'];
        $Responsable=$row['Responsable'];
        $Descripcion_Bien=$row['Descripcion_Bien'];
        $Marca=$row['Marca'];
        $Modelo=$row['Modelo'];
        $Numero_de_serie=$row['Numero_de_serie'];
        $Num_de_placa=$row['Num_de_placa'];
        $Cantidad=$row['Cantidad'];
        $Importe_MOI=$row['Importe_MOI'];
        $Moneda=$row['Moneda'];
        $Factura=$row['Factura'];
        $Registro_Contable=$row['Registro_Contable'];
        $Estatus=$row['Estatus'];
        $Sociedad=$row['Sociedad'];
        $Razon_Social=$row['Razon_Social'];
        $Ano=$row['Ano'];
    } 
}


if (isset($_POST['update'])) {
    $id = $_GET['id'];
    $Mes=$_POST['Mes'];
    $Fecha_Adquisicion=$_POST['Fecha_Adquisicion'];
    $Ubicacion=$_POST['Ubicacion'];
    $Area=$_POST['Area'];
    $CeCo=$_POST['CeCo'];
    $Responsable=$_POST['Responsable'];
    $Descripcion_Bien=$_POST['Descripcion_Bien'];
    $Marca=$_POST['Marca'];
    $Modelo=$_POST['Modelo'];
    $Numero_de_serie=$_POST['Numero_de_serie'];
    $Num_de_placa=$_POST['Num_de_placa'];
    $Cantidad=$_POST['Cantidad'];
    $Importe_MOI=$_POST['Importe_MOI'];
    $Moneda=$_POST['Moneda'];
    $Factura=$_POST['Factura'];
    $Registro_Contable=$_POST['Registro_Contable'];
    $Estatus=$_POST['Estatus'];
    $Sociedad=$_POST['Sociedad'];
    $Razon_Social=$_POST['Razon_Social'];
    $Ano=$_POST['Ano'];

$queryup = "UPDATE activo_sma set Mes = '$Mes', Fecha_Adquisicion= '$Fecha_Adquisicion',Ubicacion='$Ubicacion',Area='$Area',CeCo='$CeCo',Responsable='$Responsable', 
Descripcion_Bien='$Descripcion_Bien',Marca='$Marca',Modelo='$Modelo',Numero_de_serie='$Numero_de_serie',Num_de_placa='$Num_de_placa' ,Cantidad='$Cantidad' ,
Importe_MOI='$Importe_MOI' ,Moneda='$Moneda' , Factura='$Factura' , Registro_Contable='$Registro_Contable' , Estatus= '$Estatus', Sociedad='$Sociedad',  Razon_Social='$Razon_Social', Ano='$Ano'      WHERE id=$id";
mysqli_query($conn, $queryup);
$_SESSION['message'] = 'Actualizado correctamente';
$_SESSION['message_type'] = 'warning';;
header('Location: activosma.php');  
  }



?>

<div class="container p-4">
    <div class="row">
      <div class="col-md-9 register-right"> 
      <form action="editactivosma.php?id=<?php echo $_GET['id']; ?>" method="POST" class="form-register" >
         <p class="text-uppercase" >EDITAR ACTIVO</p>
          
         <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
        
                                <div class="row register-form">
                                    <div class="col-md-6">

                                    <div class="form-group">
                                        <a aling="left">MES</a>
                                            <select class="form-control" name="Mes" value="<?php echo $Mes; ?>">
                                            
                                                <option><?php echo $Mes;?></option>
                                                <option>FEBRERO</option>
                                                <option>MARZO</option>
                                                <option>ABRIL</option>
                                                <option>MAYO</option>
                                                <option>JUNIO</option>
                                                <option>JULIO</option>
                                                <option>AGOSTO</option>
                                                <option>SEPTIEMBRE</option>
                                                <option>OCTUBRE </option>
                                                <option>NOVIEMBRE</option>
                                                <option>DICIEMBRE</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Fecha Adquisicion</a>
                                            <input type="date" class="form-control" placeholder="Fecha de Adquisicion*" value="<?php echo $Fecha_Adquisicion; ?>" name="Fecha_Adquisicion"  />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Ubicacion</a>
                                            <select class="form-control" name="Ubicacion" value="<?php echo $Ubicacion; ?>">
                                            
                                                <option>SANULAC</option>
                                                <option>SMA</option>
                                                <option>ICI</option>
                                                
                                            </select>
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Area</a>
                                            <input type="text" class="form-control" placeholder="AREA*" name="Area"  value="<?php echo $Area; ?>" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">CeCo</a>
                                            <input type="text" class="form-control" placeholder="CeCo*" name="CeCo" value="<?php echo $CeCo; ?>" />
                                        </div>
            
                                        <div class="form-group">
                                        <a aling="left">Responsable</a>
                                            <input type="text" class="form-control"  placeholder="Responsable*" name="Responsable" value="<?php echo $Responsable; ?>" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Descripcion</a>
                                            <input type="text" class="form-control"  placeholder="DESCRIPCION *" name="Descripcion_Bien" value="<?php echo $Descripcion_Bien; ?>" />
                                        </div>
                                        
                                        <div class="form-group">
                                        <a aling="left">Marca</a>
                                            <input type="text" class="form-control"  placeholder="Marca*" name="Marca" value="<?php echo $Marca; ?>"  />
                                        </div>

                                        <div class="form-group">
                                        <a aling="left">Numero de Serie</a>
                                            <input type="text" class="form-control"  placeholder="NUMERO DE SERIE*" name="Numero_de_serie" value="<?php echo $Numero_de_serie; ?>"  />
                                        </div>


                                        <div class="form-group">
                                        <a aling="left">AÑO</a>
                                            <select class="form-control" name="Ano" value="<?php echo $Ano; ?>">
                                            
                                                <option>2020</option>
                                                <option>2021</option>
                                                <option>2022</option>
                                                <option>2023</option>
                                                <option>2024</option>
                                                <option>2025</option>
                                                <option>2026</option>
                                                <option>2027</option>
                                                <option>2028</option>
                                                <option>2029</option>
                                                <option>2030</option>
                                                <option>2031</option>
                                              
                                            </select>
                                        </div>
                                      
                                        
                                    </div>
                                    
                                    <div class="col-md-6">

                                    <div class="form-group">
                                    <a aling="left">Modelo</a>
                                            <input type="text" class="form-control"  placeholder="MODELO*" name="Modelo"  value="<?php echo $Modelo; ?>" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Num de Placa</a>
                                            <input type="text" class="form-control"  placeholder="NUMERO DE PLACA*" name="Num_de_placa" value="<?php echo $Num_de_placa; ?>"  />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Cantidad</a>
                                            <input type="text" class="form-control"  placeholder="CANTIDAD*" name="Cantidad"  value="<?php echo $Cantidad; ?>" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">importe MOI</a>
                                            <input type="text" class="form-control"  placeholder="IMPORTE MOI*" name="Importe_MOI"  value="<?php echo $Importe_MOI; ?>"/>
                                        </div>

                                        <div class="form-group">
                                        <a aling="left">Moneda</a>
                                            <input type="text" class="form-control"  placeholder="MONEDA*" name="Moneda" value="<?php echo $Moneda; ?>" />
                                        </div>
                                        
                                        <div class="form-group">
                                        <a aling="left">Factura</a>
                                            <input type="text"  class="form-control" placeholder="FACTURA *" name="Factura" value="<?php echo $Factura; ?>" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text"  class="form-control" placeholder="REGISTRO CONTABLE*" name="Registro_Contable" value="<?php echo $Registro_Contable; ?>" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Estatus</a>
                                            <input type="text"  class="form-control" placeholder="ESTATUS*" name="Estatus" value="<?php echo $Estatus; ?>" />
                                        </div>
                                       
                                        <div class="form-group">
                                        <a aling="left">Sociedad</a>
                                            <select class="form-control" name="Sociedad" value="<?php echo $Sociedad; ?>">
                                            
                                                <option>MX30</option>
                                                <option>MX20</option>
                                              
                                            </select>
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Razon Social</a>
                                            <select class="form-control" name="Razon_Social" value="<?php echo $Sociedad; ?>">
                                           
                                                <option>DILASA</option>
                                                <option>DELESA</option>
                                              
                                            </select>
                                        </div>
                                     
                                                                              
                                       
                                           
                                        <a href="activosma.php" class="btn btn-danger"  role="button" aria-pressed="true">ATRAS</a>                            
                                        <button type="submit"class="btn btn-success" name="update">GUARDAR</button>
                                        
                                    </div>
                                </div>
                            </div>

         




         </form>

        </div>  
    </div>  
</div>






























<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<