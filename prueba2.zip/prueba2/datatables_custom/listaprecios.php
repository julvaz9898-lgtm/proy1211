<?php
 include("conexionsql.php");




//echo '<a href="logout.php">Cerrar Sesión</a>';
?><!--FIN -->





<!--BIENVENIDA-->





<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="#" />  
    <title>REPORTE LISTA DE PRECIOS</title>
      
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- CSS personalizado --> 
    <link rel="stylesheet" href="main.css">  
    <link rel="stylesheet" href="vista.css">
    <link rel="stylesheet" href="nav.css">  
      
    <!--datables CSS básico-->
    <link rel="stylesheet" type="text/css" href="datatables/datatables.min.css"/>
    <!--datables estilo bootstrap 4 CSS-->  
    <link rel="stylesheet"  type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
           
    <!--font awesome con CDN-->  
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">  
      
  </head>
  <h2>REPORTE LISTA DE PRECIOS</h2>
  

 <!--<?php if (isset($_SESSION['message'])) { ?>
     <div class="alert alert-<?= $_SESSION['message_type']?> alert-dismissible fade show" role="alert">
        <?= $_SESSION['message']?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
     
      </div>
      <?php } ?>-->  




 
  
 
  <body> 
       
    <div style="height:50px"></div>
     
    <!-- tabla con DataTables-->
    <div class="container">
        <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">        
                        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                            <th>FIN_VALIDEZ</th>
                            <th>INI_VALIDEZ</th>
                            <th>CODIGO_LACTALIS</th> 
                            <th>DESCRIPCION_LACTALIS</th>
                            <th>Precioxpieza</th>
                            <th>IMPORTE</th> 
                            <th>MONEDA</th> 
                            <th>GRUPO</th> 
                            <th>PORC_DESCU</th>
                            <th>CADENA</th>
                            <th>CANAL</th>
                            <th>SUBCANAL</th> 
                            <th>CLAS_CONDI_DESCU</th> 
                            <th>CLAS_CONDI</th> 
                            <th>CLIENTE</th>
                            <th>NOMBRECLIENTE</th>
                            <th>REG_CONDI</th>
                            <th>UNIDAD_BASE</th>
                            <th>UNIDAD_MEDIDA</th>  
                            <th>PESO_NET</th> 
                            <th>PiezasxCaja</th> 
                            <th>DESCUENTO_TOTAL </th>
                            <th>DEPARTAMENTO</th>
                            <th>DESC_DEPARTAMENTO</th>
                            <th>COMPAÑIA</th>
                            <th>IDNVAGRUPO</th>
                            <th>Right_IDNVAGRUPO</th>
                            
                           
                            
                             
                            </tr>
                        </thead>
                        <tbody>
                        <?php  



   $query="SELECT * FROM LISTA_PRECIOS  ";

   $Result=sqlsrv_query($conn2,$query);
   
   if ($Result==false){
    die(print_r(sqlsrv_errors(), true));
   }
   
   while($row=sqlsrv_fetch_array($Result)){?>

   <tr>  
 
          <td> <?= $row['FIN_VALIDEZ'] ?></td> 
          <td> <?= $row['INI_VALIDEZ'] ?></td> 
          <td> <?= $row['CODIGO_LACTALIS'] ?></td> 
          <td> <?= $row['DESCRIPCION_LACTALIS'] ?></td> 
          <td> <?= $row['Precioxpieza'] ?></td> 
          <td> <?= $row['IMPORTE'] ?></td>
          <td> <?= $row['MONEDA'] ?></td>
          <td> <?= $row['GRUPO'] ?></td>
          <td> <?= $row['PORC_DESCU'] ?></td>
          <td> <?= $row['CADENA'] ?></td> 
          <td> <?= $row['CANAL'] ?></td>
          <td> <?= $row['SUBCANAL'] ?></td>
          <td> <?= $row['CLAS_CONDI_DESCU'] ?></td>
          <td> <?= $row['CLAS_CONDI'] ?></td>
          <td> <?= $row['CLIENTE'] ?></td>
          <td> <?= $row['NOMBRECLIENTE'] ?></td>
          <td> <?= $row['REG_CONDI'] ?></td>
          <td> <?= $row['UNIDAD_BASE'] ?></td>
          <td> <?= $row['UNIDAD_MEDIDA'] ?></td>
          <td> <?= $row['PESO_NET'] ?></td>
          <td> <?= $row['PiezasxCaja'] ?></td>
          <td> <?= $row['[DESCUENTO_TOTAL ]'] ?></td>
          <td> <?= $row['DEPARTAMENTO'] ?></td>
          <td> <?= $row['DESC_DEPARTAMENTO'] ?></td>
          <td> <?= $row['COMPAÑIA'] ?></td>
          <td> <?= $row['IDNVAGRUPO'] ?></td>
          <td> <?= $row['Right_IDNVAGRUPO'] ?></td>
          

         
    

   </tr>

   <?php }?>


                        </tbody>        
                       </table>                  
                    </div>
                </div>
        </div>  
    </div>    
     
    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="jquery/jquery-3.3.1.min.js"></script>
    <script src="popper/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
      
    <!-- datatables JS -->
    <script type="text/javascript" src="datatables/datatables.min.js"></script>    
     
    <!-- para usar botones en datatables JS -->  
    <script src="datatables/Buttons-1.5.6/js/dataTables.buttons.min.js"></script>  
    <script src="datatables/JSZip-2.5.0/jszip.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/pdfmake.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
    <script src="datatables/Buttons-1.5.6/js/buttons.html5.min.js"></script>
     
    <!-- código JS propìo -->    
    <script type="text/javascript" src="main.js"></script>  
    <script type="text/javascript" src="navb.js"></script> 
    
    
  </body>
</html>
