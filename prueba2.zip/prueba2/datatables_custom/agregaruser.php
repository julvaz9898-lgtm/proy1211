<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />


<body>
<nav class="navbar navbar-ligth" style="background-color: #e3f2fd;">
    <div class="container">
    <a>
    <img src="images/logo_lactalis.jpg">
       
    <div>
    <a aling="rigth"class="navbar-brand ">INVENTARIO EQUIPO DE COMPUTO</a>
    
   
       
    </div>
</nav>


<div class="container p-4">
    <div class="row">
      <div class="col-md-9 register-right"> 
         <form action="guardaruser.php" method="POST" class="form-register" enctype="multipart/form-data">
         <p class="text-uppercase" >AGREGAR EQUIPO</p>
          
         <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
        
                                <div class="row register-form">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="numero de placa*" name="Num_placa" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="numero de serie*" name="Num_serie" />
                                        </div>
                                        <div class="form-group">
                                            <input type="date" class="form-control" placeholder="fecha *" name="Fecha" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="marca y modelo *" name="Marca" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="Puesto *" name="Puesto" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="Ubicación*" name="Ubicacion" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="Disco Duro*" name="Disco" />
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="area *" name="Area" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text"  class="form-control" placeholder="Nombre *" name="Nombre" />
                                        </div>
                                        <div class="form-group">
                                            <select class="form-control" name="Estado">
                                            <option class="hidden"  selected disabled>SELECCIONA UNA OPCION</option>
                                                <option>SI ESTA EN OPERACION</option>
                                                <option>NO OPERABLE</option>
                                                <option>OPTIMO PERO NO OPERABLE</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" name="Origen" class="form-control" placeholder="estaba en *"  />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" name="Destino" class="form-control" placeholder="se cambio a  *"  />
                                        </div>  
                                        <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="RAM*" name="RAM" />
                                        </div>     
                                        
                                       
                                           
                                        <a href="espaciouser.php" class="btn btn-danger"  role="button" aria-pressed="true">ATRAS</a>                            
                                        <button type="submit"class="btn btn-success" name="guardaruser">GUARDAR</button>
                                        
                                    </div>
                                </div>
                            </div>

         




         </form>

        </div>  
    </div>  
</div>











<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
