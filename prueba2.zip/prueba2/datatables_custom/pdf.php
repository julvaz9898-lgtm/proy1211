<?php
require('fpdf184/fpdf.php');
include("conexiondb.php");
if(isset($_GET['id'])){
    $id=$_GET['id'];
    $query="SELECT Nombre, Area, Num_Serie, Marca, Fecha_Entrega, Puesto, Num_Placa FROM activo_fijo WHERE id=$id";
    $Result=mysqli_query($conn,$query);
}



$pdf=new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',18);
while($row=mysqli_fetch_array($Result)){
$pdf->Cell(180,20,utf8_decode('Distribuidora de Lácteos Agil S.A de C.V.'),'0','1','C');


$pdf->SetFont('Arial','I',12);
$pdf->Cell(150, 5, utf8_decode("Fecha de Entrega"), 0, 1, 'R');
    $pdf->SetXY(3,30);
$pdf->Cell(180, 5,$row['Fecha_Entrega'], 0, 1, 'R');
$pdf->Cell(100, 5, "", 0, 1, 'L');



$pdf->SetFont('Arial','I',11);
$pdf->Cell(90, 5, utf8_decode("Por este conducto declaro recibir el equipo de cómputo que en adelante se detalla"), 0, 1, 'L');
$pdf->Cell(90, 5, utf8_decode(" a mi entera satisfacción."), 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');



$pdf->SetFont('Arial','I',12);
    $pdf->Cell(90, 5, utf8_decode("Marca:"), 0, 1, 'L');
    $pdf->SetXY(23,55);
    $pdf->Cell(100, 5,$row['Marca'], 0, 1, 'L');
    $pdf->Cell(100, 2, "", 0, 1, 'L');
    $pdf->Cell(90, 5, utf8_decode("Numero de Serie:"), 0, 1, 'L');
    $pdf->SetXY(43,62);
    $pdf->Cell(100, 5,$row['Num_Serie'], 0, 1, 'L');
    $pdf->Cell(90, 5, utf8_decode("Numero de Placa:"), 0, 1, 'L');
    $pdf->SetXY(44,67);
    $pdf->Cell(100, 5,$row['Num_Placa'], 0, 1, 'L');


$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');



$pdf->SetFont('Arial','I',12);
$pdf->Cell(89, 5, utf8_decode("Area:"), 0, 1, 'L');
$pdf->SetXY(21,82);
$pdf->Cell(100, 5,utf8_decode($row['Area']), 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->SetFont('Arial','I',11);


$pdf->Cell(100, 5, "", 0, 1, 'L');



$pdf->SetFont('Arial','I',11);
$pdf->Cell(100, 5,utf8_decode("Reconozco que este equipo es propiedad de LACTALIS MEXICO"), 0, 1, 'L');
$pdf->Cell(100, 5, " y se me entrega como prestamo para cubrir y facilitar mis actividades LABORALES", 0, 1, 'L');
$pdf->Cell(100, 5, utf8_decode(""), 0, 1, 'L');

$pdf->SetFont('Arial','I',11);
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, utf8_decode("Quedo como único y exclusivo responsable del resguardo de dicho equipo, así como el uso"), 0, 1, 'L');
$pdf->Cell(100, 5, "adecuado del mismo.", 0, 1, 'L');
$pdf->Cell(100, 5,utf8_decode("Es de mi conocimiento y conformidad que el departamento de SISTEMAS DE INFORMACIÓN podrá"), 0, 1, 'L');
$pdf->Cell(100, 5,utf8_decode("disponer del equipo así como de sus accesorios a que se refiere la presente en el momento que se"), 0, 1, 'L');
$pdf->Cell(100, 5, utf8_decode("requiera, ya sea para una nueva asignación, reasignación, auditoria del equipo o por cambio de "), 0, 1, 'L');
$pdf->Cell(100, 5,utf8_decode("funciones que e suscrito tiene que desarrollar o desempeñar, por retiro del grupo corporativo o decisión"), 0, 1, 'L');
$pdf->Cell(100, 5,utf8_decode("administrativa del propiretario haciéndome RESPONSABLE DE SU CUIDADO Y BUEN USO hasta el "), 0, 1, 'L');
$pdf->Cell(100, 5, "momento que se realice cualquiera de los supuestos que se mencionan y hasta que formalmente haga", 0, 1, 'L');
$pdf->Cell(100, 5, "entrega del mismo con todos y cada uno de sus accesorios.", 0, 1, 'L');



$pdf->Cell(100, 5, "En caso de:", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');

$pdf->SetFont('Arial','I',11);
$pdf->Cell(180,6,utf8_decode('1.- Daño de fabrica: Se repondrá el equipo sin ningún costo'),'0','1','C');
$pdf->Cell(180,6,utf8_decode('2.- Mal uso del funcionario: El beneficiario deberá asumir el'),'0','1','C');
$pdf->Cell(120,6,utf8_decode('              costo 100% de la reposición.'),'0','1','C');
$pdf->Cell(195,6,utf8_decode('3.- Robo: El beneficiario deberá presentar su denuncia correspondiente.'),'0','1','C');
$pdf->Cell(100, 5, "", 0, 1, 'L');

$pdf->SetFont('Arial','I',11);
$pdf->Cell(100, 5,utf8_decode( "Habiendo leído y estando de acuerdo en el contenido y consecuencias legales de la siguiente carta"), 0, 1, 'L');
$pdf->Cell(100, 5, utf8_decode("responsiva de asignación de equipo y sus accesorios lo firmo en la ciudad de MÉXICO."), 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->SetFont('Arial','B',11);
$pdf->Cell(100, 5, "Tickets: soporte.its@lactalis.com.mx", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 10, "", 0, 1, 'L');
$pdf->Cell(100, 10, "", 0, 1, 'L');

$pdf->SetFont('Arial','I',11);
$pdf->Cell(180,6,utf8_decode($row['Nombre']), 0, 1, 'C');
$pdf->Cell(180,6,'______________________________','0','1','C');
$pdf->Cell(180, 5, utf8_decode($row['Puesto']), 0, 1, 'C');


}

$pdf->Output('prueba.pdf','I');
$pdf->Output();
?>

