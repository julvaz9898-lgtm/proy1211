<?php include("conexiondb.php");



?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="#" />  
    <title>CHILE</title>
      
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- CSS personalizado --> 
    <link rel="stylesheet" href="main.css">  
    <link rel="stylesheet" href="vista.css">
      
    <!--datables CSS básico-->
    <link rel="stylesheet" type="text/css" href="datatables/datatables.min.css"/>
    <!--datables estilo bootstrap 4 CSS-->  
    <link rel="stylesheet"  type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
           
    <!--font awesome con CDN-->  
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">  
      
  </head>
  
  <nav class="navbar navbar-ligth" style="background-color: #e3f2fd;">
    <div class="container">
    <a href="">
    <img src="images/logo_lactalis.jpg">
       
    <div>
    <a aling="rigth" href=""class="navbar-brand "> EQUIPO DE COMPUTO REGION CHILE</a>
    
   
       
    </div>
</nav>

<div class="container p-4">
  <div class="row">
      <div class="pull-right">    
      
      <a href="sanulac.php" class="btn btn-danger"  role="button" aria-pressed="true">ATRAS</a>
      </div>
    </div>
  </div>

  <?php if (isset($_SESSION['message'])) { ?>
      <div class="alert alert-<?= $_SESSION['message_type']?> alert-dismissible fade show" role="alert">
        <?= $_SESSION['message']?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
     
      </div>
      <?php session_unset(); } ?>

 
  <body> 
       
    <div style="height:50px"></div>
     
    <!-- tabla con DataTables-->
    <div class="container">
        <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">        
                        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="75%">
                        <thead>
                            <tr>
                            <th>Nombre</th>
                            <th>Area</th>
                            <th>Numero de serie</th> 
                            <th>Numero de PLaca</th>
                            <th>Ubicación</th>
                            <th>Marca</th>
                            
                            </tr>
                        </thead>
                        <tbody>
                        <?php  



  
$query="SELECT * FROM activo_fijo_sanulac WHERE Ubicacion='Ecuador'";

   $Result=mysqli_query($conn,$query);
   
   while($row=mysqli_fetch_array($Result)){?>

   <tr>  
 
          <td> <?= $row['Nombre'] ?></td> 
          <td> <?= $row['Area'] ?></td> 
          <td> <?= $row['Num_Serie'] ?></td> 
          <td> <?= $row['Num_Placa'] ?></td> 
          <td> <?= $row['Ubicacion'] ?></td> 
          <td> <?= $row['Marca'] ?></td> 
           
   </tr>

   <?php }?>


                        </tbody>        
                       </table>                  
                    </div>
                </div>
        </div>  
    </div>    
     
    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="jquery/jquery-3.3.1.min.js"></script>
    <script src="popper/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
      
    <!-- datatables JS -->
    <script type="text/javascript" src="datatables/datatables.min.js"></script>    
     
    <!-- para usar botones en datatables JS -->  
    <script src="datatables/Buttons-1.5.6/js/dataTables.buttons.min.js"></script>  
    <script src="datatables/JSZip-2.5.0/jszip.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/pdfmake.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
    <script src="datatables/Buttons-1.5.6/js/buttons.html5.min.js"></script>
     
    <!-- código JS propìo-->    
    <script type="text/javascript" src="main.js"></script>  
    
    
  </body>
</html>
<?php 

 

?>