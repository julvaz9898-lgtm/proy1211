<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<body>
<nav class="navbar navbar-ligth" style="background-color: #e3f2fd;">
    <div class="container">
    <a href="index.php">
    <img src="images/logo_lactalis.jpg">
       
    <div>
    <a aling="rigth" href="index.php"class="navbar-brand "></a>
    
   
       
    </div>
</nav>

<?php include("conexiondb.php");


if(isset($_GET['Id'])){
    $id=$_GET['Id'];
    $query= "SELECT * FROM colaboradores WHERE Id=$id";
    $result=mysqli_query($conn,$query);
    if(mysqli_num_rows($result)==1){
        $row = mysqli_fetch_array($result);
        $Num_Emp=$row['Num_Emp'];
        $Area=$row['Area'];
        $Nombre=$row['Nombre'];
        $Puesto=$row['Puesto'];
        $Ubicacion=$row['Ubicacion'];
        

    }
}


if (isset($_POST['updatec'])) {
    $id = $_GET['Id'];
    $Num_Emp=$_POST['Num_Emp'];
    $Nombre=$_POST['Nombre'];
    $Area=$_POST['Area'];
    $Puesto=$_POST['Puesto'];
    $Ubicacion=$_POST['Ubicacion'];





$queryup = "UPDATE colaboradores set Num_Emp = '$Num_Emp',Nombre='$Nombre', Area = '$Area',Puesto='$Puesto' ,Ubicacion='$Ubicacion' WHERE Id=$id";
$Result=mysqli_query($conn, $queryup);
if(!$Result){
    die("fail");}

$_SESSION['message'] = 'Actualizado correctamente';
$_SESSION['message_type'] = 'warning';;
header('Location: colaboradores.php');  

  }



?>

<div class="container p-4">
    <div class="row">
      <div class="col-md-9 register-right"> 
         <form action="editcolab.php?Id=<?php echo $_GET['Id']; ?>" method="POST" class="form-register" >
         <p class="text-uppercase" >EDITAR INFORMACION</p>
          
         <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
        
                                <div class="row register-form">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Numero de Empleado*" name="Num_Emp" value="<?php echo $Num_Emp; ?>" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Nombre*" name="Nombre" value="<?php echo $Nombre;?>" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Area*" name="Area" value="<?php echo $Area;?>" />
                                        </div>
                                                                  
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Puesto *" name="Puesto" value="<?php echo $Puesto;?>" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text"  class="form-control" placeholder="Ubicación*" name="Ubicacion" value="<?php echo $Ubicacion;?>" />
                                        </div>
                                        

                                       
                                        
                                        
                                        <a href="colaboradores.php" class="btn btn-danger"  role="button" aria-pressed="true">ATRAS</a>
                                        <button type="submit"class="btn btn-success" name="updatec">GUARDAR CAMBIOS</button>
                                        
                                    </div>
                                </div>
                            </div>

         




         </form>

        </div>  
    </div>  
</div>






























<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
