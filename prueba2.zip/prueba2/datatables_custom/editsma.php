<?php
 include("conexiondb.php");

 

 $Username=$_SESSION['Username'];
 
 




?>


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<body>
<nav class="navbar navbar-ligth" style="background-color: #e3f2fd;">
    <div class="container">
    <a href="index.php">
    <img src="images/logo_lactalis.jpg">
       
    <div>
    <a aling="rigth" href="index.php"class="navbar-brand ">EDITA EL INVENTARIO EQUIPO DE COMPUTO</a>
    
   
       
    </div>
</nav>

<?php include("conexiondb.php");
if(isset($_GET['id'])){
    $id=$_GET['id'];
    $query= "SELECT * FROM activo_fijo WHERE id=$id";
    $result=mysqli_query($conn,$query);
    if(mysqli_num_rows($result)==1){
        $row = mysqli_fetch_array($result);
        $Num_placa=$row['Num_Placa'];
            $Num_serie=$row['Num_Serie'];
            $Fecha=$row['Fecha'];
            $Marca=$row['Marca'];
        $Area=$row['Area'];
        $Nombre=$row['Nombre'];
        $Estado=$row['Estado'];
        $Origen=$row['Origen'];
        $Destino=$row['Destino'];
        $Puesto=$row['Puesto'];
        $Ubicacion=$row['Ubicacion'];
        $RAM=$row['RAM'];
        $Disco=$row['Disco'];
        $imagen=$row['IMG'];
        $Fecha_Entrega=$row['Fecha_Entrega'];
    }
}


if (isset($_POST['updatesma'])) {
    $id = $_GET['id'];
    $Num_placa=$_POST['Num_Placa'];
$Num_serie=$_POST['Num_Serie'];
$Fecha=$_POST['Fecha'];
$Marca=$_POST['Marca'];
$Area=$_POST['Area'];
$Nombre=$_POST['Nombre'];
$Origen=$_POST['Origen'];
$Destino=$_POST['Destino'];
$Puesto=$_POST['Puesto'];
$Estado=$_POST['Estado'];
$Ubicacion=$_POST['Ubicacion'];
$RAM=$_POST['RAM'];
$Disco=$_POST['Disco'];
$Fecha_Entrega=$_POST['Fecha_Entrega'];

$queryup = "UPDATE activo_fijo set Nombre = '$Nombre', Area = '$Area',Estado='$Estado',Destino='$Destino',Origen='$Origen', 
Marca='$Marca',Num_Placa='$Num_placa',Num_Serie='$Num_serie',Fecha='$Fecha',Puesto='$Puesto' ,Ubicacion='$Ubicacion' ,RAM='$RAM' ,Disco='$Disco' , Fecha_Entrega='$Fecha_Entrega' WHERE id=$id";
mysqli_query($conn, $queryup);
$_SESSION['message'] = 'Actualizado correctamente';
$_SESSION['message_type'] = 'warning';;
header('Location: espaciouser.php');  
  }



?>

<div class="container p-4">
    <div class="row">
      <div class="col-md-9 register-right"> 
         <form action="editsma.php?id=<?php echo $_GET['id']; ?>" method="POST" class="form-register" >
         <p class="text-uppercase" >EDITAR INFORMACION</p>
          
         <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
        
                                <div class="row register-form">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                        <a aling="left">Num. Placa</a>
                                            <input type="text" class="form-control" placeholder="numero de placa*" name="Num_Placa" value="<?php echo $Num_placa; ?>" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Num. Serie</a>
                                            <input type="text" class="form-control" placeholder="numero de serie*" name="Num_Serie" value="<?php echo $Num_serie;?>" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Fecha de registro</a>
                                            <input type="date" class="form-control"  placeholder="fecha *" name="Fecha" value="<?php echo $Fecha;?>" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Marca y Modelo</a>
                                            <input type="text" class="form-control"  placeholder="marca *" name="Marca" value="<?php echo $Marca;?>" /> 
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Puesto</a>
                                            <input type="text" class="form-control"  placeholder="Puesto*" name="Puesto" value="<?php echo $Puesto;?>" /> 
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Ubicación</a>
                                            <select  class="form-control" name="Ubicacion" value="<?php echo $Ubicacion;?>" >
                                            <option><?php echo $Ubicacion;?></option>
                                            <option>INSTITUTO</option>
                                                <option>SMA</option>
                                                <option>GDG</option>
                                                <option>MTY</option>
                                                <option>ICI</option>
                                                <option>CANCUN</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Disco Duro</a>
                                            <input type="text" class="form-control"  placeholder="Disco duro*" name="Disco" value="<?php echo $Disco;?>" /> 
                                        </div>
                                        
                                        
                                        <a href="cambio.php?id=<?php echo $row['id']?>" class="btn btn-secondary" target="_blank"> 
                                        <i class="fas fa-marker" >Autorización para Traslado</i>
                                     </a>
                                     <div class="form-group">
                                           
                                        </div>
                                     
                                     <a href="pdf.php?id=<?php echo $row['id']?>" class="btn btn-secondary" target="_blank"> 
                                        <i class="fas fa-marker" >Generar Responsiva</i>
                                     </a>
                                        
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                        <a aling="left">Area</a>
                                         <select  class="form-control" name="Area" value="<?php echo $Area;?>" >
                                            <option><?php echo $Area;?></option>
                                            <option>ADMON VENTAS</option>
                                                <option>COMPRAS</option>
                                                <option>CONTABILIDAD</option>
                                                <option>CONTRALORIA</option>
                                                <option>CDG</option>
                                                <option>FINANZAS</option>
                                                <option>IMPUESTOS</option>
                                                <option>LOGISTICA</option>
                                                <option>MKT</option>
                                                <option>RECURSOS HUMANOS</option>
                                                <option>SISTEMAS</option>
                                                <option>STOCK</option>
                                                  <option>AMP</option>
                                                  <option>RECIBO DE LECHE</option>
                                                  <option>SUEROS</option>
                                                   <option>FRESCOS</option>
                                                    <option>STRING</option>
                                                     <option>REFACCIONES</option>
                                                      <option>MANTENIMIENTO</option>
                                                      <option>CALIDAD</option>
                                                      <option>MESA DE CONTROL</option>
                                                      <option>MADUROS</option>
                                                      <option>CUAJADOS</option>
                                                      <option>SERVICIO MEDICO</option>

                                                
                                                
                                            </select>   
                                    </div>
                                        <div class="form-group">
                                        <a aling="left">Nombre</a>
                                            <input type="text"  class="form-control" placeholder="Nombre *" name="Nombre" value="<?php echo $Nombre;?>" />
                                        </div>
                                        <div class="form-group"> <a aling="left">Estado</a>
                                            <select  class="form-control" name="Estado" value="<?php echo $Estado;?>" >
                                            <option><?php echo $Estado;?></option>
                                                <option >SI ESTA EN OPERACION</option>
                                                <option>NO OPERABLE</option>
                                                <option>OPTIMO PERO NO OPERABLE</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Estaba en:</a>
                                            <input type="text" name="Origen" class="form-control" placeholder="estaba en *" value="<?php echo $Origen;?>"  />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Se Cambio a:</a>
                                            <input type="text" name="Destino" class="form-control" placeholder="se cambio a  *" value="<?php echo $Destino;?>" />
                                        </div> 
                                        <div class="form-group">
                                        <a aling="left">Ram</a>
                                            <input type="text" name="RAM" class="form-control" placeholder="RAM  *" value="<?php echo $RAM;?>" />
                                        </div> 
                                        <div class="form-group">
                                        <a aling="left">Fecha de Entrega</a>
                                            <input type="date" name="Fecha_Entrega" class="form-control" placeholder="Fecha Entrega  *" value="<?php echo $Fecha_Entrega;?>" />
                                        </div>

                                       <img src= <?php echo $imagen ?>>

                                       
                                        
                                        
                                        <a href="espaciouser.php" class="btn btn-danger"  role="button" aria-pressed="true">ATRAS</a>
                                        <button type="submit"class="btn btn-success" name="updatesma">GUARDAR CAMBIOS</button>
                                        
                                    
                                    </div>
                                    
                                </div>
                            </div>
         </form>

        </div>  
    </div>  
</div>






























<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
