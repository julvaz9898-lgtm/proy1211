<?php include("conexiondb.php");

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}


?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="#" />  
    <title>Tutorial DataTables</title>
      
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- CSS personalizado --> 
    <link rel="stylesheet" href="main.css">  
    <link rel="stylesheet" href="vista.css">
      
    <!--datables CSS básico-->
    <link rel="stylesheet" type="text/css" href="datatables/datatables.min.css"/>
    <!--datables estilo bootstrap 4 CSS-->  
    <link rel="stylesheet"  type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
           
    <!--font awesome con CDN-->  
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">  
      
  </head>


  <body>
  
  


<div class="container p-4">
<?php  include("navegation3.php") ?>
  <div class="row">
      <div class="pull-right">
      
      <a href="index.php" class="btn btn-danger"  role="button" aria-pressed="true">ATRAS</a>
      </div>
    </div>
  </div>
  
  

  <?php if (isset($_SESSION['message'])) { ?>
      <div class="alert alert-<?= $_SESSION['message_type']?> alert-dismissible fade show" role="alert">
        <?= $_SESSION['message']?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
     
      </div>
      <?php  } ?>


  
 
  <body> 
       
    <div style="height:50px"></div>
     
    <!-- tabla con DataTables-->
    <div class="container">
        <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">        
                        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="80%">
                        <thead>
                            <tr>
                            
                            <th>Modelo</th>
                           
                            <th>FECHA de compra</th>
                       

                            
                            
                            </tr>
                        </thead>
                        <tbody>
                        <?php  



   //$query="SELECT IDE,Marca,Modelo,Names,Model,Fech_Compra,Orden_Compra	 FROM marc_model INNER JOIN facturas ON marc_model.Modelo=facturas.Model";
   $query="SELECT * FROM facturas";
   $Result=mysqli_query($conn,$query);
   
   while($row=mysqli_fetch_array($Result)){?>

   <tr>  
   
          
    
          <td> <?= $row['Model'] ?></td> 


          <!-- <td> <a href="descargafactura.php?IDE=<?php echo $row['IDE']?>" class="btn btn-secondary"> 
          <i >DESCARGAR</i>
          </a></td> -->

          <td> <?= $row['Fech_Compra'] ?></td> 
         
          

          
          

   </tr>
 
   <?php }?>


                        </tbody>        
                       </table>                  
                    </div>
                </div>
        </div>  
    </div>    
     
    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="jquery/jquery-3.3.1.min.js"></script>
    <script src="popper/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
      
    <!-- datatables JS -->
    <script type="text/javascript" src="datatables/datatables.min.js"></script>    
     
    <!-- para usar botones en datatables JS -->  
    <script src="datatables/Buttons-1.5.6/js/dataTables.buttons.min.js"></script>  
    <script src="datatables/JSZip-2.5.0/jszip.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/pdfmake.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
    <script src="datatables/Buttons-1.5.6/js/buttons.html5.min.js"></script>
     
    <!-- código JS propìo-->    
    <script type="text/javascript" src="main.js"></script>  
    
    
  </body>
</html>
