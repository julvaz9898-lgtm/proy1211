<?php 
include("conexiondb.php");
$Username=$_SESSION['Username'];


if(isset($_POST['guardaractivosma'])){
  $Mes=$_POST['Mes'];
  $Fecha_Adquisicion=$_POST['Fecha_Adquisicion'];
  $Ubicacion=$_POST['Ubicacion'];
  $Area=$_POST['Area'];
  $Ceco=$_POST['CeCo'];
  $Responsable=$_POST['Responsable'];
  $Descripcion_Bien=$_POST['Descripcion_Bien'];
  $Marca=$_POST['Marca'];
  $Numero_de_serie=$_POST['Numero_de_serie'];
  $Modelo=$_POST['Modelo'];
  $Num_de_placa=$_POST['Num_de_placa'];
  $Cantidad=$_POST['Cantidad'];
  $Importe_MOI=$_POST['Importe_MOI'];
  $Moneda=$_POST['Moneda'];
  $Factura=$_POST['Factura'];
  $Registro_Contable=$_POST['Registro_Contable'];
  $Estatus=$_POST['Estatus'];
  $Sociedad=$_POST['Sociedad'];
  $Razon_Social=$_POST['Razon_Social'];
  $Ano=$_POST['Ano'];

  $query="INSERT INTO activo_sma(Mes,Fecha_Adquisicion,Ubicacion,Area,CeCo,Responsable,Descripcion_Bien,Marca,Modelo,Numero_de_serie,Num_de_placa,Cantidad,Importe_MOI,Moneda,Factura,Registro_Contable,Estatus,Sociedad,Razon_Social,Ano)
  VALUES ('$Mes','$Fecha_Adquisicion','$Ubicacion','$Area','$Ceco','$Responsable','$Descripcion_Bien','$Marca','$Modelo','$Numero_de_serie','$Num_de_placa','$Cantidad','$Importe_MOI','$Moneda','$Factura','$Registro_Contable','$Estatus','$Sociedad','$Razon_Social','$Ano')";

  $Result=mysqli_query($conn,$query);

  if(!$Result){
    die("fail");
}else{ echo'guardado';
}


$_SESSION['message']='GUARDADO';
$_SESSION['message_type']='success';
header("location:activosma.php");

}

?>
