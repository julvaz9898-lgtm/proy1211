<?php 
include("conexiondb.php");

if(isset($_FILES['image'])){
  $file=$_FILES['image'];

    
    





    $_SESSION['message']='GUARDADO';
    $_SESSION['message_type']='success';
  header("location:areas.php");

}
