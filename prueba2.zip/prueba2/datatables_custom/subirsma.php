<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />


<body>
<nav class="navbar navbar-ligth" style="background-color: #e3f2fd;">
    <div class="container">
    <a>
    <img src="images/logo_lactalis.jpg">
       
    <div>
    <a aling="rigth" class="navbar-brand ">MODELO Y FACTURA</a>
    
   
       
    </div>
</nav>


<div class="container p-4">
    <div class="row">
      <div class="col-md-9 register-right"> 
         <form action="savefoto.php" method="POST" class="form-register" enctype="multipart/form-data">
         <p class="text-uppercase" >AGREGAR FOTO </p>
          
         <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
        
                        
                                    
         <style>
             #preview {
               width: 100%;
               height: auto;}
         </style>

                                <video id="preview"></video>
                            

                                       
                                        
                                       
                                      
                                           
                                        <a href="activosma.php" class="btn btn-danger"  role="button" aria-pressed="true">ATRAS</a>                            
                                        <button type="submit"class="btn btn-success" name="savefactura" id="capture-btn">GUARDAR</button>
                                        
                                    </div>
                                </div>
                            </div>

         




         </form>

        </div>  
    </div>  
</div>


























<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="camara.js"></script> 
