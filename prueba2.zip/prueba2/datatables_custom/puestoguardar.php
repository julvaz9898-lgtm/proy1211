<?php 
include("conexiondb.php");

if(isset($_POST['savepuesto'])){
    $Puesto=$_POST['Puesto'];
    $Area=$_POST['Area'];
    
     $query= "INSERT INTO puestos (Puesto,Area)
              VALUES('$Puesto','$Area')";

              $Result=mysqli_query($conn,$query);

              if(!$Result){
                  die("fail");
              }

              echo'guardado';


    $_SESSION['message']='GUARDADO';
    $_SESSION['message_type']='success';
  header("location:puestos.php");

}