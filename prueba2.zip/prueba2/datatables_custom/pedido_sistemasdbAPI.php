<?php
header('Content-Type: application/json');

// Configuración de la base de datos
$conn = mysqli_connect(
    'localhost',
    'root',
    '',
    'inventario'
);

// Verifica la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta para obtener los pedidos
$sql = "SELECT * FROM antiguedad where Area='sistemas' and Anos>=3";
$result = $conn->query($sql);

$orders= array();

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
    echo json_encode($orders);
} else {
    http_response_code(500);
    echo json_encode(array("error" => "Error en la consulta: " . $conn->error));
}

$conn->close();
?>
