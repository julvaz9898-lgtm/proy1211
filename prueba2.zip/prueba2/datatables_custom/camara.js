

if ('mediaDevices' in navigator && 'getUserMedia' in navigator.mediaDevices) {
	console.log("Let's get this party started")
  }else{console.log("mal")}


const videoElement = document.getElementById('preview');
    const captureButton = document.getElementById('capture-btn');

    // Acceder a la cámara del dispositivo
    navigator.mediaDevices.getUserMedia({ video: true })
      .then(function (stream) {

		
        // Asignar el stream de la cámara al elemento de video
        videoElement.srcObject = stream;
        videoElement.play();
      })
      .catch(function (error) {
        console.error('Error al acceder a la cámara:', error);
      });


    // Manejar el evento de captura de foto
    captureButton.addEventListener('click', function () {
		const canvas = document.createElement('canvas');
		canvas.width = videoElement.videoWidth;
		canvas.height = videoElement.videoHeight;
		canvas.getContext('2d').drawImage(videoElement, 0, 0, canvas.width, canvas.height);
  
		// Convertir la imagen del lienzo a un archivo de imagen (formato JPEG)
		canvas.toBlob(function (blob) {
		  // Crear una URL del objeto Blob para mostrar la imagen en el elemento img
		  const imageURL = URL.createObjectURL(blob);
  
		  // Crear un objeto FormData para enviar la imagen al servidor
		  const formData = new FormData();
		  formData.append('image', blob, 'foto.jpg');
  
		  // Enviar la imagen al servidor mediante una solicitud AJAX o un formulario
		  // Aquí puedes usar PHP para procesar y guardar la imagen en la base de datos
		  // Por ejemplo, puedes enviarla mediante una solicitud AJAX utilizando la biblioteca Axios
  
		  // Ejemplo de código para enviar la imagen utilizando Axios
		  axios.post('procesarimg.php', formData)
			.then(function (response) {
			  console.log('Imagen enviada y guardada en la base de datos');
			})
			.catch(function (error) {
			  console.error('Error al enviar la imagen:', error);
			});
  
		  // Liberar la URL del objeto Blob después de mostrar la imagen
		  URL.revokeObjectURL(imageURL);
		}, 'image/jpeg');
	  });