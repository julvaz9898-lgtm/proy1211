<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>    
        <link rel="stylesheet" href="vista.css">
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>  
    
    <title>CREADOR DE USUARIOS</title>

</head>

<body>
<nav class="navbar navbar-ligth" style="background-color: #e3f2fd;">
    <div class="container">
    <img src="images/logo_lactalis.jpg">
</nav>


<div class="wrapper fadeInDown">
  <div id="formContent">
  


    <!--Login-->
    <div class="login">
			<h3>CREAR USUARIO</h3>
			<form action="creacion.php" method="POST">
				<input type="text" placeholder="usuario" name="Username" required>
				<input type="password" placeholder="Contraseña" name="Pass" required>
				<input name="crear" type="submit" value="Crear">
			</form>
			<div class="clear"> </div>
				
			</div>
			
      <a href="index.php" class="btn btn-danger"  role="button" aria-pressed="true">ATRAS</a>

    

  </div>
</div>






















</html>