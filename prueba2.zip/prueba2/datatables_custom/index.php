<?php
 include("conexiondb.php");

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}


//echo "Bienvenido, " . $_SESSION['username'] . "!<br>";
//echo "Rol: " . $_SESSION['role'] . "<br>";

// if ($_SESSION['role'] == 'admin') {
 //   echo '<a href="register.php" class="btn btn-outline-info btn-lg" >REGISTRAR NUEVO USUARIO</a><br>';-->
    
//}
 if ($_SESSION['username'] == 'sanulac') {
    echo '<a href="sanulac.php" class="btn btn-outline-info btn-lg" >INVENTARIO SANULAC</a><br>';


    
}

//echo '<a href="logout.php">Cerrar Sesión</a>';
?><!--FIN -->





<!--BIENVENIDA-->





<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="#" />  
    <title>INVENTARIO VALLEJO</title>
      
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- CSS personalizado --> 
    <link rel="stylesheet" href="main.css">  
    <link rel="stylesheet" href="vista.css">
    <link rel="stylesheet" href="nav.css">  
      
    <!--datables CSS básico-->
    <link rel="stylesheet" type="text/css" href="datatables/datatables.min.css"/>
    <!--datables estilo bootstrap 4 CSS-->  
    <link rel="stylesheet"  type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
           
    <!--font awesome con CDN-->  
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">  
      
  </head>
  <?php  include("navegation.php") ?>
  

 <!--<?php if (isset($_SESSION['message'])) { ?>
     <div class="alert alert-<?= $_SESSION['message_type']?> alert-dismissible fade show" role="alert">
        <?= $_SESSION['message']?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
     
      </div>
      <?php } ?>-->  

      <h2>BIENVENIDO USUARIO: <?php echo $_SESSION['username']; ?></h2>
<h2>ROL: <?php echo $_SESSION['role']; ?></h2>


      <div class="nav-side-menu">
    <div class="brand">CATALOGO</div>
    <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
  
        <div class="menu-list">
  
            <ul id="menu-content" class="menu-content collapse out">
                
            <li data-toggle="collapse" data-target="#products" class="collapsed">
                  <a href="#"><i ></i> SOLICITUD DE EQUIPO <span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="products">
                    <li><a target="_blank" href="admin.php">SISTEMAS</a></li>
                    <li><a target="_blank" href="admin2.php">CONTRALORIA</a></li>
                    <li><a  target="_blank" href="admin3.php">ADV</a></li>
                    <li><a  target="_blank" href="admin4.php">IMPUESTOS</a></li>
                    <li><a  target="_blank" href="admin5.php">TESORERIA</a></li>
                    <li><a target="_blank" href="admin6.php">CONTABILIDAD</a></li>
                    <li><a target="_blank" href="admin7.php">COMPRAS</a></li>
                    <li><a target="_blank" href="admin8.php">NOMINAS</a></li>
                    <li><a target="_blank" href="admin9.php">COMUNICACION</a></li>
                    <li><a target="_blank" href="admin10.php">RECLUTAMIENTO</a></li>
                    <li><a target="_blank" href="admin11.php">MKT</a></li>
                    <li><a target="_blank" href="admin12.php">CPFR</a></li>
                    <li><a target="_blank" href="admin13.php">KAMS</a></li>
                    <li><a target="_blank" href="admin14.php">BI</a></li>
                    <li><a target="_blank" href="admin15.php">MAYOREO</a></li>
                    <li><a target="_blank" href="admin16.php">CDG</a></li>
                    <li><a target="_blank" href="admin17.php">LOGISTICA</a></li>
                    <li><a target="_blank" href="admin18.php">FOOD SERVICE</a></li>
                </ul> 
            

             <!--   <li>
                  <a href="areas.php">
                  <i></i> AREAS
                  </a>
                </li> -->

                <!-- <li>
                  <a href="marcas.php">
                  <i></i> MARCAS
                  </a>
                </li>-->

                
                <li>
                  <a href="subir.php">
                  <i></i> SUBIR COMPRAS
                  </a>
                </li>

                <li>
                  <a href="descarga.php">
                  <i></i> VISUALIZAR COMPRAS
                  </a>
                </li>

              <!--  <li>
                  <a href="auditoria.php">
                  <i></i> AUDITORIA
                  </a>
                </li>-->

               <!--  <li>
                  <a href="all.php">
                  <i></i> BASE INVENTARIO
                  </a>
                </li>-->



                <li data-toggle="collapse" data-target="#service" class="collapsed">
                  <a href="#"><i ></i> UBICACION <span class="arrow"></span></a>
                </li>  
                <ul class="sub-menu collapse" id="service">
                  <li><a href="SMA.php">SMA</a></li>
                    <li><a href="instituto.php">INSTITUTO</a></li>
                    <li><a href="ICI.php">ICI</a></li>
                    <li><a href="cancun.php">CANCUN</a></li>
                    <li><a href="monterrey.php">MONTERREY</a></li>
                   <!--  <li><a href="GDL.php">GDL</a></li>-->
                  
          

                </ul>


                


            </ul>
     </div>
</div>
  
 
  <body> 
       
       <div style="height:50px"></div>
     
        <!-- tabla con DataTables-->
       <div class="container">
          <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">        
                        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                            <th>Nombre</th>
                            <th>Area</th>
                            <th>Numero de serie</th> 
                            <th>Num Placa</th>
                            <th>Marca</th>
                            <th>UBICACION</th> 
                            <th>ESTADO</th> 
                            <th>TIPO DE EQUIPO</th> 
                            <th>FECHA DE REGISTRO</th>
                            <th>Acciones</th> 
                           
                            
                             
                            </tr>
                        </thead>
                        <tbody>
                        <?php  


           if(!isset($_POST['buscar'])){
              $_POST['buscar']="";
           $buscar=$_POST['buscar'];
}
   $buscar=$_POST['buscar'];
   $query="SELECT * FROM activo_fijo WHERE Nombre LIKE'%".$buscar."%' OR Num_Serie LIKE '%".$buscar."%' OR Num_Placa LIKE '%".$buscar."%' OR Area LIKE '%".$buscar."%' ORDER BY Area ";

   $Result=mysqli_query($conn,$query);
   
   while($row=mysqli_fetch_array($Result)){?>

   <tr>  
 
          <td> <?= $row['Nombre'] ?></td> 
          <td> <?= $row['Area'] ?></td> 
          <td> <?= $row['Num_Serie'] ?></td> 
          <td> <?= $row['Num_Placa'] ?></td> 
          <td> <?= $row['Marca'] ?></td> 
          <td> <?= $row['Ubicacion'] ?></td>
          <td> <?= $row['Estado'] ?></td>
          <td> <?= $row['Tipo'] ?></td>
          <td> <?= $row['Fecha'] ?></td>
         
          <td> 
          <a href="edit.php?id=<?php echo $row['id']?>" class="btn btn-secondary"> 
          <i class="fas fa-marker"></i>
          </a>
          </td>

   </tr>

   <?php }?>


                        </tbody>        
                       </table>                  
                    </div>
                </div>
        </div>  
    </div>    
     
    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="jquery/jquery-3.3.1.min.js"></script>
    <script src="popper/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
      
    <!-- datatables JS -->
    <script type="text/javascript" src="datatables/datatables.min.js"></script>    
     
    <!-- para usar botones en datatables JS -->  
    <script src="datatables/Buttons-1.5.6/js/dataTables.buttons.min.js"></script>  
    <script src="datatables/JSZip-2.5.0/jszip.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/pdfmake.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
    <script src="datatables/Buttons-1.5.6/js/buttons.html5.min.js"></script>
     
    <!-- código JS propìo -->    
    <script type="text/javascript" src="main.js"></script>  
    <script type="text/javascript" src="navb.js"></script> 
    
    
  </body>
</html>
