<?php
require('fpdf184/fpdf.php');
include("conexiondb.php");
if(isset($_GET['id'])){
    $id=$_GET['id'];
    $query2="SELECT Area, Num_Serie, Marca, Fecha,Num_Placa FROM activo_fijo WHERE id=$id";
    $Result2=mysqli_query($conn,$query2) or die(mysqli_error($conn));
}

$pdf=new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',15);
while($row=mysqli_fetch_array($Result2)){
$pdf->Cell(190,20,utf8_decode('AF-06'),'0','1','R');


$pdf->SetFont('Arial','I',12);
$pdf->Cell(150, 5, utf8_decode("Ciudad de México a"), 0, 1, 'R');
    $pdf->SetXY(3,30);
$pdf->Cell(180, 5,$row['Fecha'], 0, 1, 'R');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');


$pdf->SetFont('Arial','B',11);
$pdf->Cell(190, 5, utf8_decode("AUTORZACIÓN PARA TRASLADO DE ACTIVO"), 0, 1, 'C');
$pdf->Cell(100, 5, "", 0, 1, 'L');


$pdf->SetFont('Arial','B',11);
$pdf->Cell(100, 5, utf8_decode("Por medio del presente se solicita la autorización del traslado del activo que a continuación se detalla."), 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');

$pdf->SetFont('Arial','I',12);
$pdf->Cell(100, 5,utf8_decode("° Descripción del Activo:"), 0, 1, 'L');
$pdf->SetXY(58,70);
$pdf->Cell(180, 5,$row['Marca'], 0, 1, 'L');
$pdf->Cell(100, 5,utf8_decode("° Numero de Serie:"), 0, 1, 'L');
$pdf->SetXY(46,75);
$pdf->Cell(180, 5,$row['Num_Serie'], 0, 1, 'L');
$pdf->Cell(100, 5,utf8_decode("°Numero de Placa:"), 0, 1, 'L');
$pdf->SetXY(46,80);
$pdf->Cell(180, 5,$row['Num_Placa'], 0, 1, 'L');




$pdf->Cell(100, 5,utf8_decode("° Fotos del Activo:"), 0, 1, 'L');   
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');




$pdf->SetFont('Arial','B',11);
$pdf->Cell(100, 5, utf8_decode("Ubicación actual del activo:"), 0, 1, 'L');
$pdf->SetXY(62,150);
$pdf->Cell(180, 5, utf8_decode("INSTITUTO"), 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, utf8_decode("Nueva ubicación del activo:"), 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->SetXY(62,160);
$pdf->Cell(100, 5, utf8_decode("BAJA"), 0, 1, 'L');

$pdf->Cell(100, 5, utf8_decode("Razón social a quien pertenece el activo:"), 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->SetXY(87,165);
$pdf->Cell(100, 5, utf8_decode("DILASA"), 0, 1, 'L');
$pdf->Cell(100, 5, utf8_decode("Motivo de traslado:"), 0, 1, 'L');
$pdf->SetXY(48,170);
$pdf->Cell(100, 5, utf8_decode("VENTA"), 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');

$pdf->Cell(180,6,'______________________________','0','1','L');
$pdf->Cell(180,6, utf8_decode('             AREA DE SISTEMAS'),'0','1','L');
$pdf->SetFont('Arial','B',11);
$pdf->Cell(180,6,'_________________________________','0','1','R');
$pdf->Cell(180,6, utf8_decode('AREA DE CONTABILIDAD'),'0','1','R');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(100, 5, "", 0, 1, 'L');
$pdf->Cell(210,6,'______________________________','0','1','C');
$pdf->Cell(210,6, utf8_decode('BENEFICIADO'),'0','1','C');




}


$pdf->Output('prueba.pdf','I');
?>