<html lang="en">
<head> 

  <!--css-->
<link rel="stylesheet" href="login.css">

          
    <!--boostrap-->  
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
</head>


<div class="wrapper">

        <div class="logo">
            <img src="IMG/Lactalis.png" alt="">
        </div>
        <div class="text-center mt-4 name">
            INVENTARIO DE EQUIPO DE COMPUTO
        </div>
        <form class="p-3 mt-3" method="POST" action="validacion.php">
            <div class="form-field d-flex align-items-center">
                <span class="far fa-user"></span>
                <input type="text" name="username"  placeholder="Username" >
            </div>
            <div class="form-field d-flex align-items-center">
                <span class="fas fa-key"></span>
                <input type="password" name="password" placeholder="Password" >
            </div>
            <button type="submit"class="btn btn-success" name="guardar">INICIAR SESION</button>
        </form>
       
    </div>


 <!--Login

<div class="wrapper fadeInDown">
  <div id="formContent">
  


   
      <form action="validacion.php" method="POST" >
      <input type="text" id="Username" class="form-control" name="Username" placeholder="USUARIO">
      <input type="password" id="Pass" class="form-control" name="Pass" placeholder="CONTRASEÑA">
      <input type="submit" class="fadeIn fourth" name="validar">
    </form>


    

			


    

  </div>
</div>





-->
















</html>