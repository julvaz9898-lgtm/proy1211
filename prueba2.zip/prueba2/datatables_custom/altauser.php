<?php 
include("conexiondb.php");

if(isset($_POST['alta'])){
    $Num_Emp=$_POST['Num_Emp'];
    $Nombre=$_POST['Nombre'];
    $Area=$_POST['Area'];
    $Puesto=$_POST['Puesto'];
    $Ubicacion=$_POST['Ubicacion'];
    
    
    
    


     $query= "INSERT INTO colaboradores(Num_Emp,Nombre,Area,Puesto,Ubicacion)
              VALUES('$Num_Emp','$Nombre', '$Area','$Puesto','$Ubicacion')";

              $Result=mysqli_query($conn,$query);

              if(!$Result){
                  die("fail");
              }

              echo'guardado';






    $_SESSION['message']='GUARDADO';
    $_SESSION['message_type']='success';
  header("location:colaboradores.php");

}



?>
