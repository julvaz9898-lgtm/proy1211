
<?php


include("conexiondb.php");

 
 
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}




?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />


    <?php  include("navegation2.php") ?>

       
    </div>
</nav>
    
<h2> USUARIO: <?php echo $_SESSION['username']; ?></h2>
<h2>ROL: <?php echo $_SESSION['role']; ?></h2>

<div class="container p-4">
    <div class="row">
      <div class="col-md-9 register-right"> 
         <form action="guardar.php" method="POST" class="form-register" enctype="multipart/form-data">
         <p class="text-uppercase" >AGREGAR EQUIPO</p>
          
         <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
        
                                <div class="row register-form">
                                    <div class="col-md-6">
                                    <a aling="left">NUM PLACA</a>
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="numero de placa*" name="Num_placa" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">NUM SERIE</a>
                                            <input type="text" class="form-control" placeholder="numero de serie*" name="Num_serie" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Fecha de Registro</a>
                                            <input type="date" class="form-control" placeholder="fecha *" name="Fecha" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Fecha de Registro</a>
                                            <input type="date" class="form-control" placeholder="fecha *" name="Fecha" />
                                        </div>
                                        
                                        <div class="form-group">
                                        <a aling="left">MARCA Y MODELO</a>
                                        <select class="form-control" name="Marca">
                                            <option class="hidden"  selected disabled>SELECCIONA UNA OPCION</option>
                                                <?php include ("option.php")?>
                                            </select>
                                            
                                        </div>
                                        
                                        <div class="form-group">
                                        <a aling="left">INTERCAMBIO</a>
                                            <input type="text" class="form-control"  placeholder="Puesto *" name="Puesto" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">ubicacion</a>
                                            <select class="form-control" name="Ubicacion">
                                            <option class="hidden"  selected disabled>SELECCIONA UNA OPCION</option>
                                                <option>INSTITUTO</option>
                                                <option>SANULAC</option>
                                                <option>SMA</option>
                                                <option>GDG</option>
                                                <option>MTY</option>
                                                <option>CANCUN</option>
                                                <option>ICI</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">DISCO</a>
                                            <input type="text" class="form-control"  placeholder="Disco Duro*" name="Disco" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Tipo De Equipo</a>
                                            <select class="form-control" name="Tipo">
                                            <option class="hidden"  selected disabled>SELECCIONA UNA OPCION</option>
                                                <option>CPU</option>
                                                <option>LAPTOP</option>
                                            </select>
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                        <a aling="left">AREA</a>
                                            <select class="form-control" name="Area">
                                            <option class="hidden"  selected disabled>SELECCIONA UNA OPCION</option>
                                                <option>ADMON VENTAS</option>
                                                <option>COMERCIAL</option>
                                                <option>COMPRAS</option>
                                                <option>CONTABILIDAD</option>
                                                <option>CONTRALORIA</option>
                                                <option>CDG</option>
                                                <option>DIRECCIÓN</option>
                                                <option>FINANZAS</option>
                                                <option>IMPUESTOS</option>
                                                <option>LOGISTICA</option>
                                                <option>MKT</option>
                                                <option>CPFR</option>
                                                <option>KAM</option>
                                                <option>BI</option>
                                                <option>MAYOREO</option>
                                                <option>FOOD SERVICE</option>
                                                <option>STOCK</option>
                                                <option>RECURSOS HUMANOS</option>
                                                <option>NOMINAS</option>
                                                <option>COMUNICACION</option>
                                                <option>RECLUTAMIENTO</option>
                                                <option>SISTEMAS</option>
                                                <option>TESORERIA</option>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group">
                                        <a aling="left">NOMBRE</a>
                                            <input type="text"  class="form-control" placeholder="Nombre *" name="Nombre" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">ESTATUS</a>
                                            <select class="form-control" name="Estado">
                                           
                                            <option class="hidden"  selected disabled>SELECCIONA UNA OPCION</option>
                                                <option>SI ESTA EN OPERACION</option>
                                                <option>NO OPERABLE</option>
                                                <option>OPTIMO PERO NO OPERABLE</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Estatus Crowstrike</a>
                                            <select class="form-control" name="Antiviruz">
                                            <option class="hidden"  selected disabled>SELECCIONA UNA OPCION</option>
                                                <option>ACTIVO</option>
                                                <option>INACTIVO</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">ORIGEN</a>
                                            <input type="text" name="Origen" class="form-control" placeholder="estaba en *"  />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">DESTINO</a>
                                            <input type="text" name="Destino" class="form-control" placeholder="se cambio a  *"  />
                                        </div>  
                                        <div class="form-group">
                                        <a aling="left">Fecha de Entrega</a>
                                            <input type="date" name="Fecha_Entrega" class="form-control" placeholder="Fecha de entrega  *"  />
                                        </div>  
                                        <div class="form-group">
                                        <a aling="left">MEMORIA</a>
                                            <input type="text" class="form-control"  placeholder="RAM*" name="RAM" />
                                        </div>  
                                        <div class="form-group">
                                        <a aling="left">EMAIL</a>
                                            <input type="email" class="form-control"  placeholder="EMAIL*" name="Email" />
                                        </div> 
                                        <div class="form-group">
                                        <a aling="left">COMENTARIO</a>
                                            <input type="text"  class="form-control"  placeholder="COMENTARIO*" name="Comentario" />
                                        </div>   
                                    
                                        
                                       
                                           
                                        <a href="index.php" class="btn btn-danger"  role="button" aria-pressed="true">ATRAS</a>                            
                                        <button type="submit"class="btn btn-success" name="guardar">GUARDAR</button>
                                        
                                    </div>
                                </div>
                            </div>

         




         </form>

        </div>  
    </div>  
</div>





















































<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
