<?php 
session_start();

include("dbusers.php");


if  (isset($_POST['guardar'])) {

    
    $username = $_POST['username'];
    $pass = $_POST['password'];
    $hash=password_hash($pass,PASSWORD_DEFAULT);
    echo'bien';
    $sql = "SELECT id,username,password, role FROM users WHERE username = '$username' AND password='$pass' ";
    $result = $conn->query($sql);

    if ($result !==false && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        echo"niceeeee";
        echo"contraseña encriptada:$hash";
        // Verificar la contraseña
        if (password_verify($user['password'],$hash)) {
            echo"PERFECTOOO";
            // Guardar la información del usuario en la sesión
            $_SESSION['id'] = $user['id'];
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $user['role'];

            header("Location: index.php"); // Redirigir al dashboard
            exit();
        } else {
            echo '<script language="javascript">alert("USUARIO Y CONTRASEÑA INCORRECTOS O CAMPOS VACIOS");window.location.href="login.php"</script>';
        }
    } else {
        echo '<script language="javascript">alert("USUARIO Y CONTRASEÑA INCORRECTOS O CAMPOS VACIOS");window.location.href="login.php"</script>';
        //echo "Usuario o contraseña incorrectos";
    }
}
/*
if($row['contar']>0){
    $_SESSION['Username']=$Username;
    header("location:index.php");
}else{
    header("location:login.php");
}*/


/*
if($row['Username']==$Username && $row=['Pass']==$Pass){
    header("location: ./index.php");
}
else{
    header("login.php");
}*/




?>