<?php 
include("conexiondb.php");


if (isset($_POST['savefactura'])){

    $Marca=$_POST['Model'];
    $Fecha_Compra=$_POST['Fech_Compra'];
    $Orden_Compra=$_POST['Orden_Compra'];
    $Marcaxd=$_POST['Marca'];


    //$filename = $_FILES['Archivo']['name'];

   // $destination = dirname(__FILE__).'/Archivos' .$filename;
    //$extension = pathinfo($filename, PATHINFO_EXTENSION);
   // $file = $_FILES['Archivo']['tmp_name'];
   // $size = $_FILES['Archivo']['size'];


   // if (!in_array("zip","pdf","docx",$extension)) {
      //  echo "You file extension must be .zip, .pdf or .docx";
   // } elseif ($_FILES['Archivo']['size'] > 1000000000) { // file shouldn't be larger than 1Megabyte
    //    echo "File too large!";
   // }

   

            $sql="INSERT INTO facturas (Model,Fech_Compra,Marca) values ('$Marca','$Fecha_Compra','$Marcaxd')";
            if (mysqli_query($conn, $sql)) {
               
                $_SESSION['message']='GUARDADO';
                $_SESSION['message_type']='success';
                             header("location:index.php");

            }else{ echo "Failed to upload file.";}
        
    
}


?>