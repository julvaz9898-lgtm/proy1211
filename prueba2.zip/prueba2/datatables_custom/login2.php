<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #e0f7fa; /* Azul claro */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .login-container {
            background-color: #ffffff; /* Blanco */
            padding: 80px;
            border-radius: 40px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .login-container img {
            width: 320px;
            height: 160px;
            object-fit: cover;
            border-radius: 10%;
            margin-bottom: 20px;
        }

        .login-container h1 {
            color: #007BFF;
            margin-bottom: 30px;
            font-size: 28px;
            font-weight: bold;
            text-align: center;
        }

        .form-control {
            border-radius: 30px;
            padding: 10px 20px;
            font-size: 26px;
            margin-bottom: 20px;
        }

        .btn-custom {
            background-color: #007BFF;
            border: none;
            color: white;
            padding: 10px 20px;
            border-radius: 30px;
            width: 100%;
            transition: background-color 0.3s ease;
            font-size: 26px;
        }

        .btn-custom:hover {
            background-color: #0056b3;
        }

        .footer-text {
            margin-top: 20px;
            color: #666;
            text-align: center;
        }

        .footer-text a {
            color: #007BFF;
            text-decoration: none;
        }

        .footer-text a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <!-- Imagen dentro del formulario -->
        <img src="IMG/Lactalis.png" alt="Imagen de usuario"> 
        <h1>Iniciar Sesión</h1>
        <form action="validacion2.php" method="POST">
            <input type="text" class="form-control" name="username" placeholder="Nombre de usuario" required>
            <input type="password" class="form-control" name="password" placeholder="Contraseña" required>
            <button type="submit" class="btn btn-custom" name="guardar2" >Ingresar</button>
        </form>

    </div>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>















