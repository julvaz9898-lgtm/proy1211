<?php 
include("conexiondb.php");





if(isset($_POST['guardar'])){
    $Num_placa=$_POST['Num_placa'];
    $Num_serie=$_POST['Num_serie'];
    $Fecha=$_POST['Fecha'];
    $Marca=$_POST['Marca'];
    $Area=$_POST['Area'];
    $Nombre=$_POST['Nombre'];
    $Origen=$_POST['Origen'];
    $Destino=$_POST['Destino'];
    $Estado=$_POST['Estado'];
    $Puesto=$_POST['Puesto'];
    $Ubicacion=$_POST['Ubicacion'];
    $RAM=$_POST['RAM'];
    $Disco=$_POST['Disco'];
    $Fecha_Entrega=$_POST['Fecha_Entrega'];
    $Tipo=$_POST['Tipo'];
    $Antiviruz=$_POST['Antiviruz'];
    $Email=$_POST['Email'];
    $Com=$_POST['Comentario'];

    
     $query= "INSERT INTO activo_fijo(Num_placa,Num_serie,Fecha,Marca,Area,Nombre,Origen,Destino,Estado,Puesto,Ubicacion,RAM,Disco,Fecha_Entrega,Tipo,Antiviruz,Email,Comentario)
              VALUES('$Num_placa','$Num_serie', '$Fecha','$Marca','$Area','$Nombre','$Origen','$Destino','$Estado','$Puesto','$Ubicacion','$RAM','$Disco','$Fecha_Entrega','$Tipo','$Antiviruz','$Email','$Com')";

              $Result=mysqli_query($conn,$query);

              if(!$Result){
                  die("fail");
              }else{ echo'guardado';
              }

   $_SESSION['message']='GUARDADO';
    $_SESSION['message_type']='success';
  header("location:index.php");
 
  

}


?>
