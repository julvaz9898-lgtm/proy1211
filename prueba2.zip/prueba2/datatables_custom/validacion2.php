<?php

session_start();

include("dbusers.php");




if  (isset($_POST['guardar2'])) {

    $username = $_POST['username']; // Obtener el nombre de usuario del formulario
    $password = $_POST['password']; // Obtener la contraseña del formulario
    $hash=password_hash($password,PASSWORD_DEFAULT);
$sql = "SELECT * FROM users_areas WHERE username = '$username' AND password = '$password'";
$result = $conn->query($sql);

if ($result !==false && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $redirect_page = $user['redirect_page'];
    echo"niceeeee";
    echo"contraseña encriptada:$hash";
    // Verificar la contraseña
    if (password_verify($user['password'],$hash)) {
        echo"PERFECTOOO";
        // Guardar la información del usuario en la sesión
        
        $_SESSION['username2'] = $username;
      

        header("Location: $redirect_page"); // Redirigir al dashboard
        exit();
    } else {
        echo '<script language="javascript">alert("USUARIO Y CONTRASEÑA INCORRECTOS O CAMPOS VACIOS");window.location.href="login2.php"</script>';
    }
}else {
    echo '<script language="javascript">alert("USUARIO Y CONTRASEÑA INCORRECTOS O CAMPOS VACIOS");window.location.href="login2.php"</script>';
}

}



?>