<?php 
include("conexiondb.php");

if(isset($_POST['savemodel'])){
    $Marca=$_POST['Marca'];
    $Model=$_POST['Model'];
    
     $query= "INSERT INTO marc_model (Marca,Model)
              VALUES('$Marca','$Model')";

              $Result=mysqli_query($conn,$query);

              if(!$Result){
                  die("fail");
              }

              echo'guardado';






    $_SESSION['message']='GUARDADO';
    $_SESSION['message_type']='success';
  header("location:marcas.php");

}