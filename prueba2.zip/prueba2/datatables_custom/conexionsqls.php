<?php
// db_connection.php

// Configuración de conexión a SQL Server
$serverName = "172.22.2.220\LACTALIS_DWH"; // Cambia por el nombre de tu servidor
$connectionInfo = array(
    "Database" => "SELLOUT_2024", // Cambia por el nombre de tu base de datos
    "UID" => "sa",           // Cambia por tu nombre de usuario
    "PWD" => "BD06e8Y8",           // Cambia por tu contraseña
);

// Establecer la conexión
$conne = sqlsrv_connect($serverName, $connectionInfo);

// Verificar si la conexión fue exitosa
if ($conne === false) {
    die("Conexión fallida: " . print_r(sqlsrv_errors(), true));
}

// Puedes retornar la conexión si lo deseas
return $conne;
?>