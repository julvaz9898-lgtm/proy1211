<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chatbot - SQL Server</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="chatcss.css"> <!-- Opcional para estilos personalizados -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</head>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header bg-primary text-white text-center">
                <h4 class="mb-0">Chatbot - Consulta SQL Server</h4>
            </div>
            <div class="card-body">
                <div id="chatbox" class="chatbox p-3" style="height: 400px; overflow-y: auto; background-color: #f8f9fa;">
                    <!-- Mensajes aparecerán aquí -->
                </div>
            </div>
            <div class="card-footer">
                <div class="input-group">
                    <input type="text" id="userInput" class="form-control" placeholder="Escribe tu pregunta...">
                    <div class="input-group-append">
                        <button class="btn btn-success" id="sendBtn">Enviar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function(){
            $('#sendBtn').click(function(){
                var userMessage = $('#userInput').val().trim();
                if(userMessage != ''){
                    $('#chatbox').append('<div class="user-message mb-2"><strong>Tú:</strong> ' + userMessage + '</div>');
                    $('#userInput').val('');
                    
                    // Enviar el mensaje al backend usando AJAX
                    $.ajax({
                        url: 'chatbot.php',
                        method: 'POST',
                        data: { message: userMessage },
                        success: function(response){
                            $('#chatbox').append('<div class="bot-message mb-2"><strong>Bot:</strong> ' + response + '</div>');
                            $('#chatbox').scrollTop($('#chatbox')[0].scrollHeight); // Scroll automático
                        }
                    });
                }
            });
        });
    </script>
</body>
</html>
