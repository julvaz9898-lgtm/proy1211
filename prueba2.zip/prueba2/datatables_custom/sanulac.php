<?php
 include("conexiondb.php");

 

 $Username=$_SESSION['Username'];
 
 




?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="#" />  
    <title>INVENTARIO SANULAC</title>
      
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- CSS personalizado --> 
    <link rel="stylesheet" href="main.css">  
    <link rel="stylesheet" href="vista.css">
      
    <!--datables CSS básico-->
    <link rel="stylesheet" type="text/css" href="datatables/datatables.min.css"/>
    <!--datables estilo bootstrap 4 CSS-->  
    <link rel="stylesheet"  type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
           
    <!--font awesome con CDN-->  
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">  
      
  </head>
  <?php  include("navegationsanulac2.php") ?>

  <?php if (isset($_SESSION['message'])) { ?>
      <div class="alert alert-<?= $_SESSION['message_type']?> alert-dismissible fade show" role="alert">
        <?= $_SESSION['message']?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
     
      </div>
      <?php session_unset(); } ?>

      <div class="nav-side-menu">
    <div class="brand">CATALOGO</div>
    <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
  
        <div class="menu-list">
  
            <ul id="menu-content" class="menu-content collapse out">
                
        

                <li>
                  <a href="allsanulac.php">
                  <i></i> REPORTE COMPLETO
                  </a>
                </li>
                <li data-toggle="collapse" data-target="#service" class="collapsed">
                  <a href="#"><i ></i> UBICACION <span class="arrow"></span></a>
                </li>  
                <ul class="sub-menu collapse" id="service">
                  <li><a href="CHILE.php">CHILE</a></li>
                    <li><a href="COLOMBIA.php">COLOMBIA</a></li>
                    <li><a href="CR.php">CR</a></li>
                    <li><a href="ECUADOR.php">ECUADOR</a></li>
                    <li><a href="MEXICO.php">MEXICO</a></li>
                    <li><a href="PERU.php">PERU</a></li>       

                </ul>
            </ul>
     </div>
</div>
  
 
  <body> 
       
    <div style="height:50px"></div>
     
    <!-- tabla con DataTables-->
    <div class="container">
        <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">        
                        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                            <th>Nombre</th>
                            <th>Area</th>
                            <th>Numero de serie</th> 
                            <th>Num Placa</th>
                            <th>Marca</th>
                            <th>Seccion</th>
                            <th>UBICACION</th> 
                            <th>Acciones</th> 
                           
                            
                             
                            </tr>
                        </thead>
                        <tbody>
                        <?php  


if(!isset($_POST['buscar'])){
  $_POST['buscar']="";
  $buscar=$_POST['buscar'];
}
   $buscar=$_POST['buscar'];
   $query="SELECT * FROM activo_fijo_sanulac WHERE Nombre LIKE'%".$buscar."%' OR Num_Serie LIKE '%".$buscar."%' OR Num_Placa LIKE '%".$buscar."%' OR Area LIKE '%".$buscar."%' ORDER BY Area ";

   $Result=mysqli_query($conn,$query);
   
   while($row=mysqli_fetch_array($Result)){?>

   <tr>  
 
          <td> <?= $row['Nombre'] ?></td> 
          <td> <?= $row['Area'] ?></td> 
          <td> <?= $row['Num_Serie'] ?></td> 
          <td> <?= $row['Num_Placa'] ?></td> 
          <td> <?= $row['Marca'] ?></td> 
          <td> <?= $row['Seccion'] ?></td> 
        
          <td> <?= $row['Ubicacion'] ?></td>
         
          <td> 

          <a href="editsanulac.php?id=<?php echo $row['id']?>" class="btn btn-secondary"> 
          <i class="fas fa-marker"></i>
          </a>
         
          
         
          
          </td>

   </tr>

   <?php }?>


                        </tbody>        
                       </table>                  
                    </div>
                </div>
        </div>  
    </div>    
     
    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="jquery/jquery-3.3.1.min.js"></script>
    <script src="popper/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
      
    <!-- datatables JS -->
    <script type="text/javascript" src="datatables/datatables.min.js"></script>    
     
    <!-- para usar botones en datatables JS -->  
    <script src="datatables/Buttons-1.5.6/js/dataTables.buttons.min.js"></script>  
    <script src="datatables/JSZip-2.5.0/jszip.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/pdfmake.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
    <script src="datatables/Buttons-1.5.6/js/buttons.html5.min.js"></script>
     
    <!-- código JS propìo -->    
    <script type="text/javascript" src="main.js"></script>  
    
    
  </body>
</html>
<?php 

?>