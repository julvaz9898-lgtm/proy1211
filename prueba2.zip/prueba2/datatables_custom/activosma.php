<?php
 include("conexiondb.php"); // aqui se incluye la conexion a la base de datos la cual proviene de conexiondb y 
                            // y la variable en la que se guarda la conexion es "conn"

 

 $Username=$_SESSION['Username'];
 
 




?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="#" />  
    <title>ACTIVO FIJO SMA</title>
      
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- CSS personalizado --> 
    <link rel="stylesheet" href="main.css">  
    <link rel="stylesheet" href="vista.css">
      
    <!--datables CSS básico-->
    <link rel="stylesheet" type="text/css" href="datatables/datatables.min.css"/>
    <!--datables estilo bootstrap 4 CSS-->  
    <link rel="stylesheet"  type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
           
    <!--font awesome con CDN-->  
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">  
      
  </head>
  <?php  include("navegationsma.php") ?>

  <?php if (isset($_SESSION['message'])) { ?>
      <div class="alert alert-<?= $_SESSION['message_type']?> alert-dismissible fade show" role="alert">
        <?= $_SESSION['message']?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
     
      </div>
      <?php session_unset(); } ?>

     
        
 
  <body> 
       
    <div style="height:50px"></div>
     
    <!-- tabla con DataTables-->
    <div class="container">
        <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">        
                        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="110%">
                        <thead>
                            <tr>
                            <th>Num. de serie</th>
                            <th>Num. Placa</th>
                            <th>Fecha Adquisicion</th>
                            <th>Descripcion</th> 
                            <th>Area</th>
                            <th>Marca</th> 
                            <th>UBICACION</th> 
                            <th>Responsable</th>
                            <th>Factura</th>
                            <th>Acciones</th> 
                           
                            
                             
                            </tr>
                        </thead>
                        <tbody>
                        <?php  


if(!isset($_POST['buscar'])){
  $_POST['buscar']="";
  $buscar=$_POST['buscar'];
}
   $buscar=$_POST['buscar'];
   $query="SELECT * FROM activo_sma ";

   $Result=mysqli_query($conn,$query);
   
   while($row=mysqli_fetch_array($Result)){?>

   <tr>  
 
          <td> <?= $row['Numero_de_serie'] ?></td> 
          <td> <?= $row['Num_de_placa'] ?></td> 
          <td> <?= $row['Fecha_Adquisicion'] ?></td> 
          <td> <?= $row['Descripcion_Bien'] ?></td> 
          <td> <?= $row['Area'] ?></td> 
          <td> <?= $row['Marca'] ?></td> 
          <td> <?= $row['Ubicacion'] ?></td>
          <td> <?= $row['Responsable'] ?></td> 
          <td> <?= $row['Factura'] ?></td>
         
          <td> 

          <a href="editactivosma.php?id=<?php echo $row['id']?>" class="btn btn-secondary"> 
          <i class="fas fa-marker"></i>
          </a>
         
          
         
          
          </td>

   </tr>

   <?php }?>


                        </tbody>        
                       </table>                  
                    </div>
                </div>
        </div>  
    </div>    
     
    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="jquery/jquery-3.3.1.min.js"></script>
    <script src="popper/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
      
    <!-- datatables JS -->
    <script type="text/javascript" src="datatables/datatables.min.js"></script>    
     
    <!-- para usar botones en datatables JS -->  
    <script src="datatables/Buttons-1.5.6/js/dataTables.buttons.min.js"></script>  
    <script src="datatables/JSZip-2.5.0/jszip.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/pdfmake.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
    <script src="datatables/Buttons-1.5.6/js/buttons.html5.min.js"></script>
     
    <!-- código JS propìo -->    
    <script type="text/javascript" src="main.js"></script>  
    
    
  </body>
</html>
<?php 

?>