<?php
 include("conexiondb.php");


 session_start();
 
 if (!isset($_SESSION['username2'])) {
     header("Location: login2.php");
     exit();
 }
 



?><!--FIN -->


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equipos de computo</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- CSS personalizado --> 
    <link rel="stylesheet" href="main.css">  
    <link rel="stylesheet" href="vista.css">
    <link rel="stylesheet" href="nav.css">  
      
    <!--datables CSS básico-->
    <link rel="stylesheet" type="text/css" href="datatables/datatables.min.css"/>
    <!--datables estilo bootstrap 4 CSS-->  
    <link rel="stylesheet"  type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
           
    <!--font awesome con CDN-->  
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">  
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        /* Estilo personalizado para la navbar */
        .navbar-custom {
            background-color: rgba(224, 247, 250, 0.4); /* Azul claro con 70% de opacidad */
            color: #ffffff;
        }

        .navbar-brand img {
            width: 300px;
            height: 122px;
            border-radius: 20%;
            
          
        }

        .navbar-title {
            font-size: 24px;
            color: #502b24; /* Azul oscuro */
            font-weight: bold;
            margin: auto;
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            animation: moveText 3s infinite alternate ease-in-out;
            
        }
        .navbar-title2 {
            font-size: 24px;
            color: #502b24; /* Azul oscuro */
            font-weight: bold;
            margin: auto;
            position: absolute;
            left: 75%;
            transform: translateX(-50%);
            animation: moveText 3s infinite alternate ease-in-out;
        }

        @keyframes moveText {
            0% { transform: translateX(-50%) translateY(0); }
            50% { transform: translateX(-50%) translateY(-5px); }
            100% { transform: translateX(-50%) translateY(0); }
        }

        .nav-item a {
            color: #502b24; /* Azul */
            font-weight: bold;
            transition: color 0.3s;
        }

        .nav-item a:hover {
            color: #502b24; /* Azul más oscuro en hover */
        }

        #enviarDatos {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            transition: all 1.3s ease;
            
        }

        /* Animación de salto */
        #enviarDatos.salto {
            transform: translateY(-10px);
            background-color: #28a745;  /* Color verde */
        }


    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-custom">
    <div class="container">
        <!-- Imagen a la izquierda -->
        <a class="navbar-brand" >
            <img src="IMG/Lactalis.png" alt="Logo">
        </a>
       
        <!-- Menú de navegación a la derecha -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            
        </button>
        <a type="button" class="btn btn-outline-warning btn-lg" href="logout2.php">CERRAR SESION</a>
        <button id="enviarDatos">SOLICITAR UN EQUIPO</button>
        <script>
       // Evento al hacer clic en el botón
       $('#enviarDatos').click(function() {
            var boton = $(this);

            // Animación de salto y cambio de color
            boton.addClass('salto');
            
            // Realizar la solicitud AJAX
            $.ajax({
                url: 'procesar_datos_8.php',  // Archivo PHP que procesará la solicitud
                method: 'POST',
                success: function(response) {

                    alert('TU SOLICITUD FUE ENVIADA CON EXITO');
                    // Redirigir a la página de administración
                   // window.location.href = 'admin.php';
                },
                error: function() {
                    alert('Hubo un problema al enviar la solicitud.');
                }
            });

            // Volver a su estado original después de 0.6s
            setTimeout(function() {
                boton.removeClass('salto');
            }, 600);
        });

      
    </script>
  


        
    </div>
    
    
    
        
</nav>

<h2 class="navbar-title2">BIENVENIDO USUARIO: <?php echo $_SESSION['username2']; ?></h2>


<div style="height:50px"></div>
     
    <!-- tabla con DataTables-->
    <div class="container">
        <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">        
                        <table id="example" class="table table-striped table-bordered" cellspacing="0px" width="100%">
                        <thead>
                            <tr>
                            <th>NOMBRE</th>
                            <th>MARCA</th>
                            <th>AREA</th>
                            <th>UBICACION</th> 
                            <th>MODELO</th> 
                            <th>FECHA DE COMPRA</th> 
                            
                            <th>AÑOS</th> 
                           
                            
                             
                            </tr>
                        </thead>
                        <tbody>
                        <?php  


if(!isset($_POST['buscar'])){
  $_POST['buscar']="";
  $buscar=$_POST['buscar'];
}
   $buscar=$_POST['buscar'];
   $query="SELECT A.Nombre,A.Marca,A.Area,A.Ubicacion,B.Model,B.Fech_Compra,TIMESTAMPDIFF(YEAR,B.Fech_Compra,CURRENT_DATE)AS AÑOS from activo_fijo A INNER JOIN facturas B ON B.Model= A.Marca WHERE Area='NOMINAS' ORDER BY `Nombre` DESC;";

   $Result=mysqli_query($conn,$query);
   
   while($row=mysqli_fetch_array($Result)){?>

   <tr>  
 
          <td> <?= $row['Nombre'] ?></td> 
          <td> <?= $row['Marca'] ?></td> 
          <td> <?= $row['Area'] ?></td> 
          <td> <?= $row['Ubicacion'] ?></td>
          <td> <?= $row['Model'] ?></td>
          <td> <?= $row['Fech_Compra'] ?></td>
          <td> <?= $row['AÑOS'] ?></td>
      

   </tr>

   <?php }?>


                        </tbody>        
                       </table>                  
                    </div>
                </div>
        </div>  
    </div>    

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- jQuery, Popper.js, Bootstrap JS -->
<script src="jquery/jquery-3.3.1.min.js"></script>
    <script src="popper/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
      
    <!-- datatables JS -->
    <script type="text/javascript" src="datatables/datatables.min.js"></script>    
     
    <!-- para usar botones en datatables JS -->  
    <script src="datatables/Buttons-1.5.6/js/dataTables.buttons.min.js"></script>  
    <script src="datatables/JSZip-2.5.0/jszip.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/pdfmake.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
    <script src="datatables/Buttons-1.5.6/js/buttons.html5.min.js"></script>
     
    <!-- código JS propìo -->    
    <script type="text/javascript" src="main.js"></script>  
    <script type="text/javascript" src="navb.js"></script> 

</body>
</html>
