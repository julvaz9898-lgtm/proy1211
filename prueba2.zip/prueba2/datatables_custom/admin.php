<?php


include("conexiondb.php"); // aqui se incluye la conexion a la base de datos la cual proviene de conexiondb y 
                           // y la variable en la que se guarda la conexion es "conn"



$sql = "SELECT * FROM admin_data"; //aqui se crea una variable llamada sql la cual guarda la consulta deseada
$result = $conn->query($sql);//se crea la variable result donde con conectamos a la base de datos y ejecutamos la funcion query y como parametro le pasamos la variable donde se almacena la consulta
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administración</title>
    <!-- Bootstrap CSS  aqui traemos el ccs de bootstrap-->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">  
    <!-- CSS personalizado --> 
    <link rel="stylesheet" href="main.css">  
    <link rel="stylesheet" href="vista.css">
    <link rel="stylesheet" href="nav.css">  
      
    <!--datables CSS básico-->
    <link rel="stylesheet" type="text/css" href="datatables/datatables.min.css"/>
    <!--datables estilo bootstrap 4 CSS-->  
    <link rel="stylesheet"  type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
           
    <!--font awesome con CDN-->  
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous"> 
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }

        .container {
            background: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        table {
            width: 100%;
        }

        #tablaDatos_wrapper {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">  <!--aqui creamos el conteiner que contrendra la tabla que crearemos-->  

        <h1>SOLICITUDES DE EQUIPO</h1> <!--aqui creamos el titulo-->  
        <table id="tablaDatos" class="display"><!--aqui creamos la tabla y le asignamos su id con el cual se identificara cuando usemos javascript--> 
            <thead>
                <tr><!--inicio de tr--> 
                    <th>Nombre</th>   <!--aqui dentro del "tr" es donde se colocan las columnas que tendra nuestra tabla--> 
                    <th>Marca</th>
                    <th>Area</th>
                    <th>Ubicacion</th>
                    
                    <th>Fecha de Compra</th>
                    <th>AÑOS</th>
                </tr>
            </thead><!--fin del tr-->
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>".$row['Nombre']."</td><td>".$row['Marca']."</td><td>".$row['Area']."</td><td>".$row['Ubicacion']."</td><td>".$row['Fech_Compra']."</td><td>".$row['Anos']."</td></tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#tablaDatos').DataTable({
                "language": {
                    "lengthMenu": "Mostrar _MENU_ registros por página",
                    "zeroRecords": "No se encontraron resultados",
                    "info": "Mostrando página _PAGE_ de _PAGES_",
                    "infoEmpty": "No hay registros disponibles",
                    "infoFiltered": "(filtrado de _MAX_ registros totales)",
                    "search": "Buscar:",
                    "paginate": {
                        "first": "Primero",
                        "last": "Último",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                }
            });
        });
    </script>


<!-- jQuery, Popper.js, Bootstrap JS -->
<script src="jquery/jquery-3.3.1.min.js"></script>
    <script src="popper/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
      
    <!-- datatables JS -->
    <script type="text/javascript" src="datatables/datatables.min.js"></script>    
     
    <!-- para usar botones en datatables JS -->  
    <script src="datatables/Buttons-1.5.6/js/dataTables.buttons.min.js"></script>  
    <script src="datatables/JSZip-2.5.0/jszip.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/pdfmake.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
    <script src="datatables/Buttons-1.5.6/js/buttons.html5.min.js"></script>
     
    <!-- código JS propìo -->    
    <script type="text/javascript" src="main.js"></script>  
    <script type="text/javascript" src="navb.js"></script> 
    
</body>
</html>