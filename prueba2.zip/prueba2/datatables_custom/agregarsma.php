
<?php


 

 
 

$Username=$_SESSION['Username'];



?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />


<body>
<nav class="navbar navbar-ligth" style="background-color: #e3f2fd;">
    <div class="container">
    <a>
    <img src="images/logo_lactalis.jpg">
       
    <div>
    <a aling="rigth"class="navbar-brand ">INVENTARIO DE ACTIVO SMA </a>
    
   
       
    </div>
</nav>


<div class="container p-4">
    <div class="row">
      <div class="col-md-9 register-right"> 
         <form action="guardaractivosma.php" method="POST" class="form-register" enctype="multipart/form-data" id="uploadForm">
         <p class="text-uppercase" >AGREGAR ACTIVO</p>
          
         <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
        
                                <div class="row register-form">
                                    <div class="col-md-6">
                                        

                                    <div class="form-group">
                                        <a aling="left">MES</a>
                                            <select class="form-control" name="Mes">
                                            <option class="hidden"  selected disabled>SELECCIONA UNA OPCION</option>
                                                <option>ENERO</option>
                                                <option>FEBRERO</option>
                                                <option>MARZO</option>
                                                <option>ABRIL</option>
                                                <option>MAYO</option>
                                                <option>JUNIO</option>
                                                <option>JULIO</option>
                                                <option>AGOSTO</option>
                                                <option>SEPTIEMBRE</option>
                                                <option>OCTUBRE </option>
                                                <option>NOVIEMBRE</option>
                                                <option>DICIEMBRE</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Fecha Adquisicion</a>
                                            <input type="date" class="form-control" placeholder="Fecha de Adquisicion*" name="Fecha_Adquisicion" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Ubicacion</a>
                                            <select class="form-control" name="Ubicacion">
                                            <option class="hidden"  selected disabled>SELECCIONA UNA OPCION</option>
                                                <option>SANULAC</option>
                                                <option>SMA</option>
                                                <option>ICI</option>
                                                
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="AREA*" name="Area" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="CeCo*" name="CeCo" />
                                        </div>
            
                                        <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="Responsable*" name="Responsable" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="DESCRIPCION *" name="Descripcion_Bien" />
                                        </div>
                                        
                                        <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="Marca*" name="Marca" />
                                        </div>

                                        <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="NUMERO DE SERIE*" name="Numero_de_serie" />
                                        </div>

                                        
                                       
                                    </div>
                         
                                    <div class="col-md-6">


                                    <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="MODELO*" name="Modelo" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="NUMERO DE PLACA*" name="Num_de_placa" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="CANTIDAD*" name="Cantidad" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="IMPORTE MOI*" name="Importe_MOI" />
                                        </div>

                                        <div class="form-group">
                                        <a aling="left">Moneda</a>
                                            <select class="form-control" name="Moneda">
                                            <option class="hidden"  selected disabled>SELECCIONA UNA OPCION</option>
                                                <option>MXN</option>
                                                <option>USD</option>
                                                <option>EUROS</option>
                                                
                                            </select>
                                        </div>
                                        
                                        <div class="form-group">
                                            <input type="text"  class="form-control" placeholder="FACTURA *" name="Factura" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text"  class="form-control" placeholder="REGISTRO CONTABLE*" name="Registro_Contable" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text"  class="form-control" placeholder="ESTATUS*" name="Estatus" />
                                        </div>
                                       
                                        <div class="form-group">
                                            <select class="form-control" name="Sociedad">
                                            <option class="hidden"  selected disabled>SELECCIONA UNA SOCIEDAD*</option>
                                                <option>MX30</option>
                                                <option>MX20</option>
                                              
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <select class="form-control" name="Razon_Social">
                                            <option class="hidden"  selected disabled>SELECCIONA UNA RAZON SOCIAL*</option>
                                                <option>DILASA</option>
                                                <option>DELESA</option>
                                              
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <select class="form-control" name="Ano">
                                            <option class="hidden"  selected disabled>SELECCIONA UN AÑO*</option>
                                                <option>2020</option>
                                                <option>2021</option>
                                                <option>2022</option>
                                                <option>2023</option>
                                                <option>2024</option>
                                                <option>2025</option>
                                                <option>2026</option>
                                                <option>2027</option>
                                                <option>2028</option>
                                                <option>2029</option>
                                                <option>2030</option>
                                                <option>2031</option>
                                              
                                            </select>
                                        </div>

                                     
                                                                              
                                       
                                           
                                        <a href="activosma.php" class="btn btn-danger"  role="button" aria-pressed="true">ATRAS</a>                            
                                        <button id="capture-btn" type="submit"class="btn btn-success" name="guardaractivosma">GUARDAR</button>
                                        
                                    </div>
                                </div>
                            </div>

         




         </form>

        </div>  
    </div>  
</div>





















































<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
