<?php 
include("conexiondb.php");

if (isset($_GET['IDE'])) {
    $id = $_GET['IDE'];

    // fetch file to download from database
    $sql = "SELECT * FROM facturas WHERE IDE=$id";
    $result = mysqli_query($conn, $sql);
  
    $file = mysqli_fetch_assoc($result);
    $filepath = 'archivos/' . $file['Names'];

    if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($filepath));
        header('Expires: 0');
        header('Content-Transfer-Encoding: binary');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize('archivos/' . $file['Names']));
      
        readfile('archivos/' . $file['Names']);
        exit;

        // Now update downloads count
        // $newCount = $file['downloads'] + 1;
         //$updateQuery = "UPDATE facturas SET downloads=$newCount WHERE IDE=$id";
         //mysqli_query($conn, $updateQuery);
         //exit;
    }

}
?>