<?php include("conexiondb.php");

    if(isset($_GET['Id'])){
        $id=$_GET['Id'];
        $querydelete="DELETE FROM colaboradores WHERE Id=$id";
        $resultado=mysqli_query($conn,$querydelete);
        if(!$resultado){
            die("mal");
        }


    $_SESSION['message']='ELIMINADO';
    $_SESSION['message_type']='danger';
    header("Location:colaboradores.php");
    }




?>