<?php include("conexiondb.php");
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}


    if(isset($_GET['ID'])){
        $id=$_GET['ID'];
        $querydelete="DELETE FROM users WHERE ID=$id";
        $resultado=mysqli_query($conn,$querydelete);
        if(!$resultado){
            die("mal");
        }


    $_SESSION['message']='ELIMINADO';
    $_SESSION['message_type']='danger';
    header("Location:creados.php");
    }




?>