<?php
// Configuración de la conexión a SQL Server
$serverName = "mxa12vm.mx.lactadom.ad\LACTALIS_DWH"; // Cambia por el nombre de tu servidor SQL
$connectionInfo = array("Database" => "SELLOUT_2024", "UID" => "sa", "PWD" => "BD06e8Y8");
$conn3 = sqlsrv_connect($serverName, $connectionInfo);

if ($conn3 === false) {
    die(print_r(sqlsrv_errors(), true));
}

// Procesar el mensaje del usuario
if (isset($_POST['message'])) {
    $userMessage = strtolower($_POST['message']);  // Convertir a minúsculas para evitar problemas

    // Verificar si el usuario pide todos los datos de la tabla
    if (strpos($userMessage, 'todos los datos de la tabla') !== false) {
        $query3 = "SELECT VALOR_COSTO, RegDate FROM [dbo].[CONSOLIDADO_DEV]";  // Cambia "tu_tabla" por el nombre de tu tabla
        $stmt = sqlsrv_query($conn3, $query3);

        if ($stmt === false) {
            echo "Error en la consulta.";
            die(print_r(sqlsrv_errors(), true));
        }

        // Si hay resultados, devolverlos como respuesta
        if (sqlsrv_has_rows($stmt)) {
            $response = "<table class='table table-bordered'><thead><tr><th>Columna 1</th><th>Columna 2</th></tr></thead><tbody>";
            while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
                $response .= "<tr><td>" . $row['VALOR_COSTO'] . "</td><td>" . $row['RegDate'] . "</td></tr>";
            }
            $response .= "</tbody></table>";
            echo $response;
        } else {
            echo "No se encontraron datos.";
        }

        // Cerrar la conexión
        sqlsrv_free_stmt($stmt);
        sqlsrv_close($conn3);
    } else {
        // Respuesta por defecto si el mensaje no coincide con la consulta
        echo "No entiendo tu mensaje. Pregunta por 'todos los datos de la tabla'.";
    }
}
?>
