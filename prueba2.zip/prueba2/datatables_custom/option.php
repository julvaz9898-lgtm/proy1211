<?php


include("conexiondb.php");



if ($conn->connect_error){
    die("conexion fallida" .$conn->connect_error);
}
$sql="SELECT IDE, Model from facturas WHERE Fech_Compra between '2024-01-01' and '2024-12-31'";
$Result=$conn->query($sql);
if($Result->num_rows>0){
    while($row=$Result->fetch_assoc()){
        
        echo "<option value='".$row["Model"]."'>".$row["Model"] ."</option>";
    }

 } else{
    
        echo"<option>No hay resultados</option>";
    }


$conn->close();



?>