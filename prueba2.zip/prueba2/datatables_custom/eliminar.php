<?php include("conexiondb.php");


$Username=$_SESSION['Username'];

    if(isset($_GET['id'])){
        $id=$_GET['id'];
        $querydelete="DELETE FROM activo_fijo WHERE id=$id";
        $resultado=mysqli_query($conn,$querydelete);
        if(!$resultado){
            die("mal");
        }


    $_SESSION['message']='ELIMINADO';
    $_SESSION['message_type']='danger';
    header("Location:index.php");
    }



?>