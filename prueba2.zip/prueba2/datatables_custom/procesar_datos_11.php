<?php
  session_start();

  include("conexiondb.php");
  $sql = "SELECT * FROM antiguedad where Area='MKT' and Anos>=3;";
$result = $conn->query($sql);

// Limpia la tabla `admin_data` antes de insertar nuevos datos (sobreescritura)
$conn->query("TRUNCATE TABLE admin_data11");

// Recoger datos en un array
if ($result->num_rows > 0) {while ($row = $result->fetch_assoc()) {
  
  $nombre = $row['Nombre'];
  $Marca = $row['Marca'];
  $Area = $row['Area'];
  $Ubicacion = $row['Ubicacion'];
  $Model = $row['Model'];
  $Fech_Compra = $row['Fech_Compra'];
  $Anos = $row['Anos'];

  // Inserta los datos en una tabla de administración o cualquier tabla que quieras
  $insert_sql = "INSERT INTO admin_data11 (Nombre, Marca, Area,Ubicacion,Model,Fech_Compra,Anos) VALUES ('$nombre', '$Marca', '$Area','$Ubicacion','$Model','$Fech_Compra','$Anos')";
  $conn->query($insert_sql);
}
}
// Cerrar la conexión
$conn->close();


?>