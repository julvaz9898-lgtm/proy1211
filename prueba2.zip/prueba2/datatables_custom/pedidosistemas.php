<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Mis Pedidos</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css" />
</head>
<body>
  <div class="container mt-5">
    <h1 class="text-center">Mis Pedidos</h1>
    <div id="orders-container" class="row">
      <!-- Aquí se mostrarán los pedidos -->
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
    AOS.init();

    async function fetchOrders() {
      const response = await fetch('pedido_sistemasdbAPI.php');
      const orders = await response.json();
      const container = document.getElementById('orders-container');
      
      orders.forEach((order, index) => {
        const card = document.createElement('div');
        card.className = 'col-md-4';
        card.innerHTML = `
          <div class="card mb-4" data-aos="fade-up" data-aos-delay="${index * 100}">
            <div class="card-body">
              <h5 class="card-title">Pedido #${order.Nombre}</h5>
              <p><strong>Producto:</strong> ${order.Marca}</p>
              <p><strong>Cantidad:</strong> ${order.Area}</p>
              <p><strong>Precio:</strong> $${order.Ubicacion}</p>
              <p><strong>Fecha:</strong> ${order.Fech_Compra}</p>
            </div>
          </div>`;
        container.appendChild(card);
      });
    }

    fetchOrders();
  </script>
</body>
</html>
