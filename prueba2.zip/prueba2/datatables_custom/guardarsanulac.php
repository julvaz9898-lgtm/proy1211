<?php 
include("conexiondb.php");
$Username=$_SESSION['Username'];



if(isset($_POST['guardar'])){
    $Num_placa=$_POST['Num_placa'];
    $Num_serie=$_POST['Num_serie'];
    $Fecha=$_POST['Fecha'];
    $Marca=$_POST['Marca'];
    $Area=$_POST['Area'];
    $Nombre=$_POST['Nombre'];
    $Origen=$_POST['Origen'];
    $Destino=$_POST['Destino'];
    $Estado=$_POST['Estado'];
    $Puesto=$_POST['Puesto'];
    $Ubicacion=$_POST['Ubicacion'];
    $RAM=$_POST['RAM'];
    $Disco=$_POST['Disco'];
    $Fecha_Entrega=$_POST['Fecha_Entrega'];
    $Seccion=$_POST['Seccion'];

    
     $query= "INSERT INTO activo_fijo_sanulac (Num_placa,Num_serie,Fecha,Marca,Area,Nombre,Origen,Destino,Estado,Puesto,Ubicacion,RAM,Disco,Fecha_Entrega,Seccion)
              VALUES('$Num_placa','$Num_serie', '$Fecha','$Marca','$Area','$Nombre','$Origen','$Destino','$Estado','$Puesto','$Ubicacion','$RAM','$Disco','$Fecha_Entrega','$Seccion')";

              $Result=mysqli_query($conn,$query);

              if(!$Result){
                  die("fail");
              }else{ echo'guardado';
              }


    $_SESSION['message']='GUARDADO';
    $_SESSION['message_type']='success';
  header("location:sanulac.php");
  

}


?>
