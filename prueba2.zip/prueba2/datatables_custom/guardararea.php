<?php 
include("conexiondb.php");

if(isset($_POST['savearea'])){
    $Area=$_POST['Area'];
   
    
     $query= "INSERT INTO areas (Nom_Area)
              VALUES('$Area')";

              $Result=mysqli_query($conn,$query);

              if(!$Result){
                  die("fail");
              }

              echo'guardado';






    $_SESSION['message']='GUARDADO';
    $_SESSION['message_type']='success';
  header("location:areas.php");

}