<?php

include("conexiondb.php");

  if (isset($_POST['crear'])) {
    $Username=$_POST['Username'];
    $Pass=$_POST['Pass'];
    $pass_hash=password_hash($Pass,PASSWORD_BCRYPT);
    $query = "INSERT INTO users (Username, Pass) VALUES ('$Username', '$Pass')";
    $Result = mysqli_query($conn,$query);
   
    if (!$Result) {
        die("fail");
    } else {
      echo'guardado';
    }
    
    $_SESSION['message']='GUARDADO';
    $_SESSION['message_type']='success';
  header("location:creados.php");
  }
?>