<?php
 include("db.php");

session_start();

if (!isset($_SESSION['username6'])) {
    header("Location: login.php");
    exit();
}


?><!--FIN -->

<h2>BIENVENIDO USUARIO: <?php echo $_SESSION['username6']; ?></h2>
<a href="index.php" class="btn btn-danger"  role="button" aria-pressed="true">ATRAS</a>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTRO DE SALIDAS</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
<div class="container mt-5">
        <h1 class="text-center">REGISTRO DE SALIDAS</h1>
        <form action="guardarsalida.php" method="POST" id="formulario" class="mt-4">
            <div class="col-md-4">
                <label for="busqueda" class="form-label">BUSCAR PRODUCTO:</label>
                <input type="text" class="form-control" id="busqueda" name="busqueda" placeholder="Escribe el nombre del producto">
                <div id="sugerencias" class="list-group mt-2"></div>
            </div>
            <!--<button type="submit" class="btn btn-primary">Seleccionar</button>-->
            <div class="col-md-4">
                    <label for="datetime" class="form-label">FECHA DE SALIDA</label>
                    <input class="form-control" type="datetime-local"  id="fecha" name="fecha" value="<?php echo date('Y-m-d\TH:i'); ?>" required>
                </div>

            
                <div class="col-md-4">
                  <a aling="left">CANTIDAD DE SALIDA</a>
                   <input type="text" class="form-control" placeholder="numero de serie*" name="salida" />
                </div>

                <div class="col-md-4">
                    <label for="datetime" class="form-label">COMENTARIO DE SALIDA</label>
                    <input type="text" class="form-control" placeholder="comentario*" name="comentario" />
                </div>

                <div class="col-md-4">
                                        <a aling="left">TIPO SE SALIDA</a>
                                            <select class="form-control" name="tipo">
                                           
                                            <option class="hidden"  selected disabled>SELECCIONA UNA OPCION</option>
                                                <option>SALIDA</option>
                                                <option>PRESTAMO</option>
                                                
                                              
                                              
                                            </select>
                                        </div>
               
              
                <button type="submit"class="btn btn-success" name="salidas">GUARDAR SALIDA</button>
                



        </form>
    </div>
    </body>

    

    


        <!-- Bootstrap JS y dependencias -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Script para la búsqueda dinámica -->
    <script>
        $(document).ready(function() {
            $('#busqueda').on('input', function() {
                const query = $(this).val();
                if (query.length >= 2) { // Solo buscar si se escriben 2 o más caracteres
                    $.ajax({
                        url: 'buscar.php',
                        type: 'GET',
                        data: { query: query },
                        success: function(response) {
                            $('#sugerencias').html(response);
                        }
                    });
                } else {
                    $('#sugerencias').html(''); // Limpiar sugerencias si no hay suficiente texto
                }
            });

            // Seleccionar una sugerencia
            $(document).on('click', '.list-group-item', function() {
                $('#busqueda').val($(this).text());
                $('#sugerencias').html('');
            });
        });
    </script>



