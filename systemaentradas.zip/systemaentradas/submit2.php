<?php
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo "No se recibió información.";
    exit;
}


 try {
 $conn = new PDO("mysql:host=localhost;dbname=useradmin;charset=utf8", "root", "");
     $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

     foreach ($data as $row) {
       $stmt = $conn->prepare("INSERT INTO salida (Fecha, supervisor, producto, Salida, Comentario_Salida, vale,Tipo) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute(array(
           $row['campo1'],
            $row['campo2'],
          $row['campo3'],
             $row['campo4'],
             $row['select1'],
         $row['select2'],
         $row['select3']
         ));
    }
     echo "Datos insertados correctamente.";
 } catch (PDOException $e) {
     echo "Error: " . $e->getMessage();}
?>

