
<?php


include("db.php");

 
 
session_start();

if (!isset($_SESSION['username6'])) {
    header("Location: login.php");
    exit();
}




?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />


    <?php  include("navegation2.php") ?>

       
    </div>
</nav>
    
<h2> USUARIO: <?php echo $_SESSION['username6']; ?></h2>
<h2>ROL: <?php echo $_SESSION['role']; ?></h2>

<div class="container p-4">
    <div class="row">
      <div class="col-md-9 register-right"> 
         <form action="guardareys.php" method="POST" class="form-register" enctype="multipart/form-data">
         <p class="text-uppercase" >AGREGAR INSUMO</p>
          
         <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
        
                                <div class="row register-form">
                                    <div class="col-md-6">
                                    <a aling="left">PRODUCTO</a>
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="PRODUCTO*" name="producto" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">EXISTENCIAS</a>
                                            <input type="text" class="form-control" placeholder="EXISTENCIAS*" name="existencias" />
                                        </div>

                                       
                                        
                                      
                                        
                                    </div>
                                    
                                    <div class="col-md-6">
                                       
                                        
                                        
                                        <div class="form-group">
                                        <a aling="left">UNIDAD MEDIDA</a>
                                            <select class="form-control" name="unidad_medida">
                                           
                                            <option class="hidden"  selected disabled>SELECCIONA UNA OPCION</option>
                                                <option>PIEZAS</option>
                                                <option>KILOS</option>
                                                <option>TONELADAS</option>
                                                <option>LITROS</option>
                                                <option>GALONES</option>
                                                <option>CAJAS</option>
                                                <option>METROS</option>
                                              
                                              
                                            </select>
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">COMENTARIOS</a>
                                            <input type="text" class="form-control" placeholder="COMENTARIOS*" name="comentarios" />
                                        </div>
                                      
                                       
                                    
                                        
                                       
                                           
                                        <a href="index.php" class="btn btn-danger"  role="button" aria-pressed="true">ATRAS</a>                            
                                        <button type="submit"class="btn btn-success" name="guardar">GUARDAR</button>
                                        
                                    </div>
                                </div>
                            </div>

         




         </form>

        </div>  
    </div>  
</div>





















































<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
