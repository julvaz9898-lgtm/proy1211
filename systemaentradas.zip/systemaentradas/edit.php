<?php
 include("conexiondb.php");
 session_start();
 if (!isset($_SESSION['username6'])) {
    header("Location: login.php");
    exit();
}

?>

<h2>BIENVENIDO USUARIO: <?php echo $_SESSION['username6']; ?></h2>


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script>
        // Función para calcular la suma
        function calcularSuma() {
            // Obtener los valores de los campos de número
            var num1 = parseFloat(document.getElementById('num1').value) || 0;
            var num2 = parseFloat(document.getElementById('num2').value) || 0;

            // Calcular la suma
            var suma = num1 + num2;

            // Mostrar el resultado en el tercer campo
            document.getElementById('resultado').value = suma;
        }
    </script>
<body>


<?php include("db.php");


if(isset($_GET['codigo'])){
    $id=$_GET['codigo'];
    $query= "SELECT * FROM productos WHERE codigo=$id";
    $result=mysqli_query($conn,$query);
    if(mysqli_num_rows($result)==1){
        $row = mysqli_fetch_array($result);
        $Producto=$row['producto'];
        $unidad_medida=$row['unidad_medida'];
        $existencias=$row['existencias'];
        $salidas=$row['SALIDAS'];
        $prestamos=$row['prestamos'];
        $entradas=$row['Entradas'];
        $comentario=$row['comentarios'];
       
    }else{echo'mal';}
}

if (isset($_POST['update'])) {
    $id = $_GET['codigo'];
    $Producto=$_POST['producto'];
$unidad_medida=$_POST['unidad_medida'];
$existencias=$_POST['existencias'];
$salidas=$_POST['salidas'];
$prestamos=$_POST['prestamos'];
$entradas=$_POST['Entradas'];
$comentario=$_POST['comentarios'];



$queryup = "UPDATE productos set producto = '$Producto', existencias = '$existencias',unidad_medida='$unidad_medida',SALIDAS='$salidas',prestamos='$prestamos',Entradas='$entradas',comentarios='$comentario' WHERE codigo=$id";
mysqli_query($conn, $queryup);
$_SESSION['message'] = 'Actualizado correctamente';
$_SESSION['message_type'] = 'warning';
header('Location: index.php');  
  }



?>

<div class="container p-4">
    <div class="row">
      <div class="col-md-9 register-right"> 
         <form action="edit.php?codigo=<?php echo $_GET['codigo']; ?>" method="POST" class="form-register" >
         <p class="text-uppercase" >EDITAR INFORMACION</p>
          
         <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
        
                                <div class="row register-form">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                        <a aling="left">Producto</a>
                                            <input type="text" class="form-control" placeholder="producto" name="producto" value="<?php echo $Producto; ?>" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left" for="num1">Entradas</a>
                                            <input type="text" id="num1" oninput="calcularSuma()" class="form-control" placeholder="NUEVAS ENTRADAS*" name="Entradas" value="<?php echo $entradas;?>" />
                                        </div>
                                        <div class="form-group">
                                        <a aling="left">Comentario</a>
                                            <input type="text"  class="form-control" placeholder="COMENTARIO*" name="comentarios" value="<?php echo $comentario;?>" />
                                        </div>
                                                                           
                                        
                                        <div class="form-group">
                                        <a aling="left">Unidad Medida</a>
                                            <select  class="form-control" name="unidad_medida" value="<?php echo $unidad_medida;?>" >
                                            <option><?php echo $unidad_medida;?></option>
                                            <option>PIEZAS</option>
                                                <option>KILOS</option>
                                                <option>TONELADAS</option>
                                                <option>LITROS</option>
                                                <option>GALONES</option>
                                                <option>CAJAS</option>
                                                <option>METROS</option>
                                              
                                                
                                            </select>
                                        </div>
                                      
                                        
                                        
                                        
                                        
                                    </div>
                                    
                                    <div class="col-md-6">
                                       
                                        <div class="form-group">
                                        <a aling="left" for="num2">Existencias</a>
                                            <input type="text"  class="form-control" id="num2" oninput="calcularSuma()" placeholder="existencias*" name="existencias" value="<?php echo $existencias;?>" />
                                        </div>
                                        
                                        
                                        <div class="form-group">
                                        <a aling="left">Salidas</a>
                                            <input type="text"  class="form-control" placeholder="salidas*" name="salidas" value="<?php echo $salidas;?>" />
                                        </div>

                                        <div class="form-group">
                                        <a aling="left">Prestamos</a>
                                            <input type="text"  class="form-control" placeholder="prestamos*" name="prestamos" value="<?php echo $prestamos;?>" />
                                        </div>
                                        <label for="resultado">Resultado:</label>
                                             <input type="number" id="resultado" readonly  name="existencias" value="<?php echo $existencias;?>"><br><br>
                                       
                                       
                                        

                                       <img src= <?php echo $imagen ?>>

                                       
                                        
                                        
                                        <a href="index.php" class="btn btn-danger"  role="button" aria-pressed="true">ATRAS</a>
                                        <button type="submit"class="btn btn-success" name="update">GUARDAR CAMBIOS</button>
                                        
                                    
                                    </div>
                                    
                                </div>
                            </div>
         </form>

        </div>  
    </div>  
    
</div>


<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
