<div class="container p-4">
<div class="row">
<div class="col-md-4">
        <?php if(isset($_SESSION['message'])) {?>

   <div class="alert alert-<?= $_SESSION['message_type'];?> alert-dismissible fade show" role="alert">
         <?= $_SESSION['message'] ?>
         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>

        <?php session_unset(); } ?>
</div>





<div class="card card-body p-4">
<form action="buscar.php"  method="">
<div class="form-group">
<input type="text" name="" claholss="form-control" placeholder="BUSCAR" autofocus>
</div>
</div>

<div class="col-md-8"> 
   
   <table class="table-bordered">


   <thead>

   <tr>   
   <th>Marca</th>
   <th>Area</th>
   <th>Num_Serie</th>
   <th>Num_Placa</th> 
   <th>Acciones</th>  
   </tr>
   </thead> 
   <tbody>

   <?php $query="SELECT id,Marca,Area,Num_Serie,Num_Placa FROM activo_fijo";

   $Result=mysqli_query($conn,$query);
   while($row=mysqli_fetch_array($Result)){?>

   <tr>  
          <td> <?php echo $row['Marca'] ?></td> 
          <td> <?php echo $row['Area'] ?></td> 
          <td> <?php echo $row['Num_Serie'] ?></td> 
          <td> <?php echo $row['Num_Placa'] ?></td> 
          <td> 

          <a href="edit.php?id=<?php echo $row['id']?>" class="btn btn-secondary"> 
          <i class="fas fa-marker"></i>
          </a>
          <a href="eliminar.php?id=<?php echo $row['id']?>" class="btn btn-danger"> <i class="far fa-trash-alt"></i></a>
          
          </td>

   </tr>

   <?php }?>
   
   </tbody>
   </table>

</div>




</div>
</div>
</html>