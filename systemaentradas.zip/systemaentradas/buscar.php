<?php
 include("db.php");

 session_start();
 
 if (!isset($_SESSION['username6'])) {
     header("Location: login.php");
     exit();
 }

// Obtener el término de búsqueda
$query = $_GET['query'];

// Buscar coincidencias en la base de datos
$sql = "SELECT  DISTINCT producto FROM productos WHERE producto LIKE '%$query%' LIMIT 5";
$result = $conn->query($sql);

// Mostrar sugerencias
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<div class="list-group-item">' . $row['producto'] . '</div>';
    }
} else {
    echo '<div class="list-group-item">No se encontraron resultados</div>';
}

$conn->close();
?>



