<?php 
include("db.php");

if(isset($_POST['entradas'])){
    $busqueda=$_POST['busqueda'];
    $fecha=$_POST['fecha'];
    $salidas=$_POST['entrada'];
    $comentario=$_POST['comentario'];
   
 

    
     $entrada= "INSERT INTO entrada(producto,Fecha,Entrada,Comentario_Entrada)
              VALUES('$busqueda','$fecha','$salidas','$comentario')";

              $Result=mysqli_query($conn,$entrada);

              if(!$Result){
                  die("fail");
              }else{ echo'guardado';
              }

   $_SESSION['message']='GUARDADO';
    $_SESSION['message_type']='success';
  header("location:index.php");
 
  

}


?>