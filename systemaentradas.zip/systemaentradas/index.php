<?php
 include("db.php");

session_start();

if (!isset($_SESSION['username6'])) {
    header("Location: login.php");
    exit();
}

//echo "Rol: " . $_SESSION['role'] . "<br>";

// if ($_SESSION['role'] == 'admin') {
 //   echo '<a href="register.php" class="btn btn-outline-info btn-lg" >REGISTRAR NUEVO USUARIO</a><br>';-->
    
//}


//echo '<a href="logout.php">Cerrar Sesión</a>';
?><!--FIN -->
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="#" />  
    <title>PROYECTO ESMERALDA V2</title>
      
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- CSS personalizado --> 
    <link rel="stylesheet" href="main.css">  
    <link rel="stylesheet" href="vista.css">
    <link rel="stylesheet" href="nav.css">  
      
    <!--datables CSS básico-->
    <link rel="stylesheet" type="text/css" href="datatables/datatables.min.css"/>
    <!--datables estilo bootstrap 4 CSS-->  
    <link rel="stylesheet"  type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
           
    <!--font awesome con CDN-->  
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">  
      
  </head>
  <h2>BIENVENIDO USUARIO: <?php echo $_SESSION['username6']; ?></h2>
  <a type="button"  class="btn btn-success btn-lg" href="agregar.php">AGREGAR INSUMO</a>
    
    
  <a type="button" class="btn btn-danger btn-lg" href="logout.php">CERRAR SESION</a>
  <a type="button" class="btn btn-primary btn-lg" href="entrada2.php">AGREGAR ENTRADA</a>
  <a type="button" class="btn btn-warning btn-lg" href="salida2.php">AGREGAR SALIDA</a>
  <a type="button" class="btn btn-info btn-lg" href="historialentradas.php">HISTORIAL ENTRADAS</a>
  <a type="button" class="btn btn-light btn-lg" href="historialsalidas.php">HISTORIAL SALIDAS</a>

  <body> 
       
       <div style="height:50px"></div>
     
        <!-- tabla con DataTables-->
       <div class="container">
          <div class="row">
                <div class="col-lg-16">
                    <div class="table-responsive">        
                        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                            <th>CODIGO</th>
                            <th>PRODUCTO</th>
                            
                            <th>STOCK GENERAL</th>
                            <th>ENTRADAS TOTALES</th>
                            <th>PRESTAMOS Y SALIDAS TOTALES</th>
                            <th>RESULTADO TOTAL</th>
                            
                        
                            
                            
                           
                            
                             
                            </tr>
                        </thead>
                        <tbody>
                        <?php  


           if(!isset($_POST['buscar'])){
              $_POST['buscar']="";
           $buscar=$_POST['buscar'];
}
   $buscar=$_POST['buscar'];
   $query="SELECT * FROM vista_operaciones_final";

   $Result=mysqli_query($conn,$query);
   
   while($row=mysqli_fetch_array($Result)){?>

   <tr>  
          <td> <?= $row['codigo'] ?></td> 
          <td> <?= $row['Nombre_Producto'] ?></td> 
          <td> <?= $row['NUMERO_GENERAL'] ?></td> 
           
          <td> <?= $row['SUMA_TABLA1'] ?></td> 
          <td> <?= $row['RESTA_TABLA2'] ?></td> 
          <td> <?= $row['RESULTADO_FINAL'] ?></td>
          
        

   </tr>

   <?php }?>


                        </tbody>        
                       </table>                  
                    </div>
                </div>
        </div>  
    </div>    
     
    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="jquery/jquery-3.3.1.min.js"></script>
    <script src="popper/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
      
    <!-- datatables JS -->
    <script type="text/javascript" src="datatables/datatables.min.js"></script>    
     
    <!-- para usar botones en datatables JS -->  
    <script src="datatables/Buttons-1.5.6/js/dataTables.buttons.min.js"></script>  
    <script src="datatables/JSZip-2.5.0/jszip.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/pdfmake.min.js"></script>    
    <script src="datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
    <script src="datatables/Buttons-1.5.6/js/buttons.html5.min.js"></script>
     
    <!-- código JS propìo -->    
    <script type="text/javascript" src="main.js"></script>  
    <script type="text/javascript" src="navb.js"></script> 
    
    
  </body>

  
  </html>
