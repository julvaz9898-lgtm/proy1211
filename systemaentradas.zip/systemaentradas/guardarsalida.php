<?php 
include("db.php");

if(isset($_POST['salidas'])){
    $busqueda=$_POST['busqueda'];
    $fecha=$_POST['fecha'];
    $salidas=$_POST['salida'];
    $comentario=$_POST['comentario'];
    $tipo=$_POST['tipo'];
   
 

    
     $SALIDA= "INSERT INTO salida(producto,Fecha,Salida,Comentario_Salida,Tipo)
              VALUES('$busqueda','$fecha','$salidas','$comentario','$tipo')";

              $Result=mysqli_query($conn,$SALIDA);

              if(!$Result){
                  die("fail");
              }else{ echo'guardado';
              }

   $_SESSION['message']='GUARDADO';
    $_SESSION['message_type']='success';
  header("location:index.php");
 
  

}


?>