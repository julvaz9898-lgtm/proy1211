<?php
 include("db.php");

 session_start();
 
 if (!isset($_SESSION['username6'])) {
     header("Location: login.php");
     exit();}

$usuario = $_SESSION['username6'];
$fechaHora = date('Y-m-d H:i:s');

$randomNumber = rand(1, 99999); // Número de 6 dígitos

?>
<a href="index.php" class="btn btn-danger"  role="button" aria-pressed="true">ATRAS</a>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  
    
</head>
<body class="bg-light">
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="card p-4 shadow-lg" style="width: 450px;">
            <h4 class="card-title text-center">SALIDAS DE ALMACEN</h4>
            <form>
                <div class="mb-3">
                    <label for="datetime" class="form-label">Fecha y Hora</label>
                    <input type="text"  class="form-control" id="datetime" value="<?php echo $fechaHora; ?>" readonly>
                </div>
                <div class="mb-3" id="productoSubcategoria" style="flex-direction:column;">
                    <label for="username" class="form-label">Nombre de Usuario</label>
                    <input type="text"  class="form-control" id="username" value="<?php echo $usuario; ?>" readonly>
                </div>
                <div class="mb-3">
                <label for="busqueda" class="form-label">BUSCAR PRODUCTO:</label>
                <input type="text" class="form-control" id="busqueda" name="busqueda" placeholder="Escribe el nombre del producto">
                <div id="sugerencias" class="list-group mt-2"></div>
            </div>

            <div class="mb-3">
                  <a aling="left">CANTIDAD DE SALIDA</a>
                   <input type="text" class="form-control" placeholder="numero de serie*" name="entrada" id="entrada"/>
                </div>

                <div class="mb-3">
                    <label for="datetime" class="form-label">COMENTARIO DE ENTRADA</label>
                    <input type="text" class="form-control" placeholder="comentario*" name="comentario" id="comentario" />
                </div>
                <div class="mb-3">
                    <label for="randomNumber" class="form-label">NUMERO DE VALE</label>
                    <input type="text" class="form-control" id="randomNumber" value="<?= $randomNumber; ?>" readonly>
                </div>
                <div class="mb-3">
                                        <a aling="left">TIPO SE SALIDA</a>
                                            <select class="form-control" name="tipo" id="tipo">
                                           
                                            <option class="hidden"  selected disabled>SELECCIONA UNA OPCION</option>
                                                <option>SALIDA</option>
                                                <option>PRESTAMO</option>
                                                
                                              
                                              
                                            </select>
                                        </div>

                


                <button type="button" id="addButton" class="btn btn-primary mt-3" onclick="addToTable()">AÑADIR</button>
                
            </form>
            
        </div>
        
    </div>
    <table class="table table-bordered table-striped" id="dataTable">
            <thead class="table-success">
                <tr>
                    <th>FECHA</th>
                    <th>SUPERVISOR</th>
                    <th>PRODUCTO</th>
                    <th>CANTIDAD ENTRADA</th>
                    <th>COMENTARIO</th>
                    <th>NUMERO DE VALE</th>
                    <th>TIPO DE SALIDA</th>
                    

                   
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <!-- Filas dinámicas aquí -->
            </tbody>
                   </table>
        <button type="button" id="submitButton" class="btn btn-success">SUBIR INFORMACION</button>

      
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        const addButton = document.getElementById('addButton');
        const submitButton = document.getElementById('submitButton');
        const dataTable = document.getElementById('dataTable').getElementsByTagName('tbody')[0];

        // Agregar una fila a la tabla
        addButton.addEventListener('click', () => {
            const input1 = document.getElementById('datetime').value;
            const input2 = document.getElementById('username').value;
            const input3 = document.getElementById('busqueda').value;
            const input4 = document.getElementById('entrada').value;
            const input5 = document.getElementById('comentario').value;
            const input6 = document.getElementById('randomNumber').value;
            const input7 = document.getElementById('tipo').value;
          
           

            if (!input1 || !input2 || !input3 || !input4 || !input5 || !input6 || !input7) {
                alert('Por favor, completa todos los campos.');
                return;
            }

            const row = dataTable.insertRow();
            row.innerHTML = `
                <td>${input1}</td>
                <td>${input2}</td>
                <td>${input3}</td>
                <td>${input4}</td>
                <td>${input5}</td>
                <td>${input6}</td>
                <td>${input7}</td>
               
                <td>
                    <button class="btn btn-danger btn-sm" onclick="deleteRow(this)">ELIMINAR</button>
                </td>
            `;

            document.getElementById('dataForm').reset();
        });

        // Eliminar una fila de la tabla
        function deleteRow(button) {
            const row = button.parentElement.parentElement;
            row.remove();
        }

        // Enviar datos de la tabla a SQL Server
        submitButton.addEventListener('click', () => {
            const rows = Array.from(dataTable.rows);
            const data = rows.map(row => {
                const cells = row.cells;
                return {
                    campo1: cells[0].innerText,
                    campo2: cells[1].innerText,
                    campo3: cells[2].innerText,
                    campo4: cells[3].innerText,
                    select1: cells[4].innerText,
                    select2: cells[5].innerText,
                    select3: cells[6].innerText,
                   
                };
            });

            fetch('submit2.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
            })
                .then(response => response.text())
                .then(result => alert(result))
                .catch(error => console.error('Error:', error));
        });
    </script>




<!-- Bootstrap JS y dependencias -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Script para la búsqueda dinámica -->
    <script>
        $(document).ready(function() {
            $('#busqueda').on('input', function() {
                const query = $(this).val();
                if (query.length >= 2) { // Solo buscar si se escriben 2 o más caracteres
                    $.ajax({
                        url: 'buscar.php',
                        type: 'GET',
                        data: { query: query },
                        success: function(response) {
                            $('#sugerencias').html(response);
                        }
                    });
                } else {
                    $('#sugerencias').html(''); // Limpiar sugerencias si no hay suficiente texto
                }
            });

            // Seleccionar una sugerencia
            $(document).on('click', '.list-group-item', function() {
                $('#busqueda').val($(this).text());
                $('#sugerencias').html('');
            });
        });
    </script>



</body>

</html>