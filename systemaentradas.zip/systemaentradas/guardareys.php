<?php 
include("db.php");





if(isset($_POST['guardar'])){
    $producto=$_POST['producto'];
    $existencias=$_POST['existencias'];
    $salidas=$_POST['salidas'];
    $unidad_medida=$_POST['unidad_medida'];
    $prestamos=$_POST['prestamos'];
    $comentarios=$_POST['comentarios'];
 

    
     $query= "INSERT INTO productos(producto,existencias,unidad_medida,SALIDAS,prestamos,comentarios)
              VALUES('$producto','$existencias','$unidad_medida','$salidas','$prestamos','$comentarios')";

              $Result=mysqli_query($conn,$query);

              if(!$Result){
                  die("fail");
              }else{ echo'guardado';
              }

   $_SESSION['message']='GUARDADO';
    $_SESSION['message_type']='success';
  header("location:index.php");
 
  

}


?>
