import streamlit as st
import pandas as pd
import hashlib
import pyodbc

# Función para cifrar la contraseña
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Función para validar el usuario y la contraseña
def validate_login(username, password):
    # Usuarios ficticios para la demostración
    users = {
        "eli": hash_password("eli1"),
        "susan": hash_password("susan2"),
    }
    return users.get(username) == hash_password(password)

# Conexión a la base de datos SQL Server
def get_data_from_sql(query):
    # Configura tu conexión a la base de datos aquí
    conn_str = (
        "Driver={SQL Server};"
        "Server=172.22.1.10\DHW_BI;"
        "Database=ESTADISTICAS;"
        "UID=sa;"
        "PWD=BD06e8Y8;"
    )
    try:
        with pyodbc.connect(conn_str) as conn:
            return pd.read_sql(query, conn)  # Devuelve un DataFrame
    except Exception as e:
        st.error(f"Error al conectar a la base de datos: {e}")
        return pd.DataFrame()  # Devuelve un DataFrame vacío en caso de error

# LA INTERFAZ DE USUARIO DEL LOGIN NO MOVERLE NADAAAAAAAAA
def login_page():
    st.title("INICIA SESION PARA ACCEDER AL CHATBOT🤖")

    # ESTO ES LA ENTRADA DE TEXTO PARA SU USUARIO Y CONTRASEÑA Y SE GUARDA EN ESAS 2 VARIABLES
    username = st.text_input("Nombre de Usuario")
    password = st.text_input("Contraseña", type="password")

    if st.button("Iniciar Sesión"): #ESTE ES EL BOTON
        if validate_login(username, password):
            st.session_state['logged_in'] = True  # Almacena el estado de sesión
            st.session_state['username'] = username  # Almacena el nombre de usuario
            st.success("Inicio de sesión exitoso!")
            st.rerun()  # Recarga la página para mostrar el chatbot
        else:
            st.error("Nombre de usuario o contraseña incorrectos.")
# LA INTERFAZ DE USUARIO DEL LOGIN NO MOVERLE NADAAAAAAAAA


# Página del chatbot
def chatbot_page():
    st.title('CHAT BOT PARA DEVOLUCIONES🤖')
    st.title("SALUDOS")

    st.write(f"¡BIENVENIDO, {st.session_state['username']}! PUEDES ESCRIBIR JERARQUIA,GRANEL,lactaclic,facturacion,notas PARA CONSULTAR LOS REPORTES")

    user_input = st.text_input("CONSULTA TU REPORTE AQUI :")
    if st.button("Enviar"):
        query = ""
        query2=""
        query3=""
        query4=""
        # Lógica para determinar la consulta SQL basada en la entrada del usuario
        if "jerarquia" in user_input.lower():
            query2 = "SELECT * FROM JERAR_CLIENTES_SAP_V2"  # Reemplaza Ventas con tu tabla
        elif "granel" in user_input.lower():
            query = "select [Id Cliente],Cliente,Cod_Lactalis2,[Descripcion Lactalis],[Volumen Neto],[Valor Neto],Fecha FROM [ESTADISTICAS].[dbo].[Weekly_Sales_2025]  where grupo='NUEVA WALMART DE MEXICO' AND Fecha BETWEEN '2025-03-01' AND '2025-12-31' and Clasificación='GRANEL'"   # Reemplaza Clientes con tu tabla
        elif "lactaclic" in user_input.lower():
            query3 = "SELECT * FROM SO_LACTACLIC_VIC"
        elif "notas" in user_input.lower():
            query4 = "SELECT * FROM NOTAS_CARGO_NEW_FORMATO"
        elif "facturacion" in user_input.lower():
            query5 = "SELECT Grupo,Cod_Lactalis2,Descripcion_Lactalis2,Marca1,Clasificación,Fecha,[Valor Neto],[Volumen Neto] from Weekly_Sales_2025 where Fecha between '2025-03-01' and '2025-12-31' and Canal='CANAL MODERNO' and Año=2025"
        else:
            st.write("Lo siento, no entiendo esa pregunta. Pregunta por ventas, clientes o productos.")

        if query:
            data = get_data_from_sql(query)
            # Mostrar datos en un DataFrame
            if not data.empty:
                st.write("Aquí están los datos de la tabla:")
                st.dataframe(data)  # Mostrar DataFrame en Streamlit
            else:
                st.write("No se encontraron datos.")
        elif query2:
            data = get_data_from_sql(query2)
            #total=data["VALOR_COSTO"].sum()
            #st.write('TOTAL VALOR COSTO:',total)
            # Mostrar datos en un DataFrame
            if not data.empty:
                st.write("Aquí están los datos de la tabla:")
                st.dataframe(data)  # Mostrar DataFrame en Streamlit
        elif query3:
            data = get_data_from_sql(query3)

            if not data.empty:
                st.write("Aquí están los datos de la tabla:")
                st.dataframe(data)  # Mostrar DataFrame en Streamlit
            else:
                st.write("No se encontraron datos.")

        elif query4:
            data = get_data_from_sql(query4)

            if not data.empty:
                st.write("Aquí están los datos de la tabla:")
                st.dataframe(data)  # Mostrar DataFrame en Streamlit
            else:
                st.write("No se encontraron datos.")

        elif query5:
            data = get_data_from_sql(query5)

            if not data.empty:
                st.write("Aquí están los datos de la tabla:")
                st.dataframe(data)  # Mostrar DataFrame en Streamlit
            else:
                st.write("No se encontraron datos.")

    if st.button("Cerrar Sesión"):
        st.session_state.clear()  # Limpia la sesión
        st.success("Has cerrado sesión correctamente.")
        st.rerun()  # Recarga la página para volver a mostrar el login

# Verifica si el usuario está logueado
if 'logged_in' not in st.session_state or not st.session_state['logged_in']:
    login_page()  # Muestra la página de login
else:
    chatbot_page()  # Muestra la página del chatbot
