import streamlit as st
import pandas as pd
import numpy as num
import sqlite3
import pypyodbc as odbc
from sqlalchemy import create_engine
from sqlalchemy.engine import URL
import pyodbc
import mysql.connector
import matplotlib.pyplot as plt
from streamlit_option_menu import option_menu


import obsoletas
import lactalis



page = st.sidebar.selectbox("Selecciona una página", [ "obsoletas","lactalis"])

# Cargar la página seleccionada


if page == "obsoletas":
    obsoletas.show_page()
elif page == "lactalis":
    lactalis.show_page()





    ##st.title('GRAFICAS INVENTARIO DE EQUIPO DE COMPUTO LACTALIS⌨️')
    #st.write("BIENVENIDOS 😎")






#connection=mysql.connector.connect(
 #host='localhost',
 #user='root',
 #password='',
 #database='inventario'
#)

#print('connected')


#cursor=connection.cursor()
#cursor.execute("SELECT * FROM activo_fijo")
#data=cursor.fetchall()

#st.title('DB MYSQL INVENTARIO')
#df=pd.DataFrame(data,columns=cursor.column_names)
#st.dataframe(df)


#st.header("____________________________________")


#cursor=connection.cursor()
#cursor.execute("SELECT Ubicacion,CANTIDAD FROM `cantidad_laptops` ")

#data2=cursor.fetchall()
#st.title('INVENTARIO LAPTOPS')
#df2=pd.DataFrame(data2,columns=cursor.column_names)
#st.dataframe(df2)
#st.bar_chart(df2.set_index('Ubicacion'))

#cursor=connection.cursor()
#cursor.execute("SELECT Ubicacion,CANTIDAD FROM `cantidad_cpu` ")
#data3=cursor.fetchall(
#)

#st.title(' INVENTARIO DESKTOP')
#df5=pd.DataFrame(data3,columns=cursor.column_names)
#st.dataframe(df5)

#st.bar_chart(df5.set_index('Ubicacion'))



#st.header("____________________________________")

#st.title('INVENTARIO LAPTOPS LACTALIS')
#fig, ax = plt.subplots()
#ax.bar(df2['Ubicacion'],df2['CANTIDAD'])
#ax.set_xlabel('Ubicacion')
#st.pyplot(fig)


#st.title('INVENTARIO CPU LACTALIS')
#fig, ax = plt.subplots()
#ax.bar(df5['Ubicacion'],df5['CANTIDAD'])
#ax.set_xlabel('Ubicacion')

#st.pyplot(fig)
