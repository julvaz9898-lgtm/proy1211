import streamlit as st
import pandas as pd
import numpy as num
import sqlite3
import pypyodbc as odbc
from sqlalchemy import create_engine
from sqlalchemy.engine import URL
import pyodbc
from datetime import datetime




st.title('CHAT BOT PARA DEVOLUCIONES🤖')
st.write("SALUDOS Y BIENVENIDAS 😎")

SERVER = '172.22.2.220\LACTALIS_DWH'
DATABASE = 'SELLOUT_2024'
USERNAME = 'sa  '
PASSWORD = 'BD06e8Y8'

connectionString = f'DRIVER={{SQL Server}};SERVER={SERVER};DATABASE={DATABASE};UID={USERNAME};PWD={PASSWORD}'

conn2 = pyodbc.connect(connectionString)




def get_table_data():

    query = "SELECT * FROM CONSOLIDADO_DEV"  # Ajusta esta consulta a tu tabla
    df10 = pd.read_sql(query, conn2)
    conn2.close()
    return df10

def get_table_data2():
    query2 = "SELECT * FROM AVANCE"  # Ajusta esta consulta a tu tabla
    df11 = pd.read_sql(query2, conn2)
    conn2.close()
    return df11

def get_table_data3():
    query3 = "SELECT * FROM NOTAS_CARGO"  # Ajusta esta consulta a tu tabla
    df12 = pd.read_sql(query3, conn2)
    conn2.close()
    return df12


def chatbot_response(user_input):
    if "devoluciones" in user_input.lower():
        # Si el usuario pide los datos de la tabla
        df10 = get_table_data()
        total=df10["VALOR_COSTO"].sum()
        st.write('TOTAL VALOR COSTO:',total)
        return df10

    elif "avance" in user_input.lower():
        df11=get_table_data2()
        return df11

    elif "notas" in user_input.lower():
            df11=get_table_data3()
            return df11

    elif "ayuda" in user_input.lower():
        # Si el usuario dice buenos días
        return "¡Buenos días! te puedo generar los reportes de que necesites, solo escribe: 'devoluciones', 'notas' o 'avance'"

    elif "hola" in user_input.lower():
            # Si el usuario dice buenos días
            return "¡Buenos días! HOLA."
    elif "como estas" in user_input.lower():
            # Si el usuario dice buenos días
            return "¡ESTOY MUY BIEN! Y TU QUE TAL."
    elif "buenos días" or "buenos dias" in user_input.lower():
            # Si el usuario dice buenos días
            return "¡BUENOS DÍAS! "
    else:
        # Respuesta por defecto
        return "Lo siento, no entiendo tu pregunta. Intenta escribiendo 'ayuda'."
# Mostrar saludo inicial basado en la hora
def greet():
    current_hour = datetime.now().hour
    if current_hour < 12:
        return "¡Buenos días!"
    elif current_hour < 19:
        return "¡Buenas tardes!"
    else:
        return "¡Buenas noches!"
# Interfaz con Streamlit
st.title("REPORTES")

st.write(greet())
st.write("Puedes decir 'buenos días' o escribiendo 'ayuda'.")


# Input del usuario
user_input = st.text_input("Haz una pregunta al chatbot:", "")

# Procesar el input del usuario
if st.button("Enviar"):
    response = chatbot_response(user_input)

    # Mostrar los datos de la tabla si la respuesta es un DataFrame
    if isinstance(response, pd.DataFrame):
        st.write("Aquí están los datos de la tabla:")
        st.dataframe(response)
    else:
        st.write(response)
