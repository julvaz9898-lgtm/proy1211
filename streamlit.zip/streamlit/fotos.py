import streamlit as stt

# Configuración de la página principal
stt.set_page_config(page_title="Mi App Multipage", layout="wide")

stt.title("🌟 Bienvenido a la App Multipágina con Streamlit")

stt.write("Navega por las páginas usando la barra lateral 📂")
stt.sidebar.success("Selecciona una página arriba 👆")
