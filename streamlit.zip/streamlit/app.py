import streamlit as st
import pandas as pd
import numpy as num
import sqlite3
import pypyodbc as odbc
from sqlalchemy import create_engine
from sqlalchemy.engine import URL
import pyodbc




st.title('PLATAFORMA DE VALIDACION👈')
st.write("SALUDOS Y BIENVENIDAS ")

#st.header(" DEVOLUCIONES🤑 ")

#archivo=r'C:\Users\Administrador.WIN-LE39LI0G69U\Desktop\streamlit\DEVOLUCION.xlsx'
#df=pd.read_excel(archivo)
#total=df['VALOR_COSTO'].sum()
#st.dataframe(df)
#st.write('TOTAL VALOR COSTO:',total)

#st.header("____________________________________")

#st.header("LACTASALES🥛 ")

#archivo2=r'C:\Users\Administrador.WIN-LE39LI0G69U\Desktop\streamlit\LACTASALES.xlsx'

#df2=pd.read_excel(archivo2)

#st.dataframe(df2)
st.header("____________________________________")
st.header(" DEVOLUCIONES BD 💸")

SERVER = '172.22.2.220\LACTALIS_DWH'
DATABASE = 'SELLOUT_2024'
USERNAME = 'sa  '
PASSWORD = 'BD06e8Y8'

connectionString = f'DRIVER={{SQL Server}};SERVER={SERVER};DATABASE={DATABASE};UID={USERNAME};PWD={PASSWORD}'

conn = pyodbc.connect(connectionString)


SQL_QUERY = """
SELECT * FROM CONSOLIDADO_DEV
"""

df3=pd.read_sql_query(SQL_QUERY,conn)
st.dataframe(df3)
total=df3['VALOR_COSTO'].sum()
st.write('TOTAL VALOR COSTO:',total)


st.header("____________________________________")
st.header("VALIDACION LACTASALES🥛 ")


SERVER = '172.22.2.220\LACTALIS_DWH'
DATABASE = 'SELLOUT_2024'
USERNAME = 'sa'
PASSWORD = 'BD06e8Y8'

connectionString = f'DRIVER={{SQL Server}};SERVER={SERVER};DATABASE={DATABASE};UID={USERNAME};PWD={PASSWORD}'

conn = pyodbc.connect(connectionString)

SQL_QUERY = """
SELECT * FROM VALIDACION_LACTACLIC
"""
df4=pd.read_sql_query(SQL_QUERY,conn)
st.dataframe(df4)

st.header("____________________________________")
st.header("VALIDACION SUPERVISOR Y CONSUMO🥛 ")



SERVER = '172.22.2.216\SATURNO'
DATABASE = 'SAP_MIDDLEWARE'
USERNAME = 'sa'
PASSWORD = 'L1nn2rb1ck.@'

connectionString2 = f'DRIVER={{SQL Server}};SERVER={SERVER};DATABASE={DATABASE};UID={USERNAME};PWD={PASSWORD}'

conn2 = pyodbc.connect(connectionString2)

SQL_QUERY2 = """
SELECT *from  VALIDACION_SUP_CONSUMO
"""
df5=pd.read_sql_query(SQL_QUERY2,conn2)
st.dataframe(df5)
