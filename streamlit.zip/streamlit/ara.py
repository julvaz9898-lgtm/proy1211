import streamlit as st
import pandas as pd
import numpy as num
import sqlite3

from sqlalchemy import create_engine
from sqlalchemy.engine import URL
import pyodbc
import mysql.connector

from streamlit_option_menu import option_menu

st.title("REPORTES AUDITORIA 📒")
st.subheader("SELECCIONA EL REPORTE QUE DESEAS VER 👀", divider=True)

# Función para conectarse a SQL Server y ejecutar una consulta
def fetch_data(query):
    # Configura la conexión a SQL Server
    conn_str = (
        "DRIVER={SQL Server};"
        "SERVER=172.22.2.220\LACTALIS_DWH;"  # Cambia por tu servidor
        "DATABASE=SELLOUT_2024;"  # Cambia por tu base de datos
        "UID=sa;"  # Cambia por tu usuario
        "PWD=BD06e8Y8;"  # Cambia por tu contraseña
    )

    conn = pyodbc.connect(conn_str)
    data = pd.read_sql(query, conn)
    conn.close()
    return data


    # Título de la aplicación


# Línea azul


# Botones de diferentes colores
button1 = st.button("REPORTE DEGUSTACIONES", key="button1", help="Muestra los resultados del reporte")
button2 = st.button("REPORTE COMPRAS AUDITORIAS", key="button2", help="Muestra los resultados del reporte")
button3 = st.button("MODIFICACION DE ACREEDORES", key="button3", help="Muestra los resultados del reporte")
button4 = st.button("REPORTE DE VARIACION", key="button4", help="Muestra los resultados del reporte")

# Consultas SQL para cada botón
queries = {
    "button1":  "SELECT * FROM CONSOLIDADO_DEV",  # Cambia por tu consulta
    "button2": "SELECT * FROM AVANCE",  # Cambia por tu consulta
    "button3": "SELECT * FROM NOTAS_CARGO",  # Cambia por tu consulta
    "button4": "SELECT * FROM NOTAS_CARGO"  # Cambia por tu consulta
}

# Mostrar el DataFrame cuando se hace clic en un botón
if button1:
    df = fetch_data(queries["button1"])
    st.write(df)

if button2:
    df = fetch_data(queries["button2"])
    st.write(df)

if button3:
    df = fetch_data(queries["button3"])
    st.write(df)

if button4:
    df = fetch_data(queries["button4"])
    st.write(df)
