import streamlit as st
import pandas as pd
import numpy as num
import sqlite3
import pypyodbc as odbc
from sqlalchemy import create_engine
from sqlalchemy.engine import URL
import pyodbc
import mysql.connector
import matplotlib.pyplot as plt
from streamlit_option_menu import option_menu

def show_page():
    st.title(' INVENTARIO DE EQUIPO DE COMPUTO LACTALIS⌨️')
    st.write("BIENVENIDOS 😎")


    connection=mysql.connector.connect(
     host='localhost',
     user='root',
     password='',
     database='inventario'
    )

    print('connected')


    #cursor=connection.cursor()
    #cursor.execute("SELECT * FROM activo_fijo")
    #data=cursor.fetchall()

    #st.title('DB MYSQL INVENTARIO')
    #df=pd.DataFrame(data,columns=cursor.column_names)
    #st.dataframe(df)


    st.header("____________________________________")


    cursor=connection.cursor()
    cursor.execute("SELECT Ubicacion,CANTIDAD FROM `cantidad_laptops` ")
    data2=cursor.fetchall()

    st.title('INVENTARIO LAPTOPS')
    df2=pd.DataFrame(data2,columns=cursor.column_names)
    st.dataframe(df2)
    st.bar_chart(df2.set_index('Ubicacion'))

    cursor=connection.cursor()
    cursor.execute("SELECT Ubicacion,CANTIDAD FROM `cantidad_cpu` ")
    data3=cursor.fetchall(
    )

    st.title(' INVENTARIO DESKTOP')
    df5=pd.DataFrame(data3,columns=cursor.column_names)
    st.dataframe(df5)
    st.bar_chart(df5.set_index('Ubicacion'))







    st.header("____________________________________")

    st.title('VERSION 2 GRAFICAS')
    st.title('INVENTARIO LAPTOPS LACTALIS')
    fig1, ax1 = plt.subplots()
    ax1.bar(df2['Ubicacion'],df2['CANTIDAD'])
    ax1.set_xlabel('UBICACION')
    ax1.set_ylabel('CANTIDAD LAPTOPS')
    st.pyplot(fig1)


    st.title('INVENTARIO CPU LACTALIS')
    fig2, ax2 = plt.subplots()
    ax2.bar(df5['Ubicacion'],df5['CANTIDAD'])
    ax2.set_xlabel('UBICACION')
    ax2.set_ylabel('CANTIDAD LAPTOPS')

    st.pyplot(fig2)
