import streamlit as st
import pandas as pd
import pyodbc
from sqlalchemy import create_engine, MetaData, Table, select, delete

# Configuración de la conexión a SQL Server
def create_connection():
    server = '172.22.2.220\BI_MEXICO'
    database = 'SELLOUT_2024'
    username = 'sa'
    password = 'BD06e8Y8'
    connection_string = f'mssql+pyodbc://{username}:{password}@{server}/{database}?driver=SQL+Server'
    engine = create_engine(connection_string)
    return engine

# Función para limpiar el DataFrame
def clean_data(df):
    # Aquí puedes agregar cualquier lógica de limpieza que necesites
    # Por ejemplo, eliminar filas con valores nulos, cambiar tipos de datos, etc.
    df = df.dropna()
    return df

# Función para subir el DataFrame a SQL Server
def upload_to_sql(df, table_name):
    engine = create_connection()
    metadata = MetaData()
    metadata.reflect(bind=engine)

    # Si la tabla ya existe, eliminarla
    if table_name in metadata.tables:
        table = metadata.tables[table_name]
        with engine.connect() as conn:
            conn.execute(delete(table))

    # Subir el DataFrame a la tabla
    df.to_sql(table_name, con=engine, if_exists='replace', index=False)
    st.success(f'Datos subidos a la tabla {table_name} en SQL Server.')

# Interfaz de Streamlit
st.title("Cargar y Limpiar Excel para SQL Server")

uploaded_file = st.file_uploader("Sube tu archivo Excel", type=["xlsx"])

if uploaded_file is not None:
    # Leer el archivo Excel
    df = pd.read_excel(uploaded_file)

    # Mostrar el DataFrame original
    st.write("DataFrame Original:")
    st.write(df)

    # Limpiar el DataFrame
    df_cleaned = clean_data(df)

    # Mostrar el DataFrame limpio
    st.write("DataFrame Limpio:")
    st.write(df_cleaned)

    # Subir el DataFrame a SQL Server
    table_name ="NotasData"

    if st.button("Subir a SQL Server"):
        if table_name:
            upload_to_sql(df_cleaned, table_name)
        else:
            st.error("Por favor, ingresa un nombre de tabla.")
