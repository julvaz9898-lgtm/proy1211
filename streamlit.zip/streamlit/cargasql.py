import streamlit as st
import pandas as pd
import pyodbc

# Configurar conexión a SQL Server
def conectar_sqlserver():
    return pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};"
        "SERVER=172.22.2.220\BI_MEXICO;"  # Cambiar por tu servidor
        "DATABASE=SELLOUT_2024;"  # Cambiar por tu base de datos
        "UID=sa;"  # Cambiar por tu usuario
        "PWD=BD06e8Y8;"  # Cambiar por tu contraseña
    )

# Convertir columnas de tipo float a varchar
def convertir_float_a_varchar(df):
    for columna in df.select_dtypes(include=['float']).columns:
        df[columna] = df[columna].astype(str)  # Convertir a texto (varchar)
    return df

# Sobreescribir datos en SQL Server
def cargar_datos_sqlserver(df, tabla):
    try:
        conn = conectar_sqlserver()
        cursor = conn.cursor()

        # Eliminar registros existentes en la tabla
        cursor.execute(f"DELETE FROM {tabla}")
        conn.commit()

        # Insertar nuevos registros
        columnas = ', '.join(df.columns)
        valores = ', '.join(['?' for _ in df.columns])
        sql_query = f"INSERT INTO {tabla} ({columnas}) VALUES ({valores})"

        for _, row in df.iterrows():
            cursor.execute(sql_query, tuple(row))

        conn.commit()
        cursor.close()
        conn.close()
        st.success("Datos sobrescritos correctamente en la base de datos.")
    except Exception as e:
        st.error(f"Error al cargar datos: {e}")

# Interfaz de usuario con Streamlit
def main():
    st.title("PORTAL DE CARGA PARA BI🤓☝️")
    st.markdown("Sube un archivo Excel para sobrescribir los datos en una tabla de SQL Server.")

    # Subir archivo Excel
    archivo = st.file_uploader("Arrastra tu archivo Excel aquí", type=["xlsx", "xls"])

    # Nombre de la tabla de SQL Server
    tabla_sql = st.text_input("COLOCA EL NOMBRE DE LA TABLA DEL ARCHIVO QUE SUBIRAS: MiTabla,CUOTA", "MiTabla")

    if archivo is not None:
        try:
            # Leer el archivo Excel en un DataFrame
            df = pd.read_excel(archivo)

            # Convertir columnas de tipo float a varchar
            df = convertir_float_a_varchar(df)

            # Mostrar una vista previa de los datos
            st.write("Vista previa de los datos cargados:")
            st.dataframe(df)
            st.write(df.dtypes)

            # Botón para cargar los datos en SQL Server
            if st.button("Sobreescribir datos en SQL Server"):
                if tabla_sql:
                    cargar_datos_sqlserver(df, tabla_sql)
                else:
                    st.error("Por favor, proporciona el nombre de la tabla.")
        except Exception as e:
            st.error(f"Error al procesar el archivo: {e}")

if __name__ == "__main__":
    main()
