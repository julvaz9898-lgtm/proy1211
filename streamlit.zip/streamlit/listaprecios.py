import streamlit as st
import pandas as pd
import numpy as num
import sqlite3

from sqlalchemy import create_engine
from sqlalchemy.engine import URL
import pyodbc


st.title('REPORTE LISTA DE PRECIOS👈')
st.write("SALUDOS ")


SERVER = '172.22.2.220\BI_MEXICO'
DATABASE = 'SELLOUT_2024'
USERNAME = 'sa  '
PASSWORD = 'BD06e8Y8'

connectionString = f'DRIVER={{SQL Server}};SERVER={SERVER};DATABASE={DATABASE};UID={USERNAME};PWD={PASSWORD}'

conn = pyodbc.connect(connectionString)


SQL_QUERY = """
SELECT * FROM LISTA_PRECIOS
"""

df4=pd.read_sql_query(SQL_QUERY,conn)
st.dataframe(df4)
