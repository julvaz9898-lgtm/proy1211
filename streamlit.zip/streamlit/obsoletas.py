import streamlit as st
import pandas as pd
import numpy as num
import sqlite3
import pypyodbc as odbc
from sqlalchemy import create_engine
from sqlalchemy.engine import URL
import pyodbc
import mysql.connector
import matplotlib.pyplot as plt
from streamlit_option_menu import option_menu
import altair as alt

def show_page():
    st.title('EQUIPO DE COMPUTO OBSOLETO⌨️')
    st.write("USUARIOS CON EQUIPO OBSOLETO ")




    connection=mysql.connector.connect(
    host='localhost',
    user='root',
    password='',
    database='inventario'
      )

    print('connected')



    cursor2=connection.cursor()
    cursor2.execute("SELECT Ubicacion, AÑOS_ANTIGUEDAD,Marca,Fech_Compra FROM `graficas_obsoletas` WHERE OBSOLESENCIA='OBSOLETA' ")
    data=cursor2.fetchall()


    cursor6=connection.cursor()
    cursor6.execute("SELECT * FROM `graficas_obsoletas` WHERE OBSOLESENCIA='OBSOLETA' ")
    data7=cursor6.fetchall()
    df7=pd.DataFrame(data7,columns=cursor6.column_names)
    st.dataframe(df7)



    df=pd.DataFrame(data,columns=cursor2.column_names)
    
    columna_seleccionada = st.sidebar.selectbox('Selecciona la columna para el gráfico', df.columns)

    st.title('UBICACION EQUIPO OBSOLETO')

    cursor=connection.cursor()
    cursor.execute("SELECT COUNT(OBSOLESENCIA) AS CANTIDAD, Ubicacion FROM `graficas_obsoletas`WHERE OBSOLESENCIA='OBSOLETA' GROUP by OBSOLESENCIA, Ubicacion ")
    data4=cursor.fetchall()

    df6=pd.DataFrame(data4,columns=cursor.column_names)

    st.dataframe(df6)
    st.bar_chart(df6.set_index('Ubicacion')['CANTIDAD'])

    st.subheader('Gráfico de Pastel')
    fig_pie, ax_pie = plt.subplots()
    df[columna_seleccionada].value_counts().plot(kind='pie', ax=ax_pie, autopct='%1.1f%%')
    ax_pie.set_ylabel('')
    ax_pie.set_title(f'Porcentajes de {columna_seleccionada}')
    st.pyplot(fig_pie)
