import streamlit as st
import pandas as pd
import pyodbc

# Configuración de la conexión a SQL Server
server = '172.22.2.220\BI_MEXICO;'
database = 'SELLOUT_2024;'
username = 'sa'
password = 'BD06e8Y8'

def get_connection():
    conn_str = f'DRIVER={{SQL Server}};SERVER={server};DATABASE={database};UID={username};PWD={password}'
    return pyodbc.connect(conn_str)

def create_table_and_insert_data(df, table_name):
    conn = get_connection()
    cursor = conn.cursor()

    # Eliminar la tabla si ya existe
    cursor.execute(f"IF OBJECT_ID('{table_name}', 'U') IS NOT NULL DROP TABLE {table_name}")
    conn.commit()

    # Crear una nueva tabla dinámicamente
    columns = ", ".join([f"[{col}] NVARCHAR(MAX)" for col in df.columns])
    cursor.execute(f"CREATE TABLE {table_name} ({columns})")
    conn.commit()

    # Insertar los datos en la tabla
    for _, row in df.iterrows():
        placeholders = ', '.join(['?' for _ in df.columns])
        cursor.execute(f"INSERT INTO {table_name} VALUES ({placeholders})", tuple(row))
    conn.commit()

    cursor.close()
    conn.close()

def main():
    st.title("CARGA DE LA CUOTA A SQL")
    uploaded_file = st.file_uploader("Sube tu archivo Excel", type=["xlsx"])

    if uploaded_file is not None:
        df = pd.read_excel(uploaded_file)
        st.write("Vista previa de los datos:")
        st.dataframe(df)

        table_name = "CuotaData"
        if st.button("Subir a SQL Server"):
            create_table_and_insert_data(df, table_name)
            st.success(f"DATOS CARGADOS A {table_name} en SQL Server")

if __name__ == "__main__":
    main()
