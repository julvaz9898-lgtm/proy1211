<?php
// db.php
$serverName = "172.22.1.10\DHW_BI"; // Cambiar por tu servidor SQL Server
$connectionOptions = array(
    "Database" => "ESTADISTICAS", // Reemplaza con tu base de datos
    "Uid" => "sa",           // Tu usuario de la base de datos
    "PWD" => "BD06e8Y8"         // Tu contraseña de la base de datos
);

// Conexión a SQL Server
$conn = sqlsrv_connect($serverName, $connectionOptions);
if ($conn === false) {
    die(print_r(sqlsrv_errors(), true));
}


// Consultar los datos
$sql = "SELECT * FROM CUOTA"; // Reemplaza con tu consulta
$stmt = sqlsrv_query($conn, $sql);
if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}

?>
