<?php require 'db.php'; ?>



<!DOCTYPE html>
<html lang="es">
<head>
    
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" />
  <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
</head>
<body>
<div id="particles-js"></div>

<div class="container">
<div class="eyes">
        <div class="eye"><div class="pupil"></div></div>
        <div class="eye"><div class="pupil"></div></div>
    </div>
        <img src="img/mexico.png" alt="Imagen Redonda" class="custom-image" />
        
      </div>
      <h1 class="ml1">
  <span class="text-wrapper">
    <span class="line line1"></span>
   
    <span class="letters">Venta Diaria Lactalis México🧀<p>RESUMEN DEL DIA </p><span id="fecha"></span></span>
    <span class="line line2"></span>
 
  </span>
</h1>

<div class="example">

       <section class="scroll-section"><pre>¡Buen Día!👋<br>Reporte de <br>seguimiento sobre</p> Volúmenes vs Cuota🗒️</p></pre></section>
  
   
</div>



  <h1 class="ml3"><?php
      // Imprimir los datos de la base de datos en el formato deseado
      while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
          // Cada línea tiene su propio párrafo
          echo "<p>💠Venta Diaria promedio REAL: <span>(" . number_format($row['VENTA_DIARIA_PROM'], 2) . ")T &nbsp &nbsp &nbsp  &nbsp  &nbsp  &nbsp </span></p>";
          echo "<p>💠Venta Diaria promedio CUOTA: <span>(" . number_format($row['VENTA_PROM_CUOTA'], 2) . ")T (" . number_format($row['POR_VENTA'], 2) . "%)</span>";
          echo "<p>💠Venta necesaria Diaria para alcanzar el objetivo: <span>(" . number_format($row['VENTA_OBJETIVO'], 2) . ")T</span></p>";
          echo "<p>💠Si la venta sigue de manera lineal Volumen Final del mes: <span>(" . number_format($row['VOL_FINAL_MES'], 2) . ")T vs &nbsp Cuota (" . number_format($row['POR_VENTA'], 2) . "%)</span></p>";
          echo "<p>💠Cuota Objetivo: <span>(" . number_format($row['VOL_NET_CUOT'], 2) . ")T</span></p>";
      }
      ?></h1>
    



<script type="module">
    import { animate, inView } from "https://cdn.jsdelivr.net/npm/motion@12/+esm"

    inView(".scroll-section pre", (element) => {
        animate(
            element,
            { opacity: 1, x: [-100, 0] },
            {
                duration: 0.9,
                easing: [0.17, 0.55, 0.55, 1],
            }
        )

        return () => animate(element, { opacity: 0, x: -100 })
    })


    // Función para obtener la fecha actual y restarle un día
    function obtenerFechaConDiaMenos() {
      let fechaActual = new Date(); // Fecha actual
      fechaActual.setDate(fechaActual.getDate() - 1); // Restar un día
      // Formatear la fecha a formato 'DD/MM/YYYY'
      let dia = fechaActual.getDate().toString().padStart(2, '0');
      let mes = (fechaActual.getMonth() + 1).toString().padStart(2, '0');
      let anio = fechaActual.getFullYear();
      return `${dia}/${mes}/${anio}`; // Devuelve la fecha en formato DD/MM/YYYY
    }

    // Insertar la fecha con un día menos en el elemento con id "fecha"
    document.getElementById("fecha").textContent = obtenerFechaConDiaMenos();


    // Wrap every letter in a span
var textWrapper = document.querySelector('.ml1 .letters');
textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<span class='letter'>$&</span>");

anime.timeline({loop: true})
  .add({
    targets: '.ml1 .letter',
    scale: [0.3,1],
    opacity: [0,1],
    translateZ: 0,
    easing: "easeOutExpo",
    duration: 1000,
    delay: (el, i) => 40 * (i+1)
  }).add({
    targets: '.ml1 .line',
    scaleX: [0,1],
    opacity: [0.5,1],
    easing: "easeOutExpo",
    duration: 1000,
    offset: '-=875',
    delay: (el, i, l) => 40 * (l - i)
  }).add({
    targets: '.ml1',
    opacity: 0,
    duration: 1000,
    easing: "easeOutExpo",
    delay: 1000
  });






  // Wrap every letter in a span
var textWrapper = document.querySelector('.ml3');
textWrapper.innerHTML = textWrapper.innerHTML.replace(/(<p[^>]*>)([^<]+)(<\/p>)/g, function(match, p1, text, p3) {
  // Envuelve cada letra del texto dentro del <p> en un <span class='letter'>
  const wrappedText = text.replace(/\S/g, "<span class='letter'>$&</span>");
  return `${p1}${wrappedText}${p3}`; // Mantiene los tags <p> y aplica el cambio solo al texto
});

particlesJS("particles-js", {
            particles: {
                number: { value: 100 },
                size: { value: 2 },
                color: { value: "#007bff" },
                move: { speed: 2 },
                line_linked: { color: "#007bff" }
            }
        });


        
        document.addEventListener("mousemove", (event) => {
            document.querySelectorAll(".pupil").forEach(pupil => {
                let eye = pupil.parentElement;
                let eyeRect = eye.getBoundingClientRect();
                let eyeCenterX = eyeRect.left + eyeRect.width / 2;
                let eyeCenterY = eyeRect.top + eyeRect.height / 2;
                let deltaX = event.clientX - eyeCenterX;
                let deltaY = event.clientY - eyeCenterY;
                let angle = Math.atan2(deltaY, deltaX);
                let distance = Math.min(eyeRect.width / 4, Math.hypot(deltaX, deltaY) / 6);
                pupil.style.transform = `translate(${Math.cos(angle) * distance}px, ${Math.sin(angle) * distance}px)`;
            });
        });

</script>






<style>
  .eyes {
            display: flex;
            gap: 20px;
        }
        .eye {
            width: 80px;
            height: 80px;
            background: white;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }
        .pupil {
            width: 30px;
            height: 30px;
            background: black;
            border-radius: 50%;
            position: absolute;
        }




 #particles-js {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -1;
        }
        .container {
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 8px rgba(0, 0, 255, 0.3);
            max-width: 600px;
            margin: auto;
            margin-top: 50px;
        }
.ml3 p {
  font-weight: 100;
  text-align: left;
 
}


    body {
        overflow-x: hidden;
        overflow-y: scroll;
        text-align: center;
    }

    .example {
        display: flex;
        flex-direction: column;
        width: 100px;
    }

    

    .scroll-section {
        box-sizing: border-box;
        width: 100svw;
        height: 50vh;
        display: flex;
        justify-content: flex-start;
        overflow: hidden;
        padding: 50px;
        background: var(--hue-1-transparent);
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .scroll-section:nth-child(2) {
        background: var(--hue-2-transparent);
    }

    .scroll-section:nth-child(3) {
        background: var(--hue-3-transparent);
    }

    .scroll-section:nth-child(4) {
        background: var(--hue-4-transparent);
    }

    .scroll-section pre {
        font-size: 20px;
        color: #000000;
        display: block;
        transform: translateX(-100px);
        opacity: 0;
    }

    .scroll-section:nth-child(2) pre {
        color: #2c83f9;
    }

    .scroll-section:nth-child(3) pre {
        color: #000000;
    }

    .scroll-section:nth-child(4) pre {
        color: #2c83f9;
    }


    .container {
      display: flex;
      justify-content: center;
      align-items: center;
      
      
  
    }

    .custom-image {
      width: 500px; 
      height: 180px;
      object-fit: cover; 
      border-radius: 10%; 
      
      
    }



    .ml1 {
  font-weight: 300;
  font-size: 3.2em;
}

.ml1 .letter {
  
  line-height: 1em;
}

.ml1 .text-wrapper {
  position: relative;
  display: inline-block;
  padding-top: 0.1em;
  padding-right: 0.05em;
  padding-bottom: 0.15em;
}

.ml1 .line {
  opacity: 0;
  position: absolute;
  left: 0;
  height: 3px;
  width: 100%;
  background-color: #3092e4 ;
  transform-origin: 0 0;
}

.ml1 .line1 { top: 0; }
.ml1 .line2 { bottom: 0; }



@media only screen and (max-width: 768px) {
    /* Aquí puedes agregar estilos para dispositivos con pantallas más pequeñas */
    body {
        font-size: 10px; /* Ejemplo de ajuste de tamaño de fuente */
    }
    /* Otros estilos para ajustar el diseño */
}
</style>

</body>
</html>

<?php
// Cerrar la conexión
sqlsrv_free_stmt($stmt);
sqlsrv_close($conn);
?>