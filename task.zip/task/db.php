<?php
// db.php
$serverName = "172.22.2.220\BI_MEXICO"; // Cambiar por tu servidor SQL Server
$database = "SELLOUT_2024";
$username = "sa";
$password = "BD06e8Y8";

try {
    $conn = new PDO("sqlsrv:server=$serverName;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}
?>
