<?php
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $estado = $_POST['estado'];

    $query = "UPDATE tareas SET estado = :estado WHERE id = :id";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->bindParam(':estado', $estado);

    if ($stmt->execute()) {
        header("Location: index.php");
    } else {
        echo "Error al actualizar el estado.";
    }
}
?>
