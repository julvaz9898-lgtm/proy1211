<?php
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre_tarea = $_POST['nombre_tarea'];
    $responsable = $_POST['responsable'];

    $query = "INSERT INTO tareas (nombre_tarea, responsable) VALUES (:nombre_tarea, :responsable)";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':nombre_tarea', $nombre_tarea);
    $stmt->bindParam(':responsable', $responsable);

    if ($stmt->execute()) {
        header("Location: index.php");
    } else {
        echo "Error al agregar la tarea.";
    }
}
?>
