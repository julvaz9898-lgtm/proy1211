<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Tareas</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    <style>
        #particles-js {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -1;
        }
        .container {
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 255, 0.3);
            max-width: 600px;
            margin: auto;
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <div id="particles-js"></div>
    <div class="container">
        <h3 class="text-center text-primary">APLICACION DE TAREAS DE BI</h3>
        <form action="add_task.php" method="POST">
            <div class="form-group">
                <label for="nombre_tarea">Tarea</label>
                <input type="text" name="nombre_tarea" id="nombre_tarea" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="responsable">Responsable</label>
                
                <select class="form-control" name="responsable" id="responsable">
                                            <option class="hidden"  selected disabled>SELECCIONA UNA OPCION</option>
                                                <option>MANUEL ROJAS</option>
                                                <option>JULIAN GOMEZ</option>
                                                
                                            </select>
                
                
            </div>
            <button type="submit" class="btn btn-success btn-block">Agregar Tarea</button>
        </form>

        <h4 class="mt-4">Listado de Tareas</h4>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Tarea</th>
                    <th>Responsable</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                require 'db.php';
                $query = "SELECT * FROM tareas ORDER BY fecha_creacion DESC";
                foreach ($conn->query($query) as $row) {
                    echo "<tr>
                        <td>{$row['nombre_tarea']}</td>
                        <td>{$row['responsable']}</td>
                        <td>{$row['estado']}</td>
                        <td>
                            <form action='update_task.php' method='POST' class='d-inline'>
                                <input type='hidden' name='id' value='{$row['id']}'>
                                <input type='hidden' name='estado' value='" . ($row['estado'] === 'En Proceso' ? 'Completada' : 'En Proceso') . "'>
                                <button type='submit' class='btn btn-sm btn-primary'>Cambiar Estado</button>
                            </form>
                        </td>
                    </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <script>
        particlesJS("particles-js", {
            particles: {
                number: { value: 100 },
                size: { value: 3 },
                color: { value: "#007bff" },
                move: { speed: 2 },
                line_linked: { color: "#007bff" }
            }
        });
    </script>
</body>
</html>
