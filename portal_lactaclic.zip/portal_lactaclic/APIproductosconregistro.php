<?php
include('conn.php');


$sqlClientesRegistrados = "SELECT DISTINCT Grupo FROM DB_TIENDAS_APP_MAYTE";
$resultClientesRegistrados = sqlsrv_query($conn, $sqlClientesRegistrados);

if (sqlsrv_has_rows($resultClientesRegistrados)) {
    // Salida de datos de cada fila
    while ($row = sqlsrv_fetch_array($resultClientesRegistrados, SQLSRV_FETCH_ASSOC)) {
        echo "<option value='".$row['Cadena']."'>".$row['Cadena']."</option>";
    }
} else {
    echo "No hay productos con estas caracteristicas";
}

$conn->close();