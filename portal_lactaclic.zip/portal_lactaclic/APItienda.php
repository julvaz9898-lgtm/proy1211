<?php
include('conn.php');

$user = $_GET['user1'];
$grupo = $_GET['grupo'];





$sqlClientesRegistrados1 = "SELECT DISTINCT NombreTienda from v_AppSellout_product WHERE IdSupervisor = '$user' and Grupo='$grupo' AND NombreMes='ENERO'";

$resultClientesRegistrados1 = sqlsrv_query($conn, $sqlClientesRegistrados1);

if (sqlsrv_has_rows($resultClientesRegistrados1)) {
    // Salida de datos de cada fila
    while ($row = sqlsrv_fetch_array($resultClientesRegistrados1, SQLSRV_FETCH_ASSOC)) {
        echo "<option value='".$row['NombreTienda']."'>".$row['NombreTienda']."</option>";
    }
} else {
    echo "No hay productos con estas caracteristicas";
}

$conn->close();