<?php
session_start();
if (isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Fondo con partículas */
        body {
            margin: 0;
            overflow: hidden;
            background: #ffffff;
            color: #fff;
        }
        #particles-js {
            position: absolute;
            width: 100%;
            height: 100%;
            z-index: -1;
        }

        /* Título animado */
        .animated-title {
            font-size: 2rem;
            font-weight: bold;
            color: #05bafd;
            animation: colorChange 2s infinite;
        }
        @keyframes colorChange {
            0%, 100% {
                color: #05bafd;
            }
            50% {
                color: #0563fd;
            }
        }

        /* Botón de inicio de sesión */
        .btn-particles {
            position: relative;
            overflow: hidden;
            font-size: 1.5rem;
        }
        .btn-particles:active::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 300px;
            height: 300px;
            background: rgba(0, 123, 255, 0.4);
            border-radius: 50%;
            transform: translate(-50%, -50%);
            animation: particleEffect 0.5s ease-out;
            z-index: 1;
        }
        @keyframes particleEffect {
            from {
                opacity: 1;
                transform: translate(-50%, -50%) scale(0);
            }
            to {
                opacity: 0;
                transform: translate(-50%, -50%) scale(1);
            }
        }
    </style>
</head>
<body>
    <!-- Fondo de partículas -->
    <div id="particles-js"></div>

    <!-- Formulario de Login -->
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="card text-center p-4" style="width: 400px; border-radius: 15px;">
            <div>
                <img src="img/Lactalis_logo.svg.png" alt="Logo" class="img-fluid mb-3" style="border-radius: 50%;">
            </div>
            <h1 class="animated-title mb-4">Inicio de Sesión</h1>
            <form action="validate_login.php" method="POST">
                <div class="mb-3">
                    <label for="username" class="form-label">Usuario</label>
                    <input type="text" class="form-control" name="usuario" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Contraseña</label>
                    <input type="password" class="form-control" name="password" required>
                </div>
                <button type="submit" class="btn btn-success btn-particles w-100">Iniciar Sesión</button>
            </form>
        </div>
    </div>

    <!-- Partículas (particles.js) -->
    <script src="https://cdn.jsdelivr.net/npm/particles.js"></script>
    <script>
        // Inicializar partículas en el fondo
        particlesJS("particles-js", {
            particles: {
                number: { value: 100 },
                color: { value: ["#e2f82d", "#168ef9", "#16f91d"] },
                shape: { type: "circle" },
                opacity: { value: 2.5 },
                size: { value: 4 },
                line_linked: {
                    enable: true,
                    distance: 180,
                    color: "#67cefe",
                    opacity: 0.6,
                    width: 2,
                },
                move: { enable: true, speed: 2 },
            },
            interactivity: {
                events: {
                    onhover: { enable: true, mode: "repulse" },
                    onclick: { enable: true, mode: "push" },
                },
                modes: {
                    repulse: { distance: 100 },
                    push: { particles_nb: 4 },
                },
            },
        });

        // Efecto de partículas al presionar el botón (agregado en CSS)
    </script>
</body>
</html>
