<?php
$serverName = "172.22.2.216\SATURNO"; // Cambia esto con tu servidor
$connectionOptions = array(
    "Database" => "SAP_MIDDLEWARE",
    "Uid" => "sa", 
    "PWD" => "L1nn2rb1ck.@"
);

// Establecer la conexión
$conn = sqlsrv_connect( $serverName, $connectionOptions );
if( !$conn ) {
    die( print_r(sqlsrv_errors(), true));
}
?>