<?php
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo "No se recibió información.";
    exit;
}

try {
    $conn = new PDO("sqlsrv:Server=172.22.2.216\SATURNO;Database=SAP_MIDDLEWARE", "sa", "L1nn2rb1ck.@");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    foreach ($data as $row) {
        $stmt = $conn->prepare("INSERT INTO MAYTE_APP (FECHA, SUPERVISOR, CADENA, TIENDA, PRODUCTO, SUGERIDO_PZ, COMPROMISO_VENTA) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute(array(
            $row['campo1'],
            $row['campo2'],
            $row['campo3'],
            $row['campo4'],
            $row['select1'],
            $row['select2'],
            $row['select3'],
        ));
    }

    echo "Datos guardados exitosamente.";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
