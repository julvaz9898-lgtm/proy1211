<?php
include('conn.php');

$user = $_GET['user2'];
$grupo = $_GET['grupo1'];
$tienda=$_GET['tienda'];





$sqlClientesRegistrados2 = "SELECT DISTINCT NombreProducto from v_AppSellout_product WHERE IdSupervisor = '$user' and Grupo='$grupo'and  NombreTienda='$tienda' AND NombreMes='ENERO'";

$resultClientesRegistrados2 = sqlsrv_query($conn, $sqlClientesRegistrados2);

if (sqlsrv_has_rows($resultClientesRegistrados2)) {
    // Salida de datos de cada fila
    while ($row = sqlsrv_fetch_array($resultClientesRegistrados2, SQLSRV_FETCH_ASSOC)) {
        echo "<option value='".$row['NombreProducto']."'>".$row['NombreProducto']."</option>";
    }
} else {
    echo "No hay productos con estas caracteristicas";
}

$conn->close();