<?php
// Conexión
// Conexión a la base de datos SQL Server
$serverName = "172.22.2.220\BI_MEXICO";
$connectionOptions = array(
    "Database" => "SELLOUT_2024",
    "Uid" => "sa",
    "PWD" => "BD06e8Y8"
);
$conn = sqlsrv_connect($serverName, $connectionOptions);

$usuario = "MXSUICI018";
$password = password_hash("L4C29033S", PASSWORD_DEFAULT);

$sql = "INSERT INTO usuarios (usuario, password) VALUES (?, ?)";
$params = array($usuario, $password);

$stmt = sqlsrv_query($conn, $sql, $params);
if ($stmt) {
    echo "Usuario creado exitosamente5.";
} else {
    die(print_r(sqlsrv_errors(), true));
}
?>
