<?php
include('conn.php');

$categoria = $_GET['user'];




$sqlClientesRegistrados = "SELECT DISTINCT Grupo from v_AppSellout_product WHERE IdSupervisor = '$categoria'";

$resultClientesRegistrados = sqlsrv_query($conn, $sqlClientesRegistrados);

if (sqlsrv_has_rows($resultClientesRegistrados)) {
    // Salida de datos de cada fila
    while ($row = sqlsrv_fetch_array($resultClientesRegistrados, SQLSRV_FETCH_ASSOC)) {
        echo "<option value='".$row['Grupo']."'>".$row['Grupo']."</option>";
    }
} else {
    echo "No hay productos con estas caracteristicas";
}

$conn->close();