<?php
session_start();

// Conexión a la base de datos SQL Server
$serverName = "172.22.2.220\BI_MEXICO";
$connectionOptions = array(
    "Database" => "SELLOUT_2024",
    "Uid" => "sa",
    "PWD" => "BD06e8Y8"
);

$conn = sqlsrv_connect($serverName, $connectionOptions);
if ($conn === false) {
    die(print_r(sqlsrv_errors(), true));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['usuario'];
    $password = $_POST['password'];

    // Consulta para obtener el usuario
    $sql = "SELECT usuario, password FROM usuarios WHERE usuario = ?";
    $params = array($usuario);
    $stmt = sqlsrv_query($conn, $sql, $params);

    if ($stmt === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    // Verifica si el usuario existe
    if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['usuario'] = $usuario;
            header("Location: admin_portal.php");
            exit();
        } else {
            echo "Contraseña incorrecta.";
        }
    } else {
        echo "Usuario no encontrado.";
    }
}
sqlsrv_close($conn);
?>
