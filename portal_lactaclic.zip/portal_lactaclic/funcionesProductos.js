document.addEventListener("DOMContentLoaded", function () {
    cargarGrupo();
  });



  
  function cargarGrupo(){
    let selected = document.getElementById("username");
    let opcionSeleccionada = selected.value; // Obtén el valor del input
    
    fetch(
        "APIgrupo.php?user=" + encodeURIComponent(opcionSeleccionada)
      )

      .then((response) => response.text())
      .then((data) => {
        let selectElement = document.getElementById("categoriaSelect");
        selectElement.innerHTML = data;
        cargarTienda()
      })
      .catch((error) => console.error("Error:", error));
     

   }


   function cargarTienda(){
      
    let selectusername=document.getElementById("username");
    let usernameselect=selectusername.value; // Obtén el valor del input

    let selectgrupo=document.getElementById("categoriaSelect");
    let optiongrupo= selectgrupo.selectedOptions[0];
    let grupoSeleccionada = optiongrupo.value;//OBTIENE EL VALOR DEL SELECT DE GRUPO

    fetch(
        "APItienda.php?user1="+ encodeURIComponent(usernameselect)+"&grupo="+encodeURIComponent(grupoSeleccionada)

    )
    .then((response) => response.text())
    .then((data) => {
      let selectElement = document.getElementById("tiendaSelect");
      selectElement.innerHTML = data;
      cargarProd()
    })
    .catch((error) => console.error("Error:", error));

   }




   function cargarProd(){
    let selectusername1=document.getElementById("username");
    let usernameselect1=selectusername1.value; // Obtén el valor del input

    let selectgrupo1=document.getElementById("categoriaSelect");
    let optiongrupo1= selectgrupo1.selectedOptions[0];
    let grupoSeleccionada1 = optiongrupo1.value;//OBTIENE EL VALOR DEL SELECT DE GRUPO

    let selecttienda=document.getElementById("tiendaSelect");
    let optiontienda=selecttienda.selectedOptions[0];
    let tiendaSeleccionada=optiontienda.value;//OBTIENE EL VALOR DEL select de tienda
    fetch(
        "APIProd.php?user2="+ encodeURIComponent(usernameselect1)+"&grupo1="+encodeURIComponent(grupoSeleccionada1)+"&tienda="+encodeURIComponent(tiendaSeleccionada)

    )

    .then((response) => response.text())
    .then((data) => {
      let selectElement = document.getElementById("codigoSelect");
      selectElement.innerHTML = data;
    })
    .catch((error) => console.error("Error:", error));







   }

   



