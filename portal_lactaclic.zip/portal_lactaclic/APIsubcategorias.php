<?php
include('conn.php');

$categoria = $_GET['categoria'];

$sqlClientesRegistrados = "SELECT DISTINCT Nombre_Tienda FROM DB_TIENDAS_APP_MAYTE WHERE Cadena = '$categoria'";
$resultClientesRegistrados = sqlsrv_query($conn, $sqlClientesRegistrados);

if (sqlsrv_has_rows($resultClientesRegistrados)) {
    // Salida de datos de cada fila
    while ($row = sqlsrv_fetch_array($resultClientesRegistrados, SQLSRV_FETCH_ASSOC)) {
        echo "<option value='".$row['Nombre_Tienda']."'>".$row['Nombre_Tienda']."</option>";
    }
} else {
    echo "No hay productos con estas caracteristicas";
}

$conexion->close();