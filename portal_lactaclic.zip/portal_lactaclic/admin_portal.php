<?php
include("conn.php");
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}

$usuario = $_SESSION['usuario'];
$fechaHora = date('Y-m-d H:i:s');

// Consultar información para el campo select- YA NO SIRVE ESTO
$sql = "SELECT Cadena
FROM DB_TIENDAS_APP_MAYTE group by Cadena";
$cadena = sqlsrv_query($conn, $sql);



?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  
    
</head>
<body class="bg-light">
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="card p-4 shadow-lg" style="width: 450px;">
            <h4 class="card-title text-center">Formulario de usuario</h4>
            <form>
                <div class="mb-3">
                    <label for="datetime" class="form-label">Fecha y Hora</label>
                    <input type="text"  class="form-control" id="datetime" value="<?php echo $fechaHora; ?>" readonly>
                </div>
                <div class="mb-3" id="productoSubcategoria" style="flex-direction:column;">
                    <label for="username" class="form-label">Nombre de Usuario</label>
                    <input type="text"  class="form-control" id="username" value="<?php echo $usuario; ?>" readonly>
                </div>

                <div class="col-4"  id="productoCategoria" style="flex-direction:column;">
                <label for="categoria">CADENA:</label>
                    <select name="categoria" id="categoriaSelect" onchange= "cargarTienda()" >

                 </select>
                </div>

                <div class="col-4"  id="productoCategoria" style="flex-direction:column;">
                <label for="categoria">TIENDA:</label>
                    <select name="categoria" id="tiendaSelect" onchange= "cargarProd()">

                 </select>
                </div>

                <div class="col-4" class="form-label" id="productoCategoria" style="flex-direction:column;">
                <label for="categoria">PRODUCTO:</label>
                    <select name="categoria" id="codigoSelect" >

                 </select>
                </div>
                <div class="mb-4">
                        <label for="numero1" class="form-label"></label>
                        <input type="number" id="numero1" class="form-control form-control-lg" placeholder="SUGERIDO EN PZ" required>
                    </div>

                    <!-- Segundo input -->
                    <div class="mb-4">
                        
                        <input type="number" id="numero2" class="form-control form-control-lg" placeholder="COMPROMISO PZ VENTA" required>
                    </div>


                <a href="logout.php" class="btn btn-danger w-100">Cerrar sesión</a>
                <button type="button" id="addButton" class="btn btn-primary mt-3" onclick="addToTable()">AÑADIR</button>

            </form>
            
        </div>
        
    </div>
    <table class="table table-bordered table-striped" id="dataTable">
            <thead class="table-success">
                <tr>
                    <th>FECHA</th>
                    <th>SUPERVISOR</th>
                    <th>CADENA</th>
                    <th>TIENDA</th>
                    <th>PRODUCTO</th>
                    <th>SUGERIDO PZ</th>
                    <th>COMPROMISO VENTA</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <!-- Filas dinámicas aquí -->
            </tbody>
                   </table>
        <button type="button" id="submitButton" class="btn btn-success">SUBIR INFORMACION</button>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        const addButton = document.getElementById('addButton');
        const submitButton = document.getElementById('submitButton');
        const dataTable = document.getElementById('dataTable').getElementsByTagName('tbody')[0];

        // Agregar una fila a la tabla
        addButton.addEventListener('click', () => {
            const input1 = document.getElementById('datetime').value;
            const input2 = document.getElementById('username').value;
            const select1 = document.getElementById('categoriaSelect').value;
            const select2 = document.getElementById('tiendaSelect').value;
            const select3 = document.getElementById('codigoSelect').value;
            const input3 = document.getElementById('numero1').value;
            const input4 = document.getElementById('numero2').value;
           

            if (!input1 || !input2 || !select1 || !select2 || !select3 || !input3 || !input4) {
                alert('Por favor, completa todos los campos.');
                return;
            }

            const row = dataTable.insertRow();
            row.innerHTML = `
                <td>${input1}</td>
                <td>${input2}</td>
                <td>${select1}</td>
                <td>${select2}</td>
                <td>${select3}</td>
                <td>${input3}</td>
                <td>${input4}</td>
                <td>
                    <button class="btn btn-danger btn-sm" onclick="deleteRow(this)">ELIMINAR</button>
                </td>
            `;

            document.getElementById('dataForm').reset();
        });

        // Eliminar una fila de la tabla
        function deleteRow(button) {
            const row = button.parentElement.parentElement;
            row.remove();
        }

        // Enviar datos de la tabla a SQL Server
        submitButton.addEventListener('click', () => {
            const rows = Array.from(dataTable.rows);
            const data = rows.map(row => {
                const cells = row.cells;
                return {
                    campo1: cells[0].innerText,
                    campo2: cells[1].innerText,
                    campo3: cells[2].innerText,
                    campo4: cells[3].innerText,
                    select1: cells[4].innerText,
                    select2: cells[5].innerText,
                    select3: cells[6].innerText,
                };
            });

            fetch('submit.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
            })
                .then(response => response.text())
                .then(result => alert(result))
                .catch(error => console.error('Error:', error));
        });
    </script>


</body>
<script src="funcionesProductos.js"></script>
</html>